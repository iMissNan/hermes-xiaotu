"""小雅元数据 CDN 引擎 —— 从 https://emby.xiaoya.pro 构建片名索引并提供元数据增强。

设计依据: Mars TV 小雅元数据接入执行计划（2026-08-02）。
实测适配（勘察结论）:
- 目录列表 = nginx autoindex HTML（href 百分号编码，锚文本为解码显示名）。
- 片名目录命名 "<片名> (2023)" / "<片名>（2023）" / "<片名>(2023)"；
  索引按验收标准递归 4 层（MAX_DEPTH=4）：根(0) → 分类(1) → 地区/类型(2) →
  年份/子分类(3)，片名目录在末层识别；4 层足够覆盖 每日更新→电影→中国→片名。
- 本 CDN 的 NFO 文件实际命名为 "<片名目录名>.nfo"（movie.nfo 返回 404），
  解析时按候选链 [目录名.nfo, movie.nfo, tvshow.nfo, season.nfo] 依次探测。
- 全部网络操作走 utils.fetch（connect 2s 固定 + read 超时），失败软降级。

对外契约（供 main.py 集成，接口冻结）:
- xiaoya = XiaoyaMeta() 模块级单例；import 即后台建索引，每 6h 重建。
- get_meta(title, year=None) -> {matched, title, year, poster, fanart, rating,
  rating_imdb, plot, source:"xiaoya"} | {matched: False}
"""

from __future__ import annotations

import html as _html
import logging
import os
import re
import threading
import time
import xml.etree.ElementTree as ET
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from difflib import SequenceMatcher
from logging.handlers import RotatingFileHandler
from typing import Optional
from urllib.parse import quote

try:
    from hot_engine import _norm_title  # 片名归一化（与聚合去重同源）
except Exception:  # pragma: no cover  独立运行兜底：同逻辑本地实现
    def _norm_title(t: str) -> str:
        t = t.lower().strip()
        return re.sub(r"[\s:：·•\-—–_/\\()（）\[\]【】.。!！?？,，'\"“”‘’]+", "", t)

from utils import (  # noqa: E402
    LOG_BACKUP_COUNT, LOG_MAX_BYTES, LOGS_DIR, LRUCache, fetch)

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------
BASE_URL = "https://emby.xiaoya.pro"        # 小雅元数据 CDN 根
TITLE_RE = re.compile(r"^(.+?)[（(]\s*(\d{4})\s*[)）]$")   # "<片名> (2023)" 等三形态
DIR_RE = re.compile(r'<a href="([^"]+)">([^<]*)</a>')      # nginx autoindex 行

DIR_TIMEOUT = 3.0          # 单目录 read 超时（connect 2s 由 utils.fetch 固定）
BUILD_BUDGET = 480.0       # 单次索引构建总预算（5 路并发 × 480s ≈ 2400s 等效单线程）
MAX_DEPTH = 4              # 递归 4 层：根=0 分类=1 地区/类型=2 年份/子分类=3，片名目录在末层识别
INDEX_TTL = 6 * 3600       # 索引重建周期 6h
LOOKUP_TTL = 24 * 3600     # lookup 结果缓存 24h
NFO_TTL = 24 * 3600        # nfo 解析结果缓存 24h
NFO_DEBOUNCE_TTL = 300     # nfo 空结果进程内防抖 5min（不写 24h 缓存）
FUZZY_SCAN_LIMIT = 80000   # 模糊扫描上限（防极端索引拖慢请求路径）
MATCH_MIN_SCORE = 60       # 评分制匹配最低分（<60 拒绝，宁缺毋错防误配）
SIM_RATIO_MIN = 0.9        # 相似度兜底阈值（超高置信才给分）
_CACHE_MISS = object()     # lookup 缓存哨兵（区分"未缓存"与"缓存了 None 的 miss 防抖"）

NFO_CANDIDATES = ("movie.nfo", "tvshow.nfo", "season.nfo")  # 探测候选链
SKIP_DIR_HINTS = ("画质演示", "演示测试")                     # 明确非片源目录
CAT_PRIORITY = {           # 预算内先扫高频分类（其余按列表顺序，优先级 99）
    "每日更新": 1, "电视剧": 2, "电影": 3, "动漫": 4, "纪录片（已刮削）": 5,
}
LOG_PATH = os.path.join(LOGS_DIR, "xiaoya_meta.log")


def _to_float(v) -> Optional[float]:
    try:
        return float(str(v).strip())
    except (TypeError, ValueError):
        return None


class XiaoyaMeta:
    """小雅 CDN 元数据引擎：内存片名索引 + 惰性 NFO 解析 + 多层缓存。

    线程模型: 索引构建在后台守护线程（5 路并发扫描，写锁 _swap_lock 保护，替换原子）；
    读方直接取 self._index 快照引用，永不阻塞；NFO 抓取走 LRU 单飞。
    """

    def __init__(self, budget: float = BUILD_BUDGET, auto_start: bool = True):
        self._budget = budget
        self._index: dict = {}        # norm_title -> [entry, ...]（读快照）
        self._idx_ts = 0.0
        self._ready = False           # 至少一次成功构建（非空索引）
        self._degraded = True         # 未构建 / 被截断 / 上次刷新失败
        self._truncated = False       # 上次构建是否被预算截断
        self._build_lock = threading.Lock()   # 防并发构建（不阻塞：抢不到即跳过）
        self._swap_lock = threading.Lock()    # 索引替换锁（写互斥，读不加锁）
        self._stats_lock = threading.Lock()
        self._hits = 0
        self._misses = 0
        self._lookup_cache = LRUCache(maxsize=8000, default_ttl=LOOKUP_TTL)
        self._nfo_cache = LRUCache(maxsize=500, default_ttl=NFO_TTL)
        self._nfo_debounce: dict = {}   # path -> 空结果时间戳（5min 防抖，不写缓存）
        self._log = self._logger()
        if auto_start:
            t = threading.Thread(target=self._build_loop,
                                 name="xiaoya-index", daemon=True)
            t.start()
        self._log.info("xiaoya meta engine ready: base=%s budget=%.1fs",
                       BASE_URL, self._budget)

    # ------------------------------------------------------------------
    # 日志（独立文件 xiaoya_meta.log，5MB × 7 滚动）
    # ------------------------------------------------------------------
    def _logger(self) -> logging.Logger:
        os.makedirs(LOGS_DIR, exist_ok=True)
        logger = logging.getLogger("martv.xiaoya_meta")
        logger.setLevel(logging.INFO)
        logger.propagate = False
        if not logger.handlers:
            fh = RotatingFileHandler(LOG_PATH, maxBytes=LOG_MAX_BYTES,
                                     backupCount=LOG_BACKUP_COUNT, encoding="utf-8")
            fh.setFormatter(logging.Formatter(
                "%(asctime)s %(levelname)s [%(name)s] %(message)s"))
            logger.addHandler(fh)
        return logger

    # ------------------------------------------------------------------
    # 索引构建：启动时 + 每 6h；BFS 递归 4 层，预算截断 → degraded
    # ------------------------------------------------------------------
    def _build_loop(self) -> None:
        while True:
            try:
                self.build_index()
            except Exception:
                self._log.exception("index build crashed, retry in %ds", INDEX_TTL)
            time.sleep(INDEX_TTL)

    def build_index(self) -> None:
        """全量重建索引（幂等；并发调用直接跳过）。失败不阻塞任何请求。"""
        if not self._build_lock.acquire(blocking=False):
            self._log.warning("build skipped: another build in progress")
            return
        try:
            self._build_locked()
        except Exception:
            self._log.exception("index build error (degraded)")
            with self._swap_lock:
                self._degraded = True
        finally:
            self._build_lock.release()

    def _build_locked(self) -> None:
        start = time.monotonic()
        deadline = start + self._budget
        index: dict = {}
        fetched = failed_net = empty_dir = pending = 0
        truncated = False
        qlock = threading.Lock()      # 保护共享 queue / index / 统计计数

        root, root_err = self._list_dir(BASE_URL + "/", deadline)  # 根 → 分类
        if root_err:                  # 根都拉不到：真实网络失败，仅计数（空队列自然走完构建）
            with qlock:
                failed_net += 1
        queue = deque(sorted((("/" + href, 1, name) for href, name in root),
                             key=lambda x: CAT_PRIORITY.get(x[2], 99)))

        def worker() -> None:
            """5 路并发之一：从共享 deque 取目录并行拉取（CAT_PRIORITY 排序在入队时保持）。"""
            nonlocal fetched, failed_net, empty_dir, pending, truncated
            while True:
                with qlock:
                    if time.monotonic() >= deadline:   # 预算耗尽：剩余未请求目录计入 pending
                        truncated = True
                        pending += len(queue)
                        queue.clear()
                        return
                    if not queue:
                        return
                    path_enc, depth, _name = queue.popleft()
                entries, is_error = self._list_dir(BASE_URL + path_enc, deadline)
                with qlock:
                    if time.monotonic() >= deadline:   # 预算耗尽：截断而非失败/空目录
                        truncated = True
                        pending += 1
                        continue
                    if is_error:                       # 真实网络失败（异常/非200/超时）
                        failed_net += 1
                        continue
                    fetched += 1                       # HTTP 200 成功拉取
                    if not entries:                    # 合法空目录：不吞预算、不触发 degraded
                        empty_dir += 1
                        continue
                for href, name in entries:                 # 本层条目（仅目录）
                    name = name.rstrip("/")
                    m = TITLE_RE.match(name)
                    if m and 1900 <= int(m.group(2)) <= 2099:
                        with qlock:
                            self._add_entry(index, path_enc + href, name,
                                            m.group(1).strip(), int(m.group(2)))
                    elif depth < MAX_DEPTH:  # MAX_DEPTH=4：分类→地区→年份/子分类，片名目录在末层识别
                        with qlock:
                            queue.append((path_enc + href, depth + 1, name))

        with ThreadPoolExecutor(max_workers=5,
                                thread_name_prefix="xiaoya-scan") as pool:
            futures = [pool.submit(worker) for _ in range(5)]  # 先全部提交再等待
            for f in futures:
                f.result()            # 异常上抛 → build_index 捕获置 degraded

        with self._swap_lock:
            if index or not self._index:                   # 空索引仅首建时生效
                self._index = index
                self._idx_ts = time.monotonic()
                self._ready = bool(index)
                self._degraded = truncated or not index
                self._truncated = truncated
            else:                                          # 刷新失败 → 保留旧索引
                self._degraded = True
                self._log.warning("refresh produced empty index, "
                                  "keep previous %d titles", len(self._index))
        with self._stats_lock:
            hits, misses = self._hits, self._misses
        self._log.info(
            "index build complete: dirs=%d failed_net=%d empty_dir=%d titles=%d %.1fs%s "
            "(lookup hits=%d misses=%d)",
            fetched, failed_net, empty_dir, len(index), time.monotonic() - start,
            " TRUNCATED" if truncated else "", hits, misses)
        if truncated or failed_net or not index:
            self._log.warning("index degraded: truncated=%s failed_net_dirs=%d "
                              "empty_dirs=%d pending_dirs=%d indexed=%d",
                              truncated, failed_net, empty_dir, pending, len(index))

    @staticmethod
    def _add_entry(index: dict, path_enc: str, dir_name: str,
                   title: str, year: int) -> None:
        norm = _norm_title(title)
        if not norm:
            return
        entry = {
            "path": path_enc,                    # 编码相对路径，含首尾 "/"
            "title": title,
            "year": year,
            "dir_name": dir_name,                # 解码目录名（nfo 候选探测用）
            "poster": BASE_URL + path_enc + "poster.jpg",
            "fanart": BASE_URL + path_enc + "fanart.jpg",
            "nfo": BASE_URL + path_enc + quote(dir_name + ".nfo"),
        }
        index.setdefault(norm, []).append(entry)

    def _list_dir(self, url: str, deadline: float) -> tuple:
        """拉取目录列表（单目录 3s 超时）→ (entries, is_error)。

        entries: [(href_编码, 显示名)]，仅目录；
        is_error: True=真实网络失败（异常/非200/超时），计入 failed_net 并触发 degraded；
                  False=HTTP 200 成功（空列表=合法空目录，计入 empty_dir，不吞预算不触发 degraded）。
        """
        if time.monotonic() >= deadline:   # 预算耗尽：不算错误，由调用方按截断处理
            return [], False
        try:
            r = fetch(url, timeout=DIR_TIMEOUT)
        except Exception:                  # 极端 URL/网络异常 → 真实网络失败
            return [], True
        if r is None:
            return [], True
        try:
            body, status = r.text, r.status_code
        finally:
            r.close()
        if status != 200 or not body:      # 非 200 / 空响应体 → 真实网络失败
            return [], True
        out = []
        for href, name in DIR_RE.findall(body):
            if href in ("../", "/") or not href.endswith("/"):
                continue
            name = _html.unescape(name).strip()
            if any(h in name for h in SKIP_DIR_HINTS):
                continue
            out.append((href, name))
        return out, False                  # HTTP 200：合法结果（空列表=合法空目录）

    # ------------------------------------------------------------------
    # 查找：精确（O(1)）→ 模糊包含（优先 year，其次标题最短），最多 1 条
    # ------------------------------------------------------------------
    @staticmethod
    def _norm_query(title: Optional[str], year):
        raw = (title or "").strip()
        m = TITLE_RE.match(raw)
        if m:
            return _norm_title(m.group(1)), (year or int(m.group(2)))
        # 无括号年份后缀："阿龙2025" / "火遮眼2025" → 标题+年份分离（分类页常见形态）
        m2 = re.match(r"^(.+?)\s*(19|20)\d{2}$", raw)
        if m2:
            return _norm_title(m2.group(1)), (year or int(m2.group(0)[-4:]))
        return _norm_title(raw), year

    @staticmethod
    def _pick(lst: list, year) -> Optional[dict]:
        if year:
            for e in lst:
                if e["year"] == year:
                    return e
        return lst[0]

    def _match(self, idx: dict, q: str, year) -> Optional[dict]:
        """评分制匹配（2026-08-03 v2，替代双向包含贪心）：
        精确 100 → 完整包含 80/70（边界安全）→ 超高置信相似度 60；<60 拒绝（宁缺毋错）。
        修复: 双向包含把 "阿龙" 误配给《龙》、"飞天小女警2016第一季" 误配给《飞天》。
        """
        if len(idx) > FUZZY_SCAN_LIMIT:      # 极端索引下放弃模糊，保请求路径
            return None
        lst = idx.get(q)                      # 精确快路径 O(1)，绝大多数请求走这里
        if lst:
            return self._pick(lst, year)
        best_e, best_s = None, 0
        for k, entries in idx.items():
            s = self._match_score(k, q)
            if s < MATCH_MIN_SCORE:
                continue
            e = self._pick(entries, year)
            if e is None:
                continue
            if year and e.get("year") == year:
                s += 5                       # 年份吻合加分（同分候选优先同年）
            if s > best_s:
                best_s, best_e = s, e
        return best_e

    @staticmethod
    def _match_score(k: str, q: str) -> int:
        """标题匹配评分（k=索引 key，q=查询词，均已 norm）：
        - 100: 完全相等
        - 80 : 查询词完整包含索引标题且边界安全（"飞天小女警2016第一季" ⊃ "飞天小女警"，
              数字/标点边界视为完整词；"阿龙" ⊃ "龙" 因边界为中文被拒）
        - 70 : 索引标题完整包含查询词且边界安全（"流浪地球" ⊂ "流浪地球2"）
        - 60 : 相似度兜底：首尾字均相同 + SequenceMatcher ≥ 0.9（超高置信防误配，
              首尾过滤同时挡住 99%+ 无关 key，避免全表慢速比较）
        - 0  : 拒绝
        """
        if not k or not q:
            return 0
        if k == q:
            return 100

        def is_cjk(c: str) -> bool:
            return "\u4e00" <= c <= "\u9fff"

        def boundary_ok(text: str, start: int, end: int) -> bool:
            b = text[start - 1] if start > 0 else ""
            a = text[end] if end < len(text) else ""
            if (not b or not is_cjk(b)) and (not a or not is_cjk(a)):
                return True
            # 系列衍生连接词白名单：仅放行 "XXX之YYY"（"功夫熊猫之盖世五侠" ⊃ "功夫熊猫"）
            # 其他中文边界（阿龙传 ⊃ 阿龙）一律拒绝，防错配
            edge = b if b and is_cjk(b) else a
            return edge == "之" and not (b and a)

        # 查询词 ⊃ 索引标题（查询词带后缀：年份/季数等附加信息）
        i = q.find(k)
        if i >= 0 and len(k) >= 2 and boundary_ok(q, i, i + len(k)):
            return 80
        # 索引标题 ⊃ 查询词（索引带后缀：续集/年份，如 "流浪地球2" ⊃ "流浪地球"）
        j = k.find(q)
        if j >= 0 and len(q) >= 2 and boundary_ok(k, j, j + len(q)):
            return 70
        # 相似度兜底（超高置信才给分）
        if len(k) >= 4 and len(q) >= 4 and k[0] == q[0] and k[-1] == q[-1]:
            r = SequenceMatcher(None, k, q).ratio()
            if r >= SIM_RATIO_MIN:
                return 60
        return 0

    def lookup(self, title: str, year=None) -> Optional[dict]:
        """标题查找：命中返回 {path,title,year,poster,fanart,nfo}，未命中 None。
        命中缓存 24h；未命中短防抖 5min（NFO_DEBOUNCE_TTL）——分类页每页十几条
        小雅外影片若每次全表扫描 13k 条（~12ms/条）会拖慢请求到 0.4s+。"""
        q, y = self._norm_query(title, year)
        if not q:
            return None
        key = (q, y)
        hit = self._lookup_cache.get(key, _CACHE_MISS)   # 哨兵区分"未缓存"与"缓存了 None"
        if hit is not _CACHE_MISS:
            self._bump(hit is not None)
            return hit
        entry = self._match(self._index, q, y)
        if entry is None:
            self._bump(False)
            # 未命中短防抖缓存（不写 24h 长缓存，索引 6h 重建后新片名可快速生效）
            self._lookup_cache.set(key, None, ttl=NFO_DEBOUNCE_TTL)
            return None
        self._lookup_cache.set(key, entry)
        self._bump(True)
        return entry

    # ------------------------------------------------------------------
    # NFO 解析（惰性，24h 缓存 + 单飞）
    # ------------------------------------------------------------------
    def _fetch_nfo(self, entry: dict) -> dict:
        cands = [entry["nfo"]]
        for c in NFO_CANDIDATES:
            u = BASE_URL + entry["path"] + c
            if u not in cands:
                cands.append(u)
        for u in cands:                       # 首个 200 即停（无论解析成败）
            r = fetch(u, timeout=DIR_TIMEOUT)
            if r is None:
                continue
            try:
                body, status = r.text, r.status_code
            finally:
                r.close()
            if status != 200:
                continue
            parsed = self._parse_nfo(body)
            if parsed:
                parsed["_nfo_url"] = u
            return parsed
        return {}

    def _parse_nfo(self, xml_str: str) -> dict:
        """解析 Kodi NFO：title/year/plot + ratings（TMDB+IMDB 的 value）。
        失败返回 {}，调用方退化为仅 poster+year。"""
        try:
            root = ET.fromstring(xml_str)
        except Exception:
            return {}

        def first_text(tag: str) -> Optional[str]:
            for el in root.iter():
                if el.tag.split("}")[-1].lower() == tag and el.text \
                        and el.text.strip():
                    return el.text.strip()
            return None

        out: dict = {}
        title = first_text("title")
        if title:
            out["title"] = title
        y = first_text("year")
        m = re.search(r"(\d{4})", y or "")
        if m:
            out["year"] = int(m.group(1))
        # 新版 <ratings><rating name="tmdb" value=".."/>...</ratings>
        # 兼容 name="themoviedb" 与 <rating><value>7.0</value></rating> 子节点格式
        for el in root.iter():
            if el.tag.split("}")[-1].lower() != "rating":
                continue
            name = (el.get("name") or "").lower()
            val = el.get("value")
            if not val:                               # 属性缺省 → 读 <value> 子节点
                for sub in el.iter():
                    if sub is not el and sub.tag.split("}")[-1].lower() == "value" \
                            and sub.text and sub.text.strip():
                        val = sub.text.strip()
                        break
            if name in ("tmdb", "themoviedb") and val:
                out["rating"] = _to_float(val)
            elif name == "imdb" and val:
                out["rating_imdb"] = _to_float(val)
        if "rating" not in out:               # 旧版单值 <rating>（Kodi 默认 TMDB）
            rt = first_text("rating")
            if rt:
                out["rating"] = _to_float(rt)
        plot = first_text("plot") or first_text("outline")
        if plot:
            out["plot"] = plot
        return out

    def _resolve_meta(self, entry: dict) -> dict:
        """解析 NFO：先查 24h 缓存，miss 则拉取；解析非空才写缓存。
        空结果不写 24h 缓存，仅进程内 5min 防抖（dict+时间戳），
        CDN 恢复后下一次请求立即重新拉取。"""
        key = entry["path"]
        hit = self._nfo_cache.get(key)
        if hit is not None:
            return hit
        now = time.monotonic()
        if now - self._nfo_debounce.get(key, 0.0) < NFO_DEBOUNCE_TTL:
            return {}                          # 故障期防抖，避免空转请求
        parsed = self._fetch_nfo(entry)
        if parsed:
            self._nfo_cache.set(key, parsed)   # 非空才写 24h 缓存
            self._nfo_debounce.pop(key, None)
        else:
            self._nfo_debounce[key] = now      # 空结果仅防抖，不污染缓存
        return parsed

    # ------------------------------------------------------------------
    # 对外主接口
    # ------------------------------------------------------------------
    def get_meta(self, title: str, year=None) -> dict:
        """按标题取元数据；命中附小雅海报/评分/简介，绝不抛异常。"""
        if not self._ready or not self._index:
            return {"matched": False}
        entry = self.lookup(title, year)
        if entry is None:
            return {"matched": False}
        nfo = self._resolve_meta(entry)
        return {
            "matched": True,
            "title": nfo.get("title") or entry["title"],
            "year": nfo.get("year") or entry["year"],
            "poster": entry["poster"],
            "fanart": entry["fanart"],
            "rating": nfo.get("rating"),
            "rating_imdb": nfo.get("rating_imdb"),
            "plot": nfo.get("plot"),
            "source": "xiaoya",
        }

    def _bump(self, hit: bool) -> None:
        with self._stats_lock:
            if hit:
                self._hits += 1
            else:
                self._misses += 1

    def stats(self) -> dict:
        """运行统计（供日志/排障）。"""
        with self._stats_lock:
            return {"ready": self._ready, "degraded": self._degraded,
                    "truncated": self._truncated, "index": len(self._index),
                    "index_ts": self._idx_ts, "hits": self._hits,
                    "misses": self._misses,
                    "lookup_cache": self._lookup_cache.stats(),
                    "nfo_cache": self._nfo_cache.stats()}


# 模块级单例：main.py `from xiaoya_meta import xiaoya` 即自动开始后台索引
xiaoya = XiaoyaMeta()
