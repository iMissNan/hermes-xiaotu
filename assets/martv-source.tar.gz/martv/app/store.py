"""源池存储与熔断器 —— data/sources.json 原子读写 + 熔断/活跃池/冷却判定。

数据模型（设计文档第四章）:
{
  "sources": [{"name", "base_url", "score", "status": "active|watch|removed",
               "circuit": {"fail_count", "open_until"}, "last_seen"}],
  "repos":   [{"url", "last_ok", "dead_since"}]
}
所有写操作自动原子落盘（tmp+rename）；线程安全（RLock）。
"""

from __future__ import annotations

import json
import os
import threading
import time
from typing import Any, Optional

from utils import (ACTIVE_POOL_ALERT_THRESHOLD, CIRCUIT_FAIL_THRESHOLD,
                   CIRCUIT_OPEN_SECONDS, DEMOTE_AFTER_OPEN,
                   SOURCE_COOLDOWN_SECONDS, SOURCES_PATH,
                   get_logger, write_json_atomic)

DEFAULT_STORE = {"sources": [], "repos": []}


def _probe_alive(s: dict, timeout: float = 8.0) -> bool:
    """降级前独立复核：直连源站 ac=list&pg=1，HTTP 200 且协议键齐全即视为存活。

    与熔断记录解耦（不带 store 状态），仅验证源站网络层可达性。
    历史教训（2026-08-04）：红牛/广速被 429/抖动误熔断 5 次触发降级，
    但独立探测 200 正常——降级前必须复核，避免活跃源被瞬时抖动踢出池。
    """
    try:
        from utils import fetch
        api = (s.get("api_hint") or "").strip()
        if not api:
            base = (s.get("base_url") or "").strip()
            if not base.startswith(("http://", "https://")):
                return False
            api = base + "/api.php/provide/vod/"
        r = fetch(api + "?ac=list&pg=1", timeout=timeout)
        if r is None or getattr(r, "status_code", 0) != 200:
            return False
        import json as _json
        try:
            j = _json.loads(getattr(r, "text", "") or "{}")
        except Exception:
            return False
        # 协议键齐全 = 苹果CMS 列表响应（class 或 list 至少其一）
        return isinstance(j, dict) and ("class" in j or "list" in j)
    except Exception:
        return False


def _default() -> dict:
    return {"sources": [], "repos": []}


class SourceStore:
    """源池唯一读写入口（源引擎/榜单引擎/API 共用同一实例）。

    熔断语义：closed（正常）→ open（连败≥3，open_until 前拒绝一切请求）
    → half-open（到期放行一次探测，成功复位 closed，失败重新 open）。
    """

    def __init__(self, path: str = SOURCES_PATH):
        self.path = path
        self._lock = threading.RLock()
        self._log = get_logger("store")
        self._data = self.load()
        self._mtime = self._file_mtime()

    # ------------------------------------------------------------------ 持久化
    def load(self) -> dict:
        """读 JSON；文件缺失回默认空库，损坏则告警回退（不丢运行）。"""
        if not os.path.exists(self.path):
            return _default()
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                data = json.load(f)
            data.setdefault("sources", [])
            data.setdefault("repos", [])
            return data
        except (json.JSONDecodeError, OSError) as e:
            self._log.warning("sources.json 读取失败(%s)，回落默认空库", e)
            return _default()

    def save(self) -> None:
        """原子落盘（tmp+fsync+rename）。"""
        with self._lock:
            write_json_atomic(self.path, self._data)

    # ------------------------------------------------------------------ 热重载
    def _file_mtime(self) -> Optional[float]:
        try:
            return os.path.getmtime(self.path)
        except OSError:
            return None

    def _maybe_reload(self) -> None:
        """外部进程（cron 源管理引擎）改写 sources.json 后热重载。

        同进程内 save() 会同步更新 _mtime，读路径不会误触发；mtime 变化只来自
        其他进程落盘，此时以文件为准重新载入，保证 API 看到的源池是活的。
        """
        m = self._file_mtime()
        if m is not None and m != self._mtime:
            with self._lock:
                self._data = self.load()
                self._mtime = m

    # ------------------------------------------------------------------ 查询
    def get_source(self, name: str) -> Optional[dict]:
        """按 name 取源记录（引用，供引擎就地更新后 save()）。"""
        self._maybe_reload()
        with self._lock:
            for s in self._data["sources"]:
                if s["name"] == name:
                    return s
            return None

    def all_sources(self) -> list:
        self._maybe_reload()
        with self._lock:
            return list(self._data["sources"])

    def list_sources(self, status: Optional[str] = None) -> list:
        """按状态过滤（active/watch/removed），None=全部。"""
        self._maybe_reload()
        with self._lock:
            if status is None:
                return list(self._data["sources"])
            return [s for s in self._data["sources"] if s.get("status") == status]

    def list_repos(self) -> list:
        self._maybe_reload()
        with self._lock:
            return list(self._data["repos"])

    def stats(self) -> dict:
        """汇总 {total,active,watch,removed,circuit_open}，供 /api/sources。"""
        self._maybe_reload()
        with self._lock:
            srcs = self._data["sources"]
            now = time.time()
            return {
                "total": len(srcs),
                "active": sum(1 for s in srcs if s.get("status") == "active"),
                "watch": sum(1 for s in srcs if s.get("status") == "watch"),
                "removed": sum(1 for s in srcs if s.get("status") == "removed"),
                "circuit_open": sum(1 for s in srcs
                                    if (c := (s.get("circuit") or {}).get("open_until")) and now < c),
            }

    # ------------------------------------------------------------------ 写入
    def upsert_source(self, source: dict) -> None:
        """按 name 合并写入/更新一条源记录（缺失 circuit 自动补全），原子落盘。"""
        with self._lock:
            for s in self._data["sources"]:
                if s["name"] == source["name"]:
                    s.update(source)
                    s.setdefault("circuit", {"fail_count": 0, "open_until": None})
                    break
            else:
                source.setdefault("circuit", {"fail_count": 0, "open_until": None})
                self._data["sources"].append(source)
            self.save()

    def set_status(self, name: str, status: str) -> None:
        """状态迁移：active/watch/removed（removed=移出活跃池）。"""
        with self._lock:
            s = self._require(name)
            s["status"] = status
            s["last_seen"] = time.time()
            self.save()

    def upsert_repo(self, url: str, last_ok: Optional[float] = None,
                    dead_since: Optional[float] = None) -> None:
        """写入/更新仓库记录（url 为主键）。"""
        with self._lock:
            for r in self._data["repos"]:
                if r["url"] == url:
                    if last_ok is not None:
                        r["last_ok"] = last_ok
                    if dead_since is not None:
                        r["dead_since"] = dead_since
                    break
            else:
                self._data["repos"].append({"url": url, "last_ok": last_ok,
                                            "dead_since": dead_since})
            self.save()

    def _require(self, name: str) -> dict:
        s = self.get_source(name)
        if s is None:  # 熔断接口容忍未知源：自动补一条 watch 占位，避免统计错位
            self._log.warning("未知源 %s 触发熔断接口，自动补位", name)
            s = {"name": name, "base_url": "", "score": 0.0, "status": "watch",
                 "circuit": {"fail_count": 0, "open_until": None},
                 "last_seen": time.time()}
            self._data["sources"].append(s)
        return s

    # ------------------------------------------------------------------ 熔断器
    def record_failure(self, name: str) -> dict:
        """记录一次连败。closed 态连败达阈值 → open（open_until=now+10min）；
        half-open 探测失败 → 重新 open。返回该源 circuit 字段。"""
        if not isinstance(name, str) or not name:
            # 防御：非字符串源名（如误传 Future）会污染 _data 导致 save() 崩溃
            self._log.warning("record_failure 收到非法源名 %r，忽略", name)
            return {"fail_count": 0, "open_until": None}
        with self._lock:
            s = self._require(name)
            c = s.setdefault("circuit", {"fail_count": 0, "open_until": None})
            now = time.time()
            if c.get("open_until") and now < c["open_until"]:
                c["open_until"] = now + CIRCUIT_OPEN_SECONDS  # 半开探测失败，重新熔断
                self._log.warning("半开探测失败: %s 重新熔断 %d 秒",
                                  name, CIRCUIT_OPEN_SECONDS)
            else:
                c["fail_count"] = c.get("fail_count", 0) + 1
                if c["fail_count"] >= CIRCUIT_FAIL_THRESHOLD:
                    c["open_until"] = now + CIRCUIT_OPEN_SECONDS
                    c["open_count"] = c.get("open_count", 0) + 1
                    self._log.warning("熔断: %s 连败 %d 次 → 熔断 %d 分钟（累计第 %d 次）",
                                      name, c["fail_count"],
                                      CIRCUIT_OPEN_SECONDS // 60, c["open_count"])
                    # 反复熔断（累计 ≥DEMOTE_AFTER_OPEN 次）→ 自动移出活跃池（降级 watch），
                    # 不再占用检索/播放资源；源恢复后由 explore 重新评估入池
                    if (c["open_count"] >= DEMOTE_AFTER_OPEN
                            and s.get("status") == "active"):
                        # 降级前独立复核：释放锁直连探针，防源站瞬时抖动误伤
                        # （历史教训：红牛/广速 2026-08-04 被 429/抖动误降级，探针实测 200 正常）
                        probe_src = dict(s)
                        self._lock.release()
                        try:
                            alive = _probe_alive(probe_src)
                        finally:
                            self._lock.acquire()
                        if alive:
                            c["fail_count"] = 0
                            c["open_until"] = None
                            self._log.warning(
                                "降级复核: %s 探针存活（%s），取消降级",
                                name, probe_src.get("base_url") or "?")
                            s["last_seen"] = now
                            self.save()
                            return c
                        s["status"] = "watch"
                        s["score"] = max(0.0, (s.get("score") or 0.0) * 0.5)
                        self._log.warning("降级: %s 反复熔断 %d 次且探针确认失效 → 移出活跃池（watch）",
                                          name, c["open_count"])
            s["last_seen"] = now
            self.save()
            return c

    def record_success(self, name: str) -> None:
        """成功复位：fail_count 清零、open_until 置空（closed 态）。"""
        if not isinstance(name, str) or not name:
            # 防御：非字符串源名（如误传 Future）会污染 _data 导致 save() 崩溃
            self._log.warning("record_success 收到非法源名 %r，忽略", name)
            return
        with self._lock:
            s = self._require(name)
            c = s.setdefault("circuit", {"fail_count": 0, "open_until": None})
            c["fail_count"] = 0
            c["open_until"] = None
            s["last_seen"] = time.time()
            self.save()

    def is_circuit_open(self, name: str) -> bool:
        """True=熔断中禁止请求；False=可请求（含 half-open 放行探测）。"""
        with self._lock:
            s = self.get_source(name)
            if s is None:
                return False
            o = (s.get("circuit") or {}).get("open_until")
            return bool(o) and time.time() < o

    def probe_allowed(self, name: str) -> bool:
        """half-open 判定：熔断期内返回 False；到期放行一次探测
        （探测结果由 record_success / record_failure 决定复位或重熔）。"""
        return not self.is_circuit_open(name)

    # ------------------------------------------------------------------ 活跃池
    def active_count(self) -> int:
        with self._lock:
            return sum(1 for s in self._data["sources"]
                       if s.get("status") == "active")

    def pool_alert(self) -> tuple:
        """活跃池 <3 告警判定 → (alert, message)。"""
        n = self.active_count()
        if n < ACTIVE_POOL_ALERT_THRESHOLD:
            msg = ("活跃池仅剩 %d 个源(<%d)，需自动更新/探索补源"
                   % (n, ACTIVE_POOL_ALERT_THRESHOLD))
            self._log.warning(msg)
            return True, msg
        return False, "活跃源 %d 个，正常" % n

    # ------------------------------------------------------------------ 冷却
    def should_retest(self, name: str) -> bool:
        """watch（降级）源冷却后重测；冷却时长随 low_score 指数退避
        （24h × 2^low_score，上限 7 天）—— 连败越久重测越稀疏，避免反复白费探测。
        active/removed 不触发。"""
        with self._lock:
            s = self.get_source(name)
            if s is None or s.get("status") != "watch":
                return False
            last = s.get("last_seen") or 0
            n = max(int(s.get("low_score", 0)), 0)
            cooldown = min(SOURCE_COOLDOWN_SECONDS * (2 ** n), 7 * 86400)
            return (time.time() - last) >= cooldown

