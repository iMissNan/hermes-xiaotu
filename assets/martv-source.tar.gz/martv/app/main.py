"""Mars TV FastAPI 后端入口 —— 统一 {code,data,msg}，9 端点 + 缓存/单飞/熔断/超时。

设计依据: docs/superpowers/specs/2026-08-02-martv-design-v3.md 第二章 API 契约。
依赖核心库（接口冻结，零改动）: utils.py（fetch/常量/LRU 单飞缓存）
+ store.py（熔断器/源池原子读写）+ source_engine.py（_cms_search/_cms_get/normalize_domain/SEM）。

运行约束（第二章原文）:
- uvicorn 单 worker；全局 Semaphore(6) 限上游并发（复用 source_engine.SEM）
- 单源搜索 5s（SOURCE_TIMEOUT）、搜索聚合总 8s 兜底（SEARCH_TOTAL_BUDGET）
- 搜索 LRU 缓存 TTL 20 分钟（10-30 分钟区间取 20）+ 同键单飞 + 全挂返 24h 缓存
- 线路预检单线 3s、并发 ≤4（CHECK_GATE）；HEAD 被拒 GET 兜底 + GET+Range 复核
- 线路预检结果按 URL 缓存 15 分钟；单源连败 3 次熔断 10 分钟（store 熔断器）
- 活跃池 <3 → /api/health alert=true；日志全部进 /opt/martv/logs/backend.log

响应码: 0=成功 1=上游失败/不可用 2=参数错误 3=未找到。
端点超出设计清单的部分：/api/categories（前端 home.js 已调用，返回静态分类）
+ /api/category（分类浏览聚合，分类树驱动多源拉取，见 category_engine.py）。
"""

from __future__ import annotations

import json
import hashlib
import logging
import os
import re
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import asynccontextmanager
from typing import Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response

from hot_engine import _norm_title  # noqa: E402  片名归一化（聚合去重共用）
from xiaoya_meta import xiaoya  # noqa: E402       小雅元数据引擎（import 即后台建索引，6h 重建）
from source_engine import (  # noqa: E402
    CMS_STD_PATH, SEM, _cms_get, _cms_search, normalize_domain)
from store import SourceStore  # noqa: E402
from category_engine import (  # noqa: E402  分类浏览引擎（7 类体系唯一来源）
    CAT_PAGE_SIZE, CATEGORY_NAMES, CATEGORY_TREE, category_loader)
from crawler import DB_PATH as VODS_DB, connect as vods_connect  # noqa: E402 本地影视库
from spider_client import spider_search, spider_detail  # noqa: E402  TVBox drpy2 spider 源聚合（2026-08 新增）
from utils import (  # noqa: E402
    ACTIVE_POOL_ALERT_THRESHOLD, CHECK_CONCURRENCY, CHECK_TIMEOUT, DATA_DIR,
    LRUCache, LRU_MAXSIZE, SEARCH_TOTAL_BUDGET, SEMAPHORE_LIMIT,
    SOURCE_TIMEOUT, fetch, get_logger)

# ---------------------------------------------------------------------------
# 常量（第二章 / 第四章）
# ---------------------------------------------------------------------------
SEARCH_CACHE_TTL = 1200          # 搜索缓存 20 分钟（10-30 分钟区间取 20）
DETAIL_CACHE_TTL = 1200          # 详情缓存 20 分钟（同预算）
CHECK_CACHE_TTL = 900            # 线路预检缓存 15 分钟（按线路 URL）
STALE_TTL = 86400                # 全挂返缓存兜底保留 24h
HOT_CACHE_SECONDS = 30           # hot.json 内存缓存 30s（mtime 变化即时失效）

CATEGORIES = list(CATEGORY_NAMES)      # 7 个一级分类（电影/电视剧/综艺/动漫/少儿/纪录片/短剧）
TYPE_RULES = {                   # 搜索 type 筛选 → vod_class 关键字
    "电影": ("电影",),
    "电视剧": ("连续剧", "电视剧", "剧集"),
    "动漫": ("动漫", "动画"),
    "综艺": ("综艺",),
    "纪录片": ("纪录",),
    "少儿": ("少儿", "儿童", "亲子"),
    "短剧": ("短剧", "微短剧"),
}
CAT_CACHE_TTL = 3600              # 分类聚合缓存 60 分钟（分类页时效要求低）
SEARCH_MAX_PER_SOURCE = 20       # 单源最多取 20 条
SEARCH_MAX_TOTAL = 100           # 聚合后最多返回 100 条

HOT_PATH = os.path.join(DATA_DIR, "hot.json")

store = SourceStore()
_log = get_logger("api")
_cache = LRUCache(maxsize=LRU_MAXSIZE)   # 搜索/详情/预检共用 LRU ≤200
_check_gate = threading.Semaphore(CHECK_CONCURRENCY)
_stale_lock = threading.Lock()
_search_stale = {}                        # key -> (ts, data)，全挂兜底快照
_hot_lock = threading.Lock()
_hot_cache = {"ts": 0.0, "mtime": 0.0, "data": None}
_start_ts = time.time()


class SearchUnavailable(Exception):
    """聚合搜索全部源失败（load 失败也由 LRU 单飞共享给等待者）。"""


# ---------------------------------------------------------------------------
# 统一响应 {code,data,msg}
# ---------------------------------------------------------------------------
def ok(data=None, msg: str = "") -> dict:
    return {"code": 0, "data": data, "msg": msg}


def fail(code: int, msg: str, data=None) -> dict:
    return {"code": code, "data": data, "msg": msg}


def _json(payload: dict, cache: bool = False, max_age: int = 1200):
    headers = {}
    if cache:
        headers["Cache-Control"] = "public, max-age=%d" % max_age
    return JSONResponse(content=payload, headers=headers)


# ---------------------------------------------------------------------------
# 字段归一化助手
# ---------------------------------------------------------------------------
def _norm_year(v) -> Optional[int]:
    if v is None:
        return None
    m = re.search(r"(\d{4})", str(v))
    return int(m.group(1)) if m else None


def _to_score(v) -> Optional[float]:
    try:
        return round(float(v), 1) if v not in (None, "") else None
    except (TypeError, ValueError):
        return None


def _cms_list_of(j) -> list:
    """CMS 搜索/详情响应 → list 段（兼容 list/data 键与裸对象）。"""
    lst = (j.get("list") if isinstance(j, dict) else None) or \
          (j.get("data") if isinstance(j, dict) else None)
    if isinstance(lst, dict):
        return [lst]
    if isinstance(lst, list):
        return [x for x in lst if isinstance(x, dict)]
    return []


def _cms_item(src_name: str, e) -> Optional[dict]:
    """CMS list 条目 → 前端统一字段（id = 来源:vod_id 主键，详情可直接查）。"""
    if not isinstance(e, dict):
        return None
    vid = e.get("vod_id")
    if vid is None:
        return None
    cls = str(e.get("vod_class") or "").strip()
    return {
        "id": "%s:%s" % (src_name, vid),
        "title": str(e.get("vod_name") or "").strip(),
        "poster": str(e.get("vod_pic") or ""),
        "score": _to_score(e.get("vod_score")),
        "year": _norm_year(e.get("vod_year")),
        "type": cls.split(",")[0].strip() if cls else "",
        "area": str(e.get("vod_area") or ""),
        "remarks": str(e.get("vod_remarks") or ""),
        "source": src_name,
        "vod_id": str(vid),
    }


# ---------------------------------------------------------------------------
# 搜索：多源聚合（LRU 单飞 loader；单源 5s；总 8s 兜底；全挂抛异常）
# ---------------------------------------------------------------------------
def _search_loader(word: str, type_filter: str) -> dict:
    t0 = time.monotonic()
    deadline = t0 + SEARCH_TOTAL_BUDGET
    srcs = [s for s in store.list_sources("active")
            if not store.is_circuit_open(s["name"])]
    if not srcs:
        raise SearchUnavailable("当前无活跃源（活跃池 <3，需自动更新/探索补源）")
    srcs.sort(key=lambda s: s.get("score") or 0.0, reverse=True)

    def work(s):
        api = s.get("api_hint") or (s.get("base_url") or "") + CMS_STD_PATH
        j = _cms_search(api, word)          # 内部 SEM(6) 闸 + 5s 双超时
        if j is None:
            return None
        return _cms_list_of(j)[:SEARCH_MAX_PER_SOURCE]

    names_all = [s["name"] for s in srcs]
    results, used, failed = [], 0, []
    with ThreadPoolExecutor(max_workers=min(SEMAPHORE_LIMIT, len(srcs))) as ex:
        futs = {}
        for s in srcs:
            if time.monotonic() + 1.0 > deadline:      # 预算不足，不再起新任务
                break
            futs[ex.submit(work, s)] = s["name"]
        attempted = set(futs.values())
        finished = set()
        try:
            for fut in as_completed(futs, timeout=max(0.2, deadline - time.monotonic())):
                name = futs[fut]
                finished.add(name)
                items = fut.result()
                if items is not None:
                    used += 1
                    store.record_success(name)
                    for e in items:
                        it = _cms_item(name, e)
                        if it is not None and it["title"]:
                            results.append(it)
                else:
                    failed.append(name)
                    store.record_failure(name)
        except TimeoutError:
            ex.shutdown(wait=False, cancel_futures=True)
    # 未尝试（预算不足）或超时未返回的源也计失败
    for name in names_all:
        if name not in attempted or name not in finished:
            failed.append(name)
    failed = list(dict.fromkeys(failed))

    if not results and failed:
        raise SearchUnavailable("无活跃源可用/全部失败（%d 个源：%s）"
                                % (len(failed), "、".join(failed[:5])))

    # 多源去重：片名+年份 模糊匹配，保留评分/海报更优者
    best = {}
    for it in results:
        key = (_norm_title(it["title"]), it.get("year"))
        old = best.get(key)
        if old is None or (it.get("score") or 0) > (old.get("score") or 0) \
                or (it.get("poster") and not old.get("poster")):
            best[key] = it
    items = sorted(best.values(), key=lambda x: x.get("score") or 0.0,
                   reverse=True)

    # 类型筛选（电影/电视剧/动漫/综艺/纪录片，其余按 class 子串匹配）
    if type_filter:
        rules = TYPE_RULES.get(type_filter) or (type_filter,)
        items = [it for it in items
                 if any(r in (it.get("type") or "") for r in rules)]

    return {
        "list": items[:SEARCH_MAX_TOTAL],
        "total": len(items[:SEARCH_MAX_TOTAL]),
        "sources_used": used,
        "sources_failed": failed,
        "elapsed": round(time.monotonic() - t0, 2),
        "stale": False,
    }


def _stale_get(key) -> Optional[dict]:
    with _stale_lock:
        item = _search_stale.get(key)
        if item is None:
            return None
        ts, data = item
        if time.time() - ts > STALE_TTL:
            _search_stale.pop(key, None)
            return None
        return data


def _stale_set(key, data) -> None:
    with _stale_lock:
        _search_stale[key] = (time.time(), data)
        while len(_search_stale) > LRU_MAXSIZE:
            _search_stale.pop(next(iter(_search_stale)))


import hashlib
import urllib.parse as _up2  # noqa: E402

# ---------------------------------------------------------------------------
# TMDB 海报回退（2026-08-03：小雅只收录新片，老剧/日韩剧海报命中率低；
# TMDB 全量覆盖，走 daili.smdhb.com 代理，命中结果回写 vods.poster 越用越全）
# ---------------------------------------------------------------------------
TMDB_PROXY = "https://daili.smdhb.com/3"
TMDB_KEY = "2a817082784309aefeff00649c1c8664"
TMDB_POSTER = "https://image.tmdb.org/t/p/w342/"   # 注意尾部斜杠！w342 后必须接 / 才能拼 poster_path
_tmdb_cache = LRUCache(maxsize=512)
_TMDB_CACHE_TTL = 86400 * 7   # 命中缓存 7 天（不命中短 1h）


_VARIANT_RE = re.compile(
    r"(第\s*[一二三四五六七八九十0-9]+\s*(季|部|集)"
    r"|[一二三四五六七八九十0-9]+\s*季"
    r"|[0-9]+"
    r")\s*$")


def _strip_variant(t: str) -> str:
    """剥离片名变体：'爱情公寓第五季'→'爱情公寓'；'爱情公寓4'→'爱情公寓'；
    '爱情公寓番外篇：辣味英雄传 第二季'→'爱情公寓'；'女力报到：爱情公寓'→'女力报到'。
    依次：冒号副标题取前段 → 番外/外传后缀 → 季/数字后缀。
    剥离后为空（如纯数字片名 '1988'）返回原串。"""
    s = (t or "").strip()
    if not s:
        return s
    head = re.split(r"[:：]", s, maxsplit=1)[0].strip()
    if head:
        s = head
    s2 = re.sub(r"(番外篇|番外|外传|前传|特别篇)$", "", s).strip()
    if s2:
        s = s2
    base = _VARIANT_RE.sub("", s).strip()
    if base and base != t:
        return base
    return s if s != t else t


def _tmdb_poster(title: str, year=None) -> Optional[str]:
    """TMDB 搜索补海报：movie/tv 两型，标题精确匹配；
    变体名（第X季/X季/裸数字后缀）剥离为基础名搜索，且跳过年份校验（同系列海报通用）。
    base 与变体共享缓存：'爱情公寓' 查过一次，'爱情公寓4/第一季' 直接命中。"""
    if not title or len(title) < 2:
        return None
    t = title.strip()
    base = _strip_variant(t)
    variant = base != t
    q = base  # 变体用基础名搜索
    try:
        # 命中缓存 7 天；未命中 1h 防抖
        hit = _tmdb_cache.get(t)
        if hit is None and variant:
            hit = _tmdb_cache.get(base)
        if hit is not None:
            return hit if hit != _MISS_TMDB else None
        best = None
        import urllib.request  # noqa: F401  局部导入（main.py 顶层无 urllib）
        for media in ("tv", "movie"):
            u = ("%s/search/%s?api_key=%s&query=%s&language=zh-CN"
                 % (TMDB_PROXY, media, TMDB_KEY, _up2.quote(q)))
            try:
                with urllib.request.urlopen(u, timeout=6) as r:
                    d = json.loads(r.read())
            except Exception:
                continue
            for it in (d.get("results") or [])[:6]:
                name = str(it.get("name") or it.get("title") or "")
                if not name:
                    continue
                # 精确标题匹配（忽略首尾空格）
                if name.strip() != q:
                    continue
                y = str(it.get("first_air_date") or it.get("release_date") or "")[:4]
                # 变体名跳过年份校验（'爱情公寓4' 用主剧海报）；精确名仍校验
                if year and y and y != str(year) and not variant:
                    continue
                pp = it.get("poster_path")
                if pp:
                    best = TMDB_POSTER + pp.lstrip("/")
                    break
            if best:
                break
        _tmdb_cache.set(t, best or _MISS_TMDB,
                        ttl=_TMDB_CACHE_TTL if best else 3600)
        if variant:
            _tmdb_cache.set(base, best or _MISS_TMDB,
                            ttl=_TMDB_CACHE_TTL if best else 3600)
        return best
    except Exception:
        return None


_MISS_TMDB = "\x00miss"  # 哨兵：查过但没海报，防反复打 TMDB


def _tmdb_lookup_id(title: str, year=None):
    """TMDB 搜索返回 (media_type, tmdb_id)；无命中返回 None。变体名用基础名。"""
    if not title or len(title) < 2:
        return None
    q = _strip_variant(title.strip())
    import urllib.request  # noqa: F401  局部导入
    for media in ("tv", "movie"):
        u = ("%s/search/%s?api_key=%s&query=%s&language=zh-CN"
             % (TMDB_PROXY, media, TMDB_KEY, _up2.quote(q)))
        try:
            with urllib.request.urlopen(u, timeout=6) as r:
                d = json.loads(r.read())
        except Exception:
            continue
        for it in (d.get("results") or [])[:6]:
            name = str(it.get("name") or it.get("title") or "")
            if name.strip() != q:
                continue
            y = str(it.get("first_air_date") or it.get("release_date") or "")[:4]
            if year and y and y != str(year):
                continue
            return (media, it.get("id"))
    return None


def _tmdb_similar(title: str, year=None, limit: int = 8) -> list:
    """猜你喜欢：TMDB similar 关联 → 本地库匹配同标题（含海报），库内无则回退标题 id。"""
    if not title or len(title) < 2:
        return []
    t = title.strip()
    cache_key = "sim:" + t
    hit = _tmdb_cache.get(cache_key)
    if hit is not None:
        return [] if hit == _MISS_TMDB else hit
    try:
        found = _tmdb_lookup_id(t, year)
        if found is None:
            _log.info("similar 无 TMDB id: %s", t)
            _tmdb_cache.set(cache_key, _MISS_TMDB, ttl=3600 * 24)
            return []
        media, tid = found
        import urllib.request  # noqa: F401
        u = ("%s/%s/%s/similar?api_key=%s&language=zh-CN&page=1"
             % (TMDB_PROXY, media, tid, TMDB_KEY))
        try:
            with urllib.request.urlopen(u, timeout=6) as r:
                d = json.loads(r.read())
            _log.info("similar %s(%s) -> %d 候选", t, tid, len(d.get("results") or []))
        except Exception as e:
            _log.warning("similar 请求失败 %s: %s", t, e)
            return []
        titles = []
        for it in (d.get("results") or []):
            nm = str(it.get("name") or it.get("title") or "").strip()
            if nm and nm != t:
                titles.append((nm, str(it.get("first_air_date") or it.get("release_date") or "")[:4]))
            if len(titles) >= limit:
                break
        out = []
        try:
            conn = vods_connect()
            try:
                for nm, ny in titles:
                    row = conn.execute(
                        "SELECT title, year, type, poster, source, vod_id FROM vods "
                        "WHERE title = ? ORDER BY health DESC, score DESC LIMIT 1",
                        (nm,)).fetchone()
                    if row:
                        out.append({"id": "%s:%s" % (row[4], row[5]), "title": row[0],
                                    "year": row[1], "type": row[2],
                                    "poster": _fix_poster_url(row[3] or "")})
                    else:
                        out.append({"id": ("t:%s|%s" % (nm, ny)) if ny else ("t:%s" % nm),
                                    "title": nm, "year": ny or None, "type": "", "poster": ""})
            finally:
                conn.close()
        except Exception:
            pass
        _tmdb_cache.set(cache_key, out, ttl=_TMDB_CACHE_TTL)
        return out
    except Exception:
        return []


def _fix_poster_url(u: str) -> str:
    """修正历史遗留的错误海报 URL：'…/w3425Rhn…'（缺斜杠）→ '…/w342/5Rhn…'。"""
    if u and "image.tmdb.org/t/p/w342" in u and "/t/p/w342/" not in u:
        return u.replace("/t/p/w342", "/t/p/w342/", 1)
    return u


def _ensure_poster(item: dict) -> None:
    """单条补海报：DB 有 poster 直接用；否则 小雅 → TMDB 回退链。
    补到即回写 vods 表（越用越全，下次查询直接命中）。"""
    if item.get("poster"):
        return
    t = (item.get("title") or "").strip()
    if not t:
        return
    try:
        m = xiaoya.lookup(t, item.get("year"))
        if m is None:
            m = xiaoya.lookup(t, None)
        poster = (m or {}).get("poster") or ""
        if not poster:
            poster = _tmdb_poster(t, item.get("year")) or ""
        if poster:
            item["poster"] = poster
            try:
                conn = vods_connect()
                try:
                    conn.execute(
                        "UPDATE vods SET poster = ? WHERE title = ? AND poster = ''",
                        (poster, t))
                    conn.commit()
                finally:
                    conn.close()
            except Exception:
                pass
    except Exception:
        pass


def _tmdb_poster_fill(it: dict) -> dict:
    """并发版 TMDB 海报回退（仅缺 poster 时调用）。"""
    try:
        if not it.get("poster"):
            p = _tmdb_poster(it.get("title"), it.get("year"))
            if p:
                it["poster"] = p
    except Exception:
        pass
    return it


# ---------------------------------------------------------------------------
# 详情：线路数组解析 + 来源标识
# ---------------------------------------------------------------------------
def _parse_play(play_from: str, play_url: str, src_name: str) -> list:
    """macCMS vod_play_url → [{name, source, episodes:[{name,url}]}]。

    两种形态兼容：
      1) vod_play_from 独立给线路名：from="线路1$$$线路2"，url="u1#u2$$$v1#v2"
      2) 线路名内嵌：url="线路1$u1#u2$$$线路2$v1#v2"
    每集可为 "名称$地址" 或裸地址；线路带来源标识（前端忽略多余字段）。
    """
    lines = []
    names = [x.strip() for x in (play_from or "").split("$$$") if x.strip()]
    segs = [x for x in (play_url or "").split("$$$") if x.strip()]
    for i, seg in enumerate(segs):
        lname, ep_str = "", seg
        if i < len(names) and names[i]:
            lname, ep_str = names[i], seg
        elif "$" in seg:
            first, _, rest = seg.partition("$")
            lname, ep_str = first.strip(), rest
        lname = lname or ("线路%d" % (len(lines) + 1))
        eps = []
        for j, ep in enumerate(ep_str.split("#")):
            ep = ep.strip()
            if not ep:
                continue
            label, u = "", ep
            if "$" in ep:
                label, _, u = ep.partition("$")
            u = u.strip()
            if not u:
                continue
            eps.append({"name": label.strip() or ("第%d集" % (j + 1)), "url": u})
        if eps:
            lines.append({"name": lname, "source": src_name, "episodes": eps})
    return lines


def _fetch_detail(src_name: str, vid: str) -> Optional[dict]:
    """单源详情：ac=detail&ids=vid；失败 record_failure，成功 record_success。"""
    s = store.get_source(src_name)
    if s is None or store.is_circuit_open(src_name):
        return None
    api = s.get("api_hint") or (s.get("base_url") or "") + CMS_STD_PATH
    j, _ = _cms_get(api, {"ac": "detail", "ids": str(vid)},
                    timeout=SOURCE_TIMEOUT)
    lst = _cms_list_of(j) if j is not None else []
    if not lst or not isinstance(lst[0], dict):
        store.record_failure(src_name)
        return None
    store.record_success(src_name)
    e = lst[0]
    intro = re.sub(r"<[^>]+>", " ", str(e.get("vod_content")
                                          or e.get("vod_blurb") or ""))
    intro = re.sub(r"\s+", " ", intro).strip()[:500]
    cls = str(e.get("vod_class") or "").strip()
    return {
        "id": "%s:%s" % (src_name, vid),
        "title": str(e.get("vod_name") or "").strip(),
        "poster": str(e.get("vod_pic") or ""),
        "score": _to_score(e.get("vod_score")),
        "year": _norm_year(e.get("vod_year")),
        "area": str(e.get("vod_area") or ""),
        "type": cls.split(",")[0].strip() if cls else "",
        "director": str(e.get("vod_director") or ""),
        "actors": str(e.get("vod_actor") or ""),
        "remarks": str(e.get("vod_remarks") or ""),
        "intro": intro,
        "source": src_name,
        "lines": _parse_play(str(e.get("vod_play_from") or ""),
                             str(e.get("vod_play_url") or ""), src_name),
    }


def _db_same_title_alts(item_id: str) -> list:
    """单源详情失败时，从 vods 库找同标题的其他源条目（多源容错）。
    返回 [(source, vod_id), ...]，按 health/score 降序。"""
    try:
        conn = vods_connect()
        try:
            row = conn.execute("SELECT title FROM vods WHERE id = ?",
                               (item_id,)).fetchone()
            if not row:
                return []
            rows = conn.execute(
                "SELECT source, vod_id FROM vods WHERE title = ? AND id != ? "
                "ORDER BY health DESC, score DESC NULLS LAST LIMIT 6",
                (row[0], item_id)).fetchall()
            return [(r[0], str(r[1])) for r in rows]
        finally:
            conn.close()
    except Exception:
        return []


def _merge_alt_lines(main: dict, item_id: str) -> dict:
    """主源详情成功后，聚合同片其他源线路（跨源切换，前端可直接切源）。
    线路名加源前缀 '源名·线路名' 防多源重名；并发 ≤4，单源失败跳过。"""
    try:
        alts = _db_same_title_alts(item_id)
        if not alts:
            return main
        seen_srcs = {main.get("source") or ""}
        extra = []
        import concurrent.futures as _cfm
        with _cfm.ThreadPoolExecutor(max_workers=4) as ex:
            jobs = {ex.submit(_fetch_detail, src, vid): (src, vid)
                    for src, vid in alts[:4]}
            for f in _cfm.as_completed(jobs):
                try:
                    d2 = f.result()
                except Exception:
                    continue
                if not d2:
                    continue
                src2 = d2.get("source") or jobs[f][0]
                if src2 in seen_srcs:
                    continue
                seen_srcs.add(src2)
                for ln in d2.get("lines") or []:
                    nm = ln.get("name") or "线路"
                    extra.append(dict(ln, name="%s·%s" % (src2, nm)))
        if extra:
            main_src = main.get("source") or ""
            main["lines"] = (main.get("lines") or []) + extra
            if len(seen_srcs) > 1:
                main["lines"] = [
                    dict(ln, name="%s·%s" % (main_src, ln.get("name") or "线路"))
                    if ln.get("source") == main_src else ln
                    for ln in main["lines"]]
        return main
    except Exception:
        return main


def _detail_loader(item_id: str) -> dict:
    """id 解析：
      1) "t:标题|年份" / 裸标题 → 标题回退（热榜海报点击、/api/detail/1 冒烟）
      2) "来源名:vod_id" → 直接查该源详情（搜索结果的 id 主键）
    标题回退走聚合搜索缓存，最多尝试 3 个候选源。
    """
    item_id = item_id.strip()
    title, year = None, None
    if item_id.startswith("spider:"):
        # spider:脚本名:vod_id → 引擎取详情（TVBox drpy2 协议）
        rest = item_id[len("spider:"):]
        script, _, vid = rest.partition(":")
        if not script or not vid:
            raise SearchUnavailable("无效 spider 片源 id")
        det = spider_detail(script, vid)
        if det is None:
            raise SearchUnavailable("spider 源 %s 详情获取失败" % script)
        title = (det.get("vod_name") or "").strip()
        if not title:
            raise SearchUnavailable("spider 源 %s 详情无片名" % script)
        return {
            "id": item_id,
            "title": title,
            "year": (det.get("vod_year") or "").strip(),
            "poster": (det.get("vod_pic") or "").strip(),
            "remarks": (det.get("vod_remarks") or "").strip(),
            "plot": (det.get("vod_content") or "").strip(),
            "actor": (det.get("vod_actor") or "").strip(),
            "director": (det.get("vod_director") or "").strip(),
            "lines": _parse_play(str(det.get("vod_play_from") or ""),
                                 str(det.get("vod_play_url") or ""),
                                 script),
            "spider": True,
        }
    if item_id.startswith("t:"):
        title = item_id[2:]
        if "|" in title:
            title, _, ys = title.partition("|")
            year = _norm_year(ys)
    elif ":" in item_id:
        src_name, _, vid = item_id.partition(":")
        d = _fetch_detail(src_name.strip(), vid.strip())
        if d is not None:
            return _merge_alt_lines(d, item_id)  # 聚合同片其他源线路（跨源切换）
        # 单源失败（熔断/超时/源站挂）→ DB 找同标题其他源条目容错（多源冗余，并发探测）
        alts = _db_same_title_alts(item_id)
        if alts:
            import concurrent.futures as _cfe
            with _cfe.ThreadPoolExecutor(max_workers=4) as ex:
                jobs = {ex.submit(_fetch_detail, src2, vid2): (src2, vid2)
                        for src2, vid2 in alts[:4]}
                for f in _cfe.as_completed(jobs):
                    try:
                        d2 = f.result()
                    except Exception:
                        continue
                    if d2 is not None:
                        return _merge_alt_lines(d2, item_id)  # 容错成功也聚合其他源线路
        raise SearchUnavailable("源 %s 详情获取失败（已尝试 %d 个备选源）"
                                % (src_name, len(alts)))
    else:
        title = item_id
    title = (title or "").strip()
    if not title:
        raise SearchUnavailable("无效片源 id")
    try:
        data = _cache.get_or_set(("s", title, ""),
                                 lambda: _search_loader(title, ""),
                                 ttl=SEARCH_CACHE_TTL)
    except SearchUnavailable as e:
        raise SearchUnavailable("无活跃源，无法查询「%s」详情：%s" % (title, e))
    cands = [it for it in data["list"]
             if year and it.get("year") == year] or data["list"]
    for cand in cands[:3]:
        d = _fetch_detail(cand["source"], cand["vod_id"])
        if d is not None:
            return d
    raise SearchUnavailable("各源均无法获取「%s」详情" % title)


# ---------------------------------------------------------------------------
# 线路预检：HEAD 优先（被拒 GET 兜底）+ GET+Range 复核；并发 ≤4；单线 3s
# ---------------------------------------------------------------------------
def _source_by_host(url: str) -> Optional[str]:
    """线路 URL 域名 → 源名（best-effort 归因；失效线路累计降级该源）。"""
    dom = normalize_domain(url)
    if not dom:
        return None
    for s in store.all_sources():
        if s.get("status") == "removed":
            continue
        if normalize_domain(s.get("base_url") or "") == dom:
            return s["name"]
        hint = s.get("api_hint") or ""
        if hint and normalize_domain(hint) == dom:
            return s["name"]
    return None


def _check_line(url: str, source: str = "", referer: str = "") -> dict:
    """单线预检：HEAD（utils 内置 403/405/501/异常 → GET 兜底）；
    仍失败且预算允许 → GET+Range(0-1) 复核（防盗链/非标准 HEAD 服务器）。"""
    t0 = time.monotonic()
    src_name = source or _source_by_host(url)
    with _check_gate:
        r = fetch(url, method="HEAD", timeout=CHECK_TIMEOUT,
                  referer=referer or None)
        status, method = None, "HEAD"
        if r is None:
            okv = False
        elif r.status_code in (200, 206):
            status, okv = r.status_code, True
        elif time.monotonic() - t0 < CHECK_TIMEOUT - 0.5:
            r.close()
            r = fetch(url, method="GET", timeout=CHECK_TIMEOUT - (time.monotonic() - t0),
                      referer=referer or None, range_bytes=(0, 1))
            method = "GET+Range"
            status = r.status_code if r is not None else None
            okv = status in (200, 206)
        else:
            status, okv = r.status_code, False
        if r is not None:
            r.close()
    elapsed = time.monotonic() - t0
    if src_name:
        if okv:
            store.record_success(src_name)
        else:
            store.record_failure(src_name)   # 失效线路累计降级该源
    return {"url": url, "ok": okv, "status": status, "method": method,
            "elapsed": round(elapsed, 2)}


# ---------------------------------------------------------------------------
# 热榜：读 data/hot.json（stale-while-error 已在 hot_engine 完成，这里原样映射）
# ---------------------------------------------------------------------------
def _map_hot(raw: dict) -> dict:
    sections = raw.get("sections") or {}
    out = {"updated_at": raw.get("updated_at"), "stale": False,
           "note": raw.get("note")}
    for band in ("global", "douban", "maoyan"):
        sec = sections.get(band) or {}
        out[band] = sec.get("items") or []
        out[band + "_updated_at"] = sec.get("updated_at")
        if sec.get("stale"):
            out["stale"] = True
    # 热榜海报需可点进详情：无 id 条目生成标题回退 id（"t:标题|年份"）
    for band in ("global", "douban", "maoyan"):
        for it in out.get(band) or []:
            if it.get("id"):
                continue
            t = str(it.get("title") or "").strip()
            if not t:
                continue
            y = it.get("year") or ""
            it["id"] = "t:%s|%s" % (t, y) if y else "t:%s" % t
    return out


def _load_hot() -> Optional[dict]:
    try:
        mtime = os.stat(HOT_PATH).st_mtime
    except OSError:
        return None
    with _hot_lock:
        c = _hot_cache
        if c["data"] is not None and c["mtime"] == mtime \
                and time.time() - c["ts"] < HOT_CACHE_SECONDS:
            return c["data"]
    try:
        with open(HOT_PATH, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        _log.warning("hot.json 读取失败: %s", e)
        return None
    data = _map_hot(raw)
    with _hot_lock:
        _hot_cache.update({"ts": time.time(), "mtime": mtime, "data": data})
    return data


def _enhance_search_poster(data: Optional[dict]) -> Optional[dict]:
    """小雅补强：搜索结果前 10 条缺海报者，用 CDN 元数据补 poster。

    命中时返回浅拷贝后的新 dict（未命中返回原对象），不改写缓存/兜底快照；
    索引查内存 <5ms，同步执行不拖慢主链路；一切异常 → 跳过增强。
    """
    if not data or not isinstance(data.get("list"), list):
        return data
    src = data["list"]
    out = []
    changed = False
    for it in src[:10]:
        if not it.get("poster") and (it.get("title") or "").strip():
            try:
                m = xiaoya.get_meta(it["title"], it.get("year"))
            except Exception:
                m = {}
            if m.get("matched") and m.get("poster"):
                nw = dict(it)
                nw["poster"] = m["poster"]
                out.append(nw)
                changed = True
                continue
        out.append(it)
    if not changed:
        return data
    nd = dict(data)
    nd["list"] = out + src[10:]
    return nd


# ---------------------------------------------------------------------------
# 生命周期 + 访问日志（全部进 backend.log）
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(_app: FastAPI):
    # uvicorn 自身日志并入 backend.log；access 由下方中间件统一记录，关掉防重复
    try:
        logging.getLogger("uvicorn.access").disabled = True
        ue = logging.getLogger("uvicorn.error")
        if ue.handlers:
            ue.handlers = [_log.handlers[0]]
            ue.propagate = False
    except Exception:
        pass
    st = store.stats()
    _log.info("API 启动: uvicorn 单 worker / Semaphore(%d) / 单源 %.0fs / "
              "搜索总预算 %.0fs / LRU<=%d / 预检并发<=%d",
              SEMAPHORE_LIMIT, SOURCE_TIMEOUT, SEARCH_TOTAL_BUDGET,
              LRU_MAXSIZE, CHECK_CONCURRENCY)
    _log.info("源池: total=%d active=%d watch=%d removed=%d 熔断=%d",
              st["total"], st["active"], st["watch"], st["removed"],
              st["circuit_open"])
    # 分类聚合后台预热：冷聚合 12s+（7 源 × 6 分类 × 3 页），用户首开不可等；
    # 预热用 loader + set 直写（不走 get_or_set 单飞锁）——预热刷新期间用户请求
    # 仍命中旧缓存（新鲜期内 0.02s），不会被预热拉取阻塞（实测撞锁会等 12.8s）
    def _warm_categories():
        try:
            while True:
                for cat in CATEGORY_NAMES:
                    try:
                        t0w = time.monotonic()
                        # force=True：跳过命中检查直接单飞 loader（主动刷新）。
                        # 用户请求走非 force 路径：新鲜期命中旧缓存 0.02s 不阻塞；
                        # 启动空窗期用户 miss 会与预热共享同一次聚合（不再并发双拉）。
                        data = _cache.get_or_set(
                            ("cat", cat, ""),
                            lambda: category_loader(store, cat, ""),
                            ttl=CAT_CACHE_TTL, force=True)
                        _log.info("预热 set %s: %d 条 %.1fs", cat, len(data.get("items", [])),
                                  time.monotonic() - t0w)
                    except Exception as e:
                        _log.warning("分类预热 %s 失败: %s", cat, e)
                time.sleep(CAT_CACHE_TTL // 2)  # 半周期刷新：一轮 ~360s + 1800s < TTL 3600s
        except Exception:
            pass  # 预热线程异常不影响服务
    threading.Thread(target=_warm_categories, name="cat-warm", daemon=True).start()
    _log.info("分类预热线程已启动（7 个一级分类，TTL %ds 自动刷新）", CAT_CACHE_TTL)

    # 搜索预热：热榜片名 DB 秒回 + 库内缺失者预聚合（冷门词首查 8s → 预热后秒回）
    def _warm_search():
        try:
            while True:
                try:
                    with open(HOT_PATH, "r", encoding="utf-8") as f:
                        raw = json.load(f)
                    secs = raw.get("sections") or {}
                    titles = []
                    for sec in secs.values():
                        for it in (sec.get("items") or []):
                            t = str(it.get("title") or "").strip()
                            if t and t not in titles:
                                titles.append(t)
                        if len(titles) >= 20:
                            break
                except Exception:
                    titles = []
                for t in titles[:10]:          # 每轮最多 10 片，控制源站压力
                    try:
                        if _search_from_db(t, "") is not None:
                            continue            # 库内命中：查询本就秒回，无需预热
                        _cache.get_or_set(("s", t, ""),
                                          lambda tt=t: _search_loader(tt, ""),
                                          ttl=SEARCH_CACHE_TTL)
                    except Exception:
                        pass
                time.sleep(SEARCH_CACHE_TTL)    # 每 20 分钟一轮
        except Exception:
            pass
    threading.Thread(target=_warm_search, name="search-warm", daemon=True).start()
    _log.info("搜索预热线程已启动（热榜片名，TTL %ds 周期）", SEARCH_CACHE_TTL)
    yield
    _log.info("API 关闭")


app = FastAPI(title="Mars TV 云影院 API", version="0.1.0", lifespan=lifespan)


@app.middleware("http")
async def access_log(request: Request, call_next):
    t0 = time.monotonic()
    try:
        resp = await call_next(request)
    except Exception:
        _log.exception("请求异常 %s %s", request.method, request.url.path)
        raise
    _log.info("%s %s -> %d (%.0fms)", request.method, request.url.path,
              resp.status_code, (time.monotonic() - t0) * 1000)
    return resp


# ---------------------------------------------------------------------------
# 端点
# ---------------------------------------------------------------------------
@app.get("/api/search")
def api_search(wd: str = "", type: str = ""):
    """多源聚合搜索：本地影视库优先（46 万条 LIKE 秒回、无源站限流），
    库内无结果回退实时多源聚合（LRU 缓存 20 分钟 + 单飞；全挂返 24h 缓存）；
    实时聚合后叠加 spider 协议源结果（TVBox drpy2 引擎，2026-08 新增）。"""
    word = (wd or "").strip()
    if not word:
        return fail(2, "缺少搜索词 wd")
    db_data = _search_from_db(word, type)
    if db_data is not None:
        # DB 命中：结果 <15 条时叠加 spider 源补全（冷门词/新片），否则直接返回
        if len(db_data.get("list", [])) >= 15:
            return _json(ok(db_data, "ok"), cache=True, max_age=SEARCH_CACHE_TTL)
        _spider_augment(db_data, word)
        return _json(ok(db_data, "ok"), cache=True, max_age=SEARCH_CACHE_TTL)
    key = ("s", word, type)
    try:
        data = _cache.get_or_set(key, lambda: _search_loader(word, type),
                                 ttl=SEARCH_CACHE_TTL)
    except SearchUnavailable as e:
        stale = _stale_get(key)
        if stale is not None:
            data = dict(stale)
            data["stale"] = True
            data["note"] = "源全部不可用，返回 24h 内缓存结果"
            return _json(ok(data, "源暂时不可用，已返回缓存结果"), cache=True)
        _log.warning("搜索「%s」全部源失败: %s", word, e)
        return _json(fail(1, str(e)), cache=True)
    _stale_set(key, data)                      # 成功即刷新兜底快照
    data = _enhance_search_poster(data)        # 小雅补海报：前 10 条缺 poster 者，同步 <5ms
    # spider 协议源叠加（TVBox drpy2；DB 不足时补全）
    if data is not None:
        _spider_augment(data, word)
    return _json(ok(data, "ok"), cache=True, max_age=SEARCH_CACHE_TTL)


def _spider_augment(data: dict, word: str) -> None:
    """spider 协议源结果叠加进 data['list']（去重片名+年份，原地修改）。"""
    try:
        sp = spider_search(word)
        if not sp:
            return
        have = {(_norm_title(it.get("title") or ""), it.get("year")) for it in data.get("list", [])}
        added = 0
        for it in sp:
            k = (_norm_title(it.get("title") or ""), it.get("year"))
            if k in have:
                continue
            have.add(k)
            data["list"].append(it)
            added += 1
        if added:
            data["spider_added"] = added
            data["total"] = len(data["list"])
    except Exception:
        _log.exception("spider 搜索叠加异常: %s", word)


def _search_rows_to_items(rows) -> list:
    """rows → items（海报 URL 修正；补海报回填在调用方做）。"""
    items = []
    for r in rows:
        items.append({
            "id": "%s:%s" % (r[7], r[8]),
            "title": r[0], "year": r[1], "type": r[2], "area": r[3],
            "score": r[4], "poster": _fix_poster_url(r[5] or ""), "remarks": r[6] or "",
            "source": r[7], "vod_id": str(r[8]),
        })
    return items


def _search_from_db(word: str, type: str = "") -> Optional[dict]:
    """本地影视库搜索：FTS5 全文索引（毫秒级）+ 可选类型过滤，取前 30 条。

    trigram tokenizer 最小 3 字符；2 字符查询走前缀 LIKE（idx_vods_title）。
    """
    try:
        conn = vods_connect()
        try:
            where, args = [], []
            if type:
                where.append("type = ?")
                args.append(type)
            w = (" AND ".join(where)) if where else "1=1"
            # 拼音检索：纯字母输入（如 'aqgy'/'aiqinggongyu'）→ 匹配 pinyin 列
            # （全拼前缀优先，首字母前缀次之；无结果回落正常标题查询）
            py_hit = None
            if word.isascii() and word.isalnum() \
                    and not any("\u4e00" <= c <= "\u9fff" for c in word):
                py = word.lower()
                py_hit = conn.execute(
                    "SELECT title, year, type, area, score, poster, remarks, "
                    "source, vod_id FROM vods "
                    "WHERE (pinyin LIKE ? OR pinyin LIKE ?) AND %s "
                    "ORDER BY (pinyin LIKE ?) DESC, health DESC, "
                    "score DESC NULLS LAST LIMIT 30" % w,
                    [py + "|%", "%|" + py + "%"] + args + [py + "|%"]).fetchall()
            # FTS 主路径：3+ 字符
            if py_hit:
                rows = py_hit
            elif len(word) >= 3:
                rows = conn.execute(
                    "SELECT v.title, v.year, v.type, v.area, v.score, v.poster, "
                    "v.remarks, v.source, v.vod_id FROM vods_fts f "
                    "JOIN vods v ON v.rowid = f.rowid "
                    "WHERE f.title MATCH ? AND %s "
                    "ORDER BY v.health DESC, v.score DESC NULLS LAST "
                    "LIMIT 30" % w,
                    [word] + args).fetchall()
            else:
                # 2 字符：前缀 LIKE（B-tree 索引快）
                rows = conn.execute(
                    "SELECT title, year, type, area, score, poster, remarks, "
                    "source, vod_id FROM vods WHERE title LIKE ? AND %s "
                    "ORDER BY health DESC, score DESC NULLS LAST LIMIT 30" % w,
                    [word + "%"] + args).fetchall()
        finally:
            conn.close()
        if not rows:
            return None  # 库中无结果：回退实时多源搜索
        items = _search_rows_to_items(rows)
        # 补海报：小雅快扫全部 → TMDB 并发补全部缺 poster 者（命中回写 DB 越用越全）
        try:
            def _fill_xiaoya(it):
                try:
                    m = xiaoya.lookup(it.get("title"), it.get("year"))
                    if m is None:
                        m = xiaoya.lookup(it.get("title"), None)
                    if m and m.get("poster") and not it.get("poster"):
                        it["poster"] = m["poster"]
                except Exception:
                    pass
            for it in items:
                _fill_xiaoya(it)
            todo = [it for it in items
                    if not it.get("poster") and (it.get("type") or "") != "短剧"]
            if todo:
                import concurrent.futures as _cf2
                with _cf2.ThreadPoolExecutor(max_workers=8) as ex2:
                    for it in ex2.map(_tmdb_poster_fill, todo):
                        pass
            # 回写 DB（补到的海报下次直接命中）
            try:
                conn = vods_connect()
                try:
                    for it in items:
                        if it.get("poster"):
                            conn.execute(
                                "UPDATE vods SET poster = ? WHERE title = ? AND poster = ''",
                                (it["poster"], it["title"]))
                    conn.commit()
                finally:
                    conn.close()
            except Exception:
                pass
        except Exception:
            pass
        return {"list": items, "total": len(items), "sources_used": 1,
                "sources_failed": [], "elapsed": 0.0, "from_db": True}
    except Exception as e:
        _log.warning("本地库搜索失败(%s): %s", word, e)
        return None  # 任何异常回退实时搜索，不阻塞


@app.get("/api/detail/{item_id}")
def api_detail(item_id: str):
    """详情：简介/评分/线路数组（解析 vod_play_url，线路带来源标识）。"""
    if not item_id or not item_id.strip():
        return fail(2, "缺少片源 id")
    try:
        data = _cache.get_or_set(("d", item_id),
                                 lambda: _detail_loader(item_id),
                                 ttl=DETAIL_CACHE_TTL)
    except SearchUnavailable as e:
        return fail(1, str(e))
    if data is None:
        return fail(3, "未找到该片")
    title = (data.get("title") or "").strip()
    if title:                                  # 小雅元数据附加（只加不覆盖；异常跳过）
        try:
            m = xiaoya.get_meta(title, data.get("year"))
        except Exception:
            m = {}
        if m.get("matched"):
            data["meta"] = {
                "matched": True,
                "poster": m.get("poster"),
                "fanart": m.get("fanart"),
                "rating": m.get("rating"),
                "rating_imdb": m.get("rating_imdb"),
                "plot": m.get("plot"),
            }
    return ok(data, "ok")


@app.get("/api/meta")
def api_meta(wd: str = ""):
    """小雅元数据 CDN 查询：片名 → {matched,title,year,poster,fanart,rating,rating_imdb,plot,source}。"""
    title = (wd or "").strip()
    if not title:
        return fail(2, "缺少片名 wd")
    try:
        m = xiaoya.get_meta(title)
    except Exception:
        _log.exception("小雅元数据查询异常: %s", title)
        m = {"matched": False}
    return ok(m, "ok")


@app.get("/api/similar")
def api_similar(wd: str = "", year: str = ""):
    """猜你喜欢（TMDB similar 关联）：片名 → 关联片（本地库匹配 + 标题回退）。"""
    title = (wd or "").strip()
    if not title:
        return fail(2, "缺少片名 wd")
    try:
        y = None
        if year:
            try:
                y = int(year)
            except ValueError:
                y = None
        recs = _tmdb_similar(title, y)
        return ok({"list": recs}, "ok")
    except Exception:
        _log.exception("猜你喜欢异常: %s", title)
        return ok({"list": []}, "ok")


@app.get("/api/check")
def api_check(url: str = "", source: str = "", referer: str = ""):
    """线路预检：单线 3s、并发 ≤4、HEAD 被拒 GET 兜底 + Range；按 URL 缓存 15 分钟。"""
    url = (url or "").strip()
    if not url.startswith(("http://", "https://")):
        return fail(2, "缺少合法线路 url")
    try:
        data = _cache.get_or_set(("c", url),
                                 lambda: _check_line(url, source, referer),
                                 ttl=CHECK_CACHE_TTL)
    except Exception as e:
        _log.warning("预检异常 %s: %s", url[:80], e)
        return ok({"url": url, "ok": False, "status": "error", "method": "error",
                   "elapsed": 0.0}, "预检异常")
    return ok(data, "ok" if data["ok"] else "线路不可用")


@app.get("/api/hot")
def api_hot():
    """三榜融合热榜：读 data/hot.json，stale-while-error 段原样标注；带 Cache-Control。"""
    data = _load_hot()
    if data is None:
        return _json(fail(1, "热榜数据暂不可用（降级走 /hot.json 快照）"),
                     cache=True, max_age=60)
    return _json(ok(data, "ok"), cache=True, max_age=600)


# ---------------------------------------------------------------------------
# 海报图片代理：豆瓣图床反盗链（无 Referer 418），统一带 UA+Referer 拉取转发。
# 三层：磁盘缓存（POSTER_DIR，秒回不回源）→ 内存 LRU（96 张）→ 回源+落盘。
# ---------------------------------------------------------------------------
_img_cache = {}
_img_cache_order = []
_img_fly = {}
_IMG_CACHE_MAX = 96
POSTER_DIR = os.path.join(DATA_DIR, "posters")
# 占位图兜底：回源失败时返回（深灰底，避免前端破图/空白）
_PLACEHOLDER_SVG = (
    b'<svg xmlns="http://www.w3.org/2000/svg" width="300" height="450">'
    b'<rect width="100%" height="100%" fill="#1a1d24"/></svg>'
)


@app.get("/api/img")
def api_img(url: str = "", request: Request = None):
    if not url.startswith(("http://", "https://")):
        return JSONResponse({"code": 2, "data": None, "msg": "bad url"}, status_code=400)
    if len(url) > 512:
        return JSONResponse({"code": 2, "data": None, "msg": "url too long"}, status_code=400)
    # 磁盘缓存优先：本地海报直接秒回（不回源、不占内存）
    try:
        fname = hashlib.sha1(url.encode()).hexdigest() + ".img"
        fpath = os.path.join(POSTER_DIR, fname)
        if os.path.exists(fpath):
            with open(fpath, "rb") as f:
                body = f.read()
            # 同时补进内存 LRU（下次更快）
            if url not in _img_cache:
                _img_cache[url] = {"body": body, "ctype": "image/jpeg"}
                _img_cache_order.append(url)
                while len(_img_cache_order) > _IMG_CACHE_MAX:
                    old = _img_cache_order.pop(0)
                    _img_cache.pop(old, None)
            return Response(content=body, media_type="image/jpeg",
                            headers={"Cache-Control": "public, max-age=604800"})
    except Exception:
        pass  # 磁盘读取失败回退内存/回源
    hit = _img_cache.get(url)
    if hit is not None:
        # LRU 触达：移到队尾
        try:
            _img_cache_order.remove(url)
            _img_cache_order.append(url)
        except ValueError:
            pass
        return Response(content=hit["body"], media_type=hit["ctype"],
                        headers={"Cache-Control": "public, max-age=86400"})
    # 并发单飞：同 URL 同时只回源一次
    if url in _img_fly:
        try:
            with _img_fly[url].acquire(timeout=10):
                hit = _img_cache.get(url)
                if hit is not None:
                    return Response(content=hit["body"], media_type=hit["ctype"],
                                    headers={"Cache-Control": "public, max-age=86400"})
        except Exception:
            pass
    sem = _img_fly.setdefault(url, threading.Lock())
    if not sem.acquire(blocking=False):
        # 已在拉取中：等它完成
        try:
            with sem:
                hit = _img_cache.get(url)
                if hit is not None:
                    return Response(content=hit["body"], media_type=hit["ctype"],
                                    headers={"Cache-Control": "public, max-age=86400"})
        except Exception:
            pass
        return JSONResponse({"code": 1, "data": None, "msg": "img busy"}, status_code=502)
    try:
        # 按域名动态 Referer：豆瓣图床需豆瓣 Referer，小雅 CDN 需小雅 Referer，
        # 其他源站图床用同域 Referer 防防盗链 403
        import urllib.parse as _up
        host = (_up.urlparse(url).netloc or "").lower()
        if "douban" in host:
            referer = "https://movie.douban.com/"
        elif "xiaoya" in host:
            referer = "https://emby.xiaoya.pro/"
        else:
            referer = "https://" + host + "/"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
            "Referer": referer,
            "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
        }
        import urllib.request
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=8) as resp:
            body = resp.read(4 * 1024 * 1024)  # 4MB 上限
            ctype = resp.headers.get("Content-Type", "image/jpeg")
            if not ctype.startswith("image/"):
                ctype = "image/jpeg"
            # 入缓存（LRU 淘汰）+ 磁盘持久化（海报秒加载：本地磁盘直出，不回源）
            _img_cache[url] = {"body": body, "ctype": ctype}
            _img_cache_order.append(url)
            while len(_img_cache_order) > _IMG_CACHE_MAX:
                old = _img_cache_order.pop(0)
                _img_cache.pop(old, None)
            try:
                fname = hashlib.sha1(url.encode()).hexdigest() + ".img"
                fpath = os.path.join(POSTER_DIR, fname)
                with open(fpath, "wb") as f:
                    f.write(body)
            except Exception:
                pass  # 磁盘写入失败不影响内存缓存
            return Response(content=body, media_type=ctype,
                            headers={"Cache-Control": "public, max-age=604800"})
    except Exception:
        # 回源失败：返回内置占位图（深灰底），避免前端破图/空白
        return Response(content=_PLACEHOLDER_SVG, media_type="image/svg+xml",
                        headers={"Cache-Control": "public, max-age=3600"})
    finally:
        _img_fly.pop(url, None)


@app.get("/api/sources")
def api_sources():
    """源池状态：数量/评分/熔断/异常数（前端页脚计数 + 维护弹窗共用）。"""
    st = store.stats()
    alert = st["active"] < ACTIVE_POOL_ALERT_THRESHOLD
    now = time.time()
    srcs = []
    for s in store.all_sources():
        c = s.get("circuit") or {}
        o = c.get("open_until")
        opened = bool(o) and now < o
        srcs.append({
            "name": s.get("name"),
            "status": s.get("status"),
            "score": s.get("score") or 0.0,
            "healthy": s.get("status") == "active" and not opened,
            "fail_count": c.get("fail_count", 0),
            "circuit_open": opened,
        })
    return ok({
        "total": st["total"], "active": st["active"], "watch": st["watch"],
        "removed": st["removed"], "circuit_open": st["circuit_open"],
        "broken": st["watch"], "fused": st["circuit_open"],
        "alert": alert, "sources": srcs,
    }, "ok")


@app.get("/api/health")
def api_health():
    """健康检查：前端 30s 轮询降级判断；活跃池 <3 时 alert=true。"""
    st = store.stats()
    return ok({
        "status": "ok",
        "active": st["active"],
        "total": st["total"],
        "alert": st["active"] < ACTIVE_POOL_ALERT_THRESHOLD,
        "circuit_open": st["circuit_open"],
        "uptime": round(time.time() - _start_ts, 1),
        "ts": time.time(),
    }, "ok")


def _category_from_db(t: str, sub: str, pg: int, year: str) -> Optional[dict]:
    """本地影视库分类查询（2026-08-03 扩资源：全量爬取后查询走库）。

    返回与 category_loader 相同的 {list,total,page,page_size,year_facets,...}
    结构；库中无该分类数据（爬取中/失败）返回 None 让调用方回退实时聚合。
    深度无限：pg 任意大都由 SQL LIMIT/OFFSET 处理，毫秒级。
    """
    try:
        conn = vods_connect()
        try:
            where, args = ["cat = ?"], [t]
            if sub:
                where.append("type = ?")
                args.append(sub)
            # 基准条件（不含 year）：年份 chips 统计用，保证选了年份后
            # 其他年份选项仍在（否则 facets 只剩当前年无法切换）
            where_base, args_base = list(where), list(args)
            yf = year.strip().lower()
            if yf:
                if re.fullmatch(r"(19|20)\d{2}", yf):
                    where.append("year = ?")
                    args.append(int(yf))
                elif yf.endswith("s"):
                    try:
                        decade = int(yf[:-1])
                    except ValueError:
                        decade = 0
                    where.append("year >= ? AND year < ?")
                    args += [decade, decade + 10]
                elif yf == "older":
                    where.append("year < 2010")
                elif yf == "newer":
                    where.append("year >= 2020")
            w = " AND ".join(where)
            total = conn.execute(f"SELECT COUNT(*) FROM vods WHERE {w}",
                                 args).fetchone()[0]
            # 年份分布（全库统计，前端 chips）——注意：不带 year 筛选条件，
            # 否则选了某年后 facets 只剩该年，其他年份 chips 全消失无法切换
            w_base = " AND ".join(where_base)
            ycnt = conn.execute(
                f"SELECT year, COUNT(*) FROM vods WHERE {w_base} "
                "AND year IS NOT NULL "
                "GROUP BY year ORDER BY COUNT(*) DESC, year DESC LIMIT 12",
                args_base).fetchall()
            year_facets = [r[0] for r in ycnt]
            year_facets.sort(reverse=True)
            start = (pg - 1) * CAT_PAGE_SIZE
            # 取 4 倍数据做页内源轮转打散（多源混合观感，同页不重复）
            rows = conn.execute(
                "SELECT title, year, type, area, score, poster, remarks, "
                "source, vod_id FROM vods WHERE %s "
                "ORDER BY health DESC, year DESC NULLS LAST, source "
                "LIMIT ? OFFSET ?" % w,
                args + [CAT_PAGE_SIZE * 4, start]).fetchall()
        finally:
            conn.close()
        items = []
        for r in rows:
            items.append({
                "id": "%s:%s" % (r[7], r[8]),
                "title": r[0], "year": r[1], "type": r[2], "area": r[3],
                "score": r[4], "poster": _fix_poster_url(r[5] or ""), "remarks": r[6] or "",
                "source": r[7], "vod_id": str(r[8]),
            })
        # 页内源轮转打散：同源最多连 3 条，保证每页多源混合（同页不重复）
        if len(items) > CAT_PAGE_SIZE:
            buckets = {}
            for it in items:
                buckets.setdefault(it.get("source", "?"), []).append(it)
            names = list(buckets.keys())
            mixed, idx, guard = [], {n: 0 for n in names}, 0
            while len(mixed) < CAT_PAGE_SIZE and guard < len(items) * 2:
                guard += 1
                for n in names:
                    if len(mixed) >= CAT_PAGE_SIZE:
                        break
                    burst = 0
                    while idx[n] < len(buckets[n]) and burst < 3 \
                            and len(mixed) < CAT_PAGE_SIZE:
                        mixed.append(buckets[n][idx[n]])
                        idx[n] += 1
                        burst += 1
            items = mixed
        if not items and pg > 1 and total > 0:
            # 超出深度但库有数据：给空页（前端无限滚动自然停止）
            pass
        if total == 0:
            return None  # 库中无该类：回退实时聚合
        # 小雅→TMDB 补数据（仅当前页，命中 O(1)）：源站 vod_year 缺失率 95%+，
        # 标题带年份的才入库有 year——补 year 供年份筛选、补 poster 供展示；
        # 补到的数据回写 DB（越用越全，下次查询直接命中不再查小雅/TMDB）
        # 注意：TMDB 回退较慢（miss 每条 ~2.5s），只对前 8 条做且并发，避免拖慢分类页
        try:
            conn = vods_connect()
            try:
                import concurrent.futures as _cf

                def _fill(it):
                    try:
                        if it.get("year") and it.get("poster"):
                            return it, None
                        m = xiaoya.lookup(it.get("title"), it.get("year"))
                        if m is None:
                            m = xiaoya.lookup(it.get("title"), None)
                        changed = False
                        if m is not None:
                            if not it.get("year") and m.get("year"):
                                it["year"] = m["year"]
                                changed = True
                            if not it.get("poster") and m.get("poster"):
                                it["poster"] = m["poster"]
                                changed = True
                        return it, changed
                    except Exception:
                        return it, None

                # 小雅补全（快，全部做）
                for it in items:
                    _fill(it)
                # TMDB 回退（并发 8，补全部缺 poster 者；短剧类目跳过——TMDB 无短剧条目，纯浪费）
                todo = [it for it in items
                        if not it.get("poster") and t != "短剧"]
                if todo:
                    with _cf.ThreadPoolExecutor(max_workers=8) as _ex:
                        for it, _p in _ex.map(_tmdb_poster_fill, todo):
                            pass
                # 回写 DB
                for it in items:
                    conn.execute(
                        "UPDATE vods SET year=?, poster=? WHERE id=?",
                        (it.get("year"), it.get("poster"), it["id"]))
                conn.commit()
            finally:
                conn.close()
        except Exception:
            pass  # 兜底失败不影响主流程
        return {"list": items, "total": total, "page": pg,
                "page_size": CAT_PAGE_SIZE, "sources_used": 1,
                "sources_failed": [], "elapsed": 0.0,
                "year_facets": year_facets}
    except Exception as e:
        _log.warning("本地库分类查询失败(%s/%s): %s", t, sub, e)
        return None  # 任何异常回退实时聚合，不阻塞


@app.get("/api/category")
def api_category(t: str = "", sub: str = "", pg: Optional[int] = 1,
                 year: str = ""):
    """多源聚合分类浏览：一级 t + 二级 sub + 页码 pg + 年份 year。

    分类树驱动（ac=list&t=<type_id>，叶子分类才有效，见 category_engine 文档）；
    单源超时跳过、分类缺失返回空列表；聚合去重后按 pg 切片（24 卡/页）。
    year: 可选，如 "2023" 精确年 / "2020s" 年代区间 / "" 全部；
    返回 year_facets = 各年份计数（前 12 个热门年份），供前端年份 chips。
    """
    t = (t or "").strip()
    if t not in CATEGORY_NAMES:
        return fail(2, "未知一级分类：%s（可选：%s）" % (t, "/".join(CATEGORY_NAMES)))
    sub = (sub or "").strip()
    if sub and sub not in CATEGORY_TREE[t]["subs"]:
        return fail(2, "二级分类 %s 不属于 %s（可选：%s）"
                    % (sub, t, "/".join(CATEGORY_TREE[t]["subs"])))
    pg = pg if (pg or 0) > 0 else 1
    # 本地影视库优先（爬虫全量入库后：查询秒出、深度无限、不触发源站锁死）。
    # 库内无该分类数据（首次爬取中/失败）自动回退实时聚合。
    db_data = _category_from_db(t, sub, pg, year)
    if db_data is not None:
        return _json(ok(db_data, "ok"), cache=True, max_age=CAT_CACHE_TTL)
    try:
        full = _cache.get_or_set(("cat", t, sub),
                                 lambda: category_loader(store, t, sub),
                                 ttl=CAT_CACHE_TTL)
    except Exception as e:
        _log.warning("分类 %s/%s 聚合异常: %s", t, sub, e)
        return _json(ok({"list": [], "total": 0, "page": pg,
                         "page_size": CAT_PAGE_SIZE, "sources_used": 0,
                         "sources_failed": [], "elapsed": 0.0,
                         "year_facets": []},
                        "分类聚合失败"), cache=True, max_age=60)
    # 年份筛选（year 参数）："" 全部 / "2023" 精确 / "2020s" 年代区间 / "older" 2010前
    # （year/poster 已由 category_loader 聚合时用小雅补全，缓存 10min）
    items = full["items"]
    yf = year.strip().lower()
    if yf:
        def _ymatch(it):
            y = it.get("year")
            if not y:
                return False
            if re.fullmatch(r"(19|20)\d{2}", yf):
                return str(y) == yf
            if yf.endswith("s"):
                try:
                    decade = int(yf[:-1])
                except ValueError:
                    return False
                return decade <= y < decade + 10
            if yf == "older":
                return y < 2010
            if yf == "newer":
                return y >= 2020
            return False
        items = [it for it in items if _ymatch(it)]
    # 年份分布（全量聚合上统计，前端年份 chips 用）
    from collections import Counter
    ycnt = Counter()
    for it in full["items"]:
        y = it.get("year")
        if y:
            ycnt[y] += 1
    year_facets = [y for y, _ in ycnt.most_common(12)]
    year_facets.sort(reverse=True)
    start = (pg - 1) * CAT_PAGE_SIZE
    page_items = items[start:start + CAT_PAGE_SIZE]
    data = {"list": page_items,
            "total": len(items), "page": pg,
            "page_size": CAT_PAGE_SIZE, "sources_used": full["sources_used"],
            "sources_failed": full["sources_failed"],
            "elapsed": full["elapsed"],
            "year_facets": year_facets}
    return _json(ok(data, "ok"), cache=True, max_age=CAT_CACHE_TTL)


@app.get("/api/categories")
def api_categories():
    """前端首页分类 chips：7 个一级分类 + 二级子类树（home.js 已调用）。"""
    tree = {k: list(v["subs"]) for k, v in CATEGORY_TREE.items()}
    return ok({"categories": CATEGORIES, "tree": tree}, "ok")


# ============================================================================
# TVBox 蜘蛛协议接口（/tvbox/vod）—— 让影视仓/TVBox 类 App 直接接入本站
# 协议参考：TVBox spider JSON 接口（ac=list/detail/search）
#   ac=list        → 分类列表 {"class":[{"type_id","type_name"}]}
#   ac=detail&pg=N → 分页列表（数据库矿场，毫秒级）
#   ac=detail&ids=X → 单条详情（含播放地址 vod_play_from/vod_play_url）
#   ac=search&wd=W → 搜索（数据库优先，无结果回退实时聚合）
# 播放地址格式：vod_play_from="线路1$$$线路2"，vod_play_url="集1$url#集2$url$$$..."
# ============================================================================
TVBOX_PAGE_SIZE = 20


@app.get("/tvbox/vod")
def tvbox_vod(ac: str = "list", t: str = "", pg: Optional[int] = 1,
              ids: str = "", wd: str = ""):
    """TVBox 蜘蛛协议入口（JSON 模式，客户端直连即点即播）。"""
    ac = (ac or "list").strip().lower()

    # ---- 1) 分类列表 ----
    if ac == "list":
        cls = [{"type_id": str(i + 1), "type_name": name}
               for i, name in enumerate(CATEGORIES)]
        return {"code": 1, "msg": "", "class": cls}

    # ---- 2) 详情（ids 逗号分隔，播放页取 vod_play_from/vod_play_url）----
    if ac == "detail" and ids:
        out = []
        for raw in str(ids).split(","):
            rid = raw.strip()
            if not rid:
                continue
            try:
                data = _cache.get_or_set(("d", rid),
                                         lambda: _detail_loader(rid),
                                         ttl=DETAIL_CACHE_TTL)
            except Exception:
                data = None
            if not data:
                continue
            out.append(_tvbox_detail_item(data))
        return {"code": 1, "msg": "", "list": out}

    # ---- 3) 分页列表（数据库矿场）----
    if ac == "detail":
        pg = pg if (pg or 0) > 0 else 1
        conn = vods_connect()
        try:
            where, args = [], []
            # t 参数：分类名或 type_id（1-7 → CATEGORIES）
            if t:
                tn = t
                if t.isdigit() and 1 <= int(t) <= len(CATEGORIES):
                    tn = CATEGORIES[int(t) - 1]
                where.append("cat = ?")
                args.append(tn)
            w = (" AND ".join(where)) if where else "1=1"
            total = conn.execute(
                "SELECT COUNT(*) FROM vods WHERE %s" % w, args).fetchone()[0]
            start = (pg - 1) * TVBOX_PAGE_SIZE
            rows = conn.execute(
                "SELECT title, year, type, area, score, poster, remarks, "
                "source, vod_id FROM vods WHERE %s "
                "ORDER BY health DESC, year DESC NULLS LAST, source "
                "LIMIT ? OFFSET ?" % w,
                args + [TVBOX_PAGE_SIZE, start]).fetchall()
        finally:
            conn.close()
        items = []
        for r in rows:
            items.append({
                "vod_id": "%s:%s" % (r[7], r[8]),
                "vod_name": r[0],
                "vod_year": r[1] or "",
                "vod_type": r[2] or "",
                "vod_area": r[3] or "",
                "vod_score": r[4] or "",
                "vod_pic": _fix_poster_url(r[5] or ""),
                "vod_remarks": r[6] or "",
            })
        pagecount = max(1, (total + TVBOX_PAGE_SIZE - 1) // TVBOX_PAGE_SIZE)
        return {"code": 1, "msg": "", "page": pg, "pagecount": pagecount,
                "limit": TVBOX_PAGE_SIZE, "total": total, "list": items}

    # ---- 4) 搜索（数据库优先，无结果回退实时聚合搜索缓存）----
    if ac == "search":
        word = (wd or "").strip()
        if not word:
            return {"code": 0, "msg": "缺少 wd", "list": []}
        try:
            db = _search_from_db(word)
            if db is None:
                # 回退实时聚合（用搜索缓存，8s 预算）
                agg = _cache.get_or_set(("s", word),
                                        lambda: _search_agg(word),
                                        ttl=SEARCH_CACHE_TTL)
                items = [{
                    "vod_id": it.get("id") or "",
                    "vod_name": it.get("title") or "",
                    "vod_year": it.get("year") or "",
                    "vod_type": it.get("type") or "",
                    "vod_area": it.get("area") or "",
                    "vod_score": it.get("score") or "",
                    "vod_pic": it.get("poster") or "",
                    "vod_remarks": it.get("remarks") or "",
                } for it in (agg.get("list") or [])]
            else:
                items = [{
                    "vod_id": it.get("id") or "",
                    "vod_name": it.get("title") or "",
                    "vod_year": it.get("year") or "",
                    "vod_type": it.get("type") or "",
                    "vod_area": it.get("area") or "",
                    "vod_score": it.get("score") or "",
                    "vod_pic": it.get("poster") or "",
                    "vod_remarks": it.get("remarks") or "",
                } for it in (db.get("list") or [])]
        except Exception as e:
            _log.warning("tvbox search %s 异常: %s", word, e)
            items = []
        return {"code": 1, "msg": "", "list": items}

    return {"code": 0, "msg": "未知 ac: %s" % ac, "list": []}


def _tvbox_detail_item(data: dict) -> dict:
    """本站详情 → TVBox 播放格式（vod_play_from/vod_play_url）。"""
    froms, urls = [], []
    for ln in data.get("lines") or []:
        nm = ln.get("name") or "线路"
        eps = ln.get("episodes") or []
        if not eps:
            continue
        froms.append(nm)
        urls.append("#".join(
            "%s$%s" % (ep.get("name") or str(i + 1), ep.get("url") or "")
            for i, ep in enumerate(eps)))
    return {
        "vod_id": data.get("id") or "",
        "vod_name": data.get("title") or "",
        "vod_pic": data.get("poster") or "",
        "vod_year": data.get("year") or "",
        "vod_area": data.get("area") or "",
        "vod_type": data.get("type") or "",
        "vod_director": data.get("director") or "",
        "vod_actor": data.get("actors") or "",
        "vod_score": data.get("score") or "",
        "vod_content": data.get("intro") or "",
        "vod_play_from": "$$$".join(froms),
        "vod_play_url": "$$$".join(urls),
        "vod_remarks": data.get("remarks") or "",
    }
