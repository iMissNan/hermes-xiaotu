"""三榜融合热榜引擎 —— TMDB 全球热播 / 豆瓣口碑 / 猫眼热映。

设计依据: docs/superpowers/specs/2026-08-02-martv-design-v3.md 第三章。
依赖核心库: utils.py（fetch/原子写/日志）。

CLI: python hot_engine.py {refresh|tmdb|douban|maoyan}
- refresh (全量): 三榜并行拉取 → 融合去重 → 原子写 data/hot.json
- tmdb   (每 6h): 只刷 TMDB（movie+tv 各 Top20），复用旧 douban/maoyan 段重融合
- douban (每 24h): 只刷豆瓣口碑榜 Top20，复用旧段重融合
- maoyan (每日):  只刷猫眼日榜 Top20，复用旧段重融合

融合规则（第三章原文照抄）:
- 三榜各自 Top 20 → 统一字段 {title, year, poster, score, source, rank}
- 以 TMDB/豆瓣 id 为主键建映射表，辅以片名+年份模糊匹配，多榜命中权重叠加去重
- 权重本地化: 豆瓣/猫眼 1.5x、TMDB 0.8x；缺中文名用活跃源（中文榜命中）回填
- 每榜独立 updated_at；单榜失败不影响其余（stale-while-error：失败榜复用旧段并标注 stale）
"""

from __future__ import annotations

import argparse
import html
import json
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils import DATA_DIR, get_logger, write_json_atomic  # noqa: E402

# ---------------------------------------------------------------------------
# 常量（第三章）
# ---------------------------------------------------------------------------
TMDB_PROXY_BASE = "https://daili.smdhb.com/3"        # TMDB 代理（非直连）
TMDB_API_KEY = "2a817082784309aefeff00649c1c8664"
TMDB_URLS = {
    "movie": f"{TMDB_PROXY_BASE}/trending/movie/week?api_key={TMDB_API_KEY}",
    "tv":    f"{TMDB_PROXY_BASE}/trending/tv/week?api_key={TMDB_API_KEY}",
}
DOUBAN_CHART_URL = "https://movie.douban.com/chart"          # 豆瓣口碑榜
MAOYAN_RANK_URL = "https://maoyan.com/rankings/year"         # 猫眼年度热映（日榜）

TOP_N = 20                       # 每榜取 Top 20
BAND_FETCH_TIMEOUT = 15.0        # 后台榜单任务 read 超时（非用户请求路径，放宽）
TMDB_POSTER_BASE = "https://image.tmdb.org/t/p/w500"
HOT_PATH = os.path.join(DATA_DIR, "hot.json")

# 权重本地化（第三章原文）：豆瓣/猫眼 1.5x、TMDB 0.8x
WEIGHTS = {"tmdb": 0.8, "douban": 1.5, "maoyan": 1.5}

_log = get_logger("hot")


# ---------------------------------------------------------------------------
# 统一条目字段 {title, year, poster, score, source, rank}（rank 融合后回填）
# ---------------------------------------------------------------------------
def _norm_title(t: str) -> str:
    """片名归一化：小写、去空白与常见标点（用于模糊匹配，尽力而为）。"""
    t = t.lower().strip()
    t = re.sub(r"[\s:：·•\-—–_/\\()（）\[\]【】.。!！?？,，'\"“”‘’]+", "", t)
    return t


def _mk_item(title: str, year: Any, poster: str, score: Any, source: str,
             ids: Optional[dict] = None, rank: int = 0) -> dict:
    """构造统一字段条目；score 保留原始（无则 None），ids 存各榜主键。"""
    y = None
    if year is not None:
        m = re.search(r"(\d{4})", str(year))
        if m:
            y = int(m.group(1))
    try:
        sc = round(float(score), 1) if score not in (None, "") else None
    except (TypeError, ValueError):
        sc = None
    return {"title": title.strip(), "year": y, "poster": poster or "",
            "score": sc, "source": source, "rank": rank,
            "ids": ids or {}, "weight": WEIGHTS[source]}


# ---------------------------------------------------------------------------
# 各榜解析器（独立函数，改版时只换对应解析器）
# ---------------------------------------------------------------------------
def parse_tmdb(resp_json: dict) -> list:
    """TMDB trending 响应 → Top20 条目。movie/tv 两段由调用方分别传入。"""
    items = []
    for r in (resp_json.get("results") or [])[:TOP_N]:
        title = r.get("title") or r.get("name") or r.get("original_title") or ""
        if not title:
            continue
        year = r.get("release_date") or r.get("first_air_date") or r.get("air_date")
        poster = TMDB_POSTER_BASE + r["poster_path"] if r.get("poster_path") else ""
        items.append(_mk_item(title, year, poster, r.get("vote_average"), "tmdb",
                              ids={"tmdb": r.get("id")}))
    return items


def parse_douban(html_text: str) -> list:
    """豆瓣口碑榜 HTML → Top20 条目（解析器独立，改版只换此函数）。"""
    items = []
    # 每行一个 <tr class="item">；ID 从 subject 链接提取，标题取 img alt 兜底 a 文本
    for row in re.findall(r'<tr\s+class="item".*?</tr>', html_text, re.S):
        m = re.search(r'https://movie\.douban\.com/subject/(\d+)/', row)
        did = m.group(1) if m else None
        m = re.search(r'<img[^>]*alt="([^"]+)"', row)
        title = html.unescape(m.group(1)).strip() if m else ""
        if not title:  # 兜底：pl2 区 a 文本
            m = re.search(r'<div\s+class="pl2">.*?<a[^>]*>(.*?)</a>', row, re.S)
            if m:
                title = re.sub(r"<[^>]+>", "", m.group(1)).strip()
        if not title:
            continue
        m = re.search(r'class="rating_nums">([\d.]+)', row)
        score = m.group(1) if m else None
        m = re.search(r'<p>([^<]*)', row)
        if m:
            dm = re.search(r"(\d{4})-\d{2}-\d{2}", m.group(1)) or \
                re.search(r"(\d{4})", m.group(1))
            year = dm.group(1) if dm else None
        else:
            year = None
        m = re.search(r'<img[^>]*src="([^"]+)"', row)
        poster = html.unescape(m.group(1)) if m else ""
        items.append(_mk_item(title, year, poster, score, "douban",
                              ids={"douban": int(did)} if did else {}))
    return items[:TOP_N]


def parse_maoyan(html_text: str) -> list:
    """猫眼榜单 HTML → Top20 条目（解析器独立，改版只换此函数）。"""
    items = []
    for block in re.split(r'<div\s+class="list-item"', html_text)[1:]:
        m = re.search(r'class="movie-title"[^>]*>(.*?)</a>', block, re.S)
        if not m:
            continue
        title = html.unescape(re.sub(r"<[^>]+>", "", m.group(1))).strip()
        if not title:
            continue
        mid = None
        m = re.search(r'href="/films/(\d+)"', block)
        if m:
            mid = int(m.group(1))
        m = re.search(r'class="integer">([\d.]+)</i><i\s+class="fraction">(\d+)', block)
        score = (m.group(1).rstrip(".") + "." + m.group(2)) if m else None
        m = re.search(r"上映时间[：:]\s*(\d{4})", block) or \
            re.search(r'class="movie-item-releasetime"[^>]*>([^<]*)', block)
        year = m.group(1) if m else None
        m = re.search(r'<img[^>]*data-src="([^"]+)"', block) or \
            re.search(r'<img[^>]*src="([^"]+)"', block)
        poster = html.unescape(m.group(1)) if m else ""
        items.append(_mk_item(title, year, poster, score, "maoyan",
                              ids={"maoyan": mid} if mid else {}))
    return items[:TOP_N]


# ---------------------------------------------------------------------------
# 拉取（每榜独立失败，返回 (items, error)）
# ---------------------------------------------------------------------------
def fetch_tmdb() -> tuple:
    from utils import fetch
    items, err = [], None
    for seg, url in TMDB_URLS.items():
        try:
            r = fetch(url, timeout=BAND_FETCH_TIMEOUT)
            if r is None:
                raise RuntimeError("请求失败/超时")
            if r.status_code != 200:
                raise RuntimeError(f"HTTP {r.status_code}")
            seg_items = parse_tmdb(r.json())
            _log.info("tmdb %s Top%d 拉到 %d 条", seg, TOP_N, len(seg_items))
            items.extend(seg_items)
            r.close()
        except Exception as e:  # 分段失败只记日志，另一段照常
            err = err or f"tmdb/{seg}: {e}"
            _log.warning("TMDB %s 段失败: %s", seg, e)
    return items[:TOP_N * 2], err


def fetch_douban() -> tuple:
    from utils import fetch
    try:
        r = fetch(DOUBAN_CHART_URL, timeout=BAND_FETCH_TIMEOUT)
        if r is None:
            raise RuntimeError("请求失败/超时")
        if r.status_code != 200:
            raise RuntimeError(f"HTTP {r.status_code}")
        items = parse_douban(r.text)
        r.close()
        _log.info("douban 口碑榜拉到 %d 条", len(items))
        return items, None if items else "解析为空"
    except Exception as e:
        _log.warning("豆瓣口碑榜拉取失败: %s", e)
        return [], str(e)


def fetch_maoyan() -> tuple:
    from utils import fetch
    try:
        r = fetch(MAOYAN_RANK_URL, timeout=BAND_FETCH_TIMEOUT)
        if r is None:
            raise RuntimeError("请求失败/超时")
        if r.status_code != 200:
            raise RuntimeError(f"HTTP {r.status_code}")
        items = parse_maoyan(r.text)
        r.close()
        _log.info("maoyan 热映榜拉到 %d 条", len(items))
        return items, None if items else "解析为空"
    except Exception as e:
        _log.warning("猫眼热映榜拉取失败: %s", e)
        return [], str(e)


# ---------------------------------------------------------------------------
# 融合去重（权重叠加；id 主键映射 + 片名+年份模糊匹配）
# ---------------------------------------------------------------------------
def _match(merged_item: dict, item: dict, id_map: Optional[dict] = None) -> bool:
    """判定两条目是否同一部片：id 主键映射表命中 → 片名+年份模糊匹配。

    id_map 结构: {src: {id: {dst: dst_id}}}（跨榜 id 对应关系，随 hot.json 持久化）。
    """
    ids = merged_item.get("ids") or {}
    for k, v in (item.get("ids") or {}).items():
        if v is not None and ids.get(k) == v:
            return True
    if id_map:  # 主键映射表（历史融合登记的跨榜 id 对应）
        for src, vid in (item.get("ids") or {}).items():
            if vid is None:
                continue
            for dst, did in (id_map.get(src) or {}).get(vid, {}).items():
                if ids.get(dst) == did:
                    return True
    a, b = _norm_title(merged_item["title"]), _norm_title(item["title"])
    if a and b and a == b:
        my, iy = merged_item.get("year"), item.get("year")
        if my == iy or my is None or iy is None:  # 年份一致或双方缺失
            return True
    return False


def _register_map(id_map: dict, a: dict, b: dict) -> None:
    """融合命中后登记跨榜 id 映射（双向），供后续刷新直接命中。"""
    for sa, va in (a.get("ids") or {}).items():
        if va is None:
            continue
        for sb, vb in (b.get("ids") or {}).items():
            if sb == sa or vb is None:
                continue
            id_map.setdefault(sa, {}).setdefault(va, {})[sb] = vb
            id_map.setdefault(sb, {}).setdefault(vb, {})[sa] = va


def merge_items(all_items: list, id_map: Optional[dict] = None) -> list:
    """多榜条目 → 融合去重：多榜命中权重叠加，title 优先中文（活跃源回填），
    score 取最高，按 (weight desc, score desc) 排序后回填 rank。
    返回 (merged, id_map)——id_map 为 None 时新建并在命中时登记。"""
    id_map = id_map if id_map is not None else {}
    merged: list = []
    for it in all_items:
        target = next((m for m in merged if _match(m, it, id_map)), None)
        if target is None:
            merged.append(dict(it))
            continue
        # 权重叠加（多榜命中去重）
        target["weight"] = target.get("weight", 0) + WEIGHTS.get(it["source"], 0)
        _register_map(id_map, target, it)
        target["ids"].update(it.get("ids") or {})
        # 中文名回填：豆瓣/猫眼标题优先于 TMDB 原名（尽力而为）
        if it["source"] != "tmdb" and it["title"] and \
                (target["source"] == "tmdb" or not target["title"]):
            target["title"] = it["title"]
        if target["source"] == "tmdb" and it["source"] != "tmdb":
            target["source"] = it["source"]
        # 评分取最高（None 不覆盖实值）
        if it.get("score") is not None and \
                (target.get("score") is None or it["score"] > target["score"]):
            target["score"] = it["score"]
            if it.get("poster"):
                target["poster"] = it["poster"]
        if target.get("year") is None and it.get("year") is not None:
            target["year"] = it["year"]
    merged.sort(key=lambda x: (x.get("weight", 0), x.get("score") or 0),
                reverse=True)
    for i, m in enumerate(merged, 1):
        m["rank"] = i
    return merged, id_map


# ---------------------------------------------------------------------------
# hot.json 读写（原子；损坏回退旧数据并告警）
# ---------------------------------------------------------------------------
def load_old_hot() -> Optional[dict]:
    if not os.path.exists(HOT_PATH):
        return None
    try:
        with open(HOT_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except (json.JSONDecodeError, OSError) as e:
        _log.warning("hot.json 读取失败(%s)，按无旧数据处理", e)
        return None


def _stamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def build_hot(fetched: dict, old: Optional[dict]) -> dict:
    """fetched: {tmdb: (items,err), douban: (items,err), maoyan: (items,err)}
    → {updated_at, sections: {global, douban, maoyan}}，每榜独立 updated_at，
    单榜失败复用旧段并标 stale（stale-while-error）。id_map 跨榜主键映射随文件持久化。"""
    now = _stamp()
    old_sec = (old or {}).get("sections") or {}
    id_map = dict((old or {}).get("id_map") or {})
    sections: dict = {}
    fresh_sources, any_new = [], False

    for band in ("tmdb", "douban", "maoyan"):
        items, err = fetched.get(band, ([], "未执行"))
        ok = bool(items) and not err
        if ok:
            fresh_sources.append((band, items))
            any_new = True
            if band == "tmdb":
                continue  # TMDB 不单独成段，内容进融合段 global
            sections[band] = {"updated_at": now, "items": items,
                              "stale": False, "error": None}
        else:  # 失败 → 复用旧段并标注
            old_band = old_sec.get(band) or {}
            sections[band] = {
                "updated_at": old_band.get("updated_at"),
                "items": old_band.get("items") or [],
                "stale": True,
                "error": err,
            }
            _log.warning("榜单 %s 失败(%s)，复用旧段 %d 条",
                         band, err, len(sections[band]["items"]))

    # 融合段 global：本次新数据 + 失败榜旧段数据一起融合（尽力而为）
    if any_new:
        fusion_input = [it for _, items in fresh_sources for it in items]
        for band in ("douban", "maoyan"):
            if sections.get(band, {}).get("stale"):
                fusion_input.extend(sections[band]["items"])
        global_items, id_map = merge_items(fusion_input, id_map)
        sections["global"] = {
            "updated_at": now,
            "items": global_items[:TOP_N * 3],
            "stale": False,
            "error": None,
        }
    elif old_sec.get("global"):  # 三榜全失败 → 复用旧 global 段并标注
        old_g = old_sec["global"]
        sections["global"] = {"updated_at": old_g.get("updated_at"),
                              "items": old_g.get("items") or [],
                              "stale": True, "error": "三榜本次全部失败"}
    else:
        sections["global"] = {"updated_at": now, "items": [], "stale": True,
                              "error": "无可用榜单数据"}

    return {"updated_at": now, "sections": sections, "id_map": id_map,
            "note": "单榜失败段 stale=true 复用旧数据" if not any_new else None}


def run_bands(bands: list) -> dict:
    """并行拉取指定榜单（Semaphore(6) 预算内，3 线程封顶）。"""
    fetchers = {"tmdb": fetch_tmdb, "douban": fetch_douban, "maoyan": fetch_maoyan}
    fetched = {}
    with ThreadPoolExecutor(max_workers=min(3, len(bands))) as ex:
        futs = {b: ex.submit(fetchers[b]) for b in bands}
        for b, f in futs.items():
            fetched[b] = f.result()
    return fetched


def refresh_hot(bands: Optional[list] = None) -> dict:
    """执行榜单刷新并原子写盘。bands=None 表示三榜全刷。"""
    bands = bands or ["tmdb", "douban", "maoyan"]
    fetched = run_bands(bands)
    old = load_old_hot()
    hot = build_hot(fetched, old)
    write_json_atomic(HOT_PATH, hot)
    _log.info("hot.json 已写入: %s (global=%d, douban=%d, maoyan=%d)",
              HOT_PATH,
              len(hot["sections"]["global"]["items"]),
              len(hot["sections"]["douban"]["items"]),
              len(hot["sections"]["maoyan"]["items"]))
    return hot


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main() -> int:
    ap = argparse.ArgumentParser(prog="hot_engine",
                                 description="三榜融合热榜引擎 (Mars TV)")
    ap.add_argument("cmd", choices=["refresh", "tmdb", "douban", "maoyan"],
                    help="refresh=三榜全刷; tmdb/douban/maoyan=只刷单榜")
    args = ap.parse_args()
    bands = {"refresh": ["tmdb", "douban", "maoyan"],
             "tmdb": ["tmdb"], "douban": ["douban"], "maoyan": ["maoyan"]}[args.cmd]
    hot = refresh_hot(bands)
    # 汇总输出（供 cron/人工查看）
    for name, sec in hot["sections"].items():
        n = len(sec["items"])
        flag = " STALE" if sec.get("stale") else ""
        err = f" err={sec['error']}" if sec.get("error") else ""
        print(f"{name}: {n} 条 updated_at={sec.get('updated_at')}{flag}{err}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
