/* ==========================================================================
   Mars TV 云影院 · 首页逻辑（js/home.js）
   - 数据链：/api/hot -> 失败 /hot.json（nginx 静态快照）-> 失败 localStorage 旧数据
   - 降级横幅 + /api/health 30s 轮询，恢复自动撤横幅并刷新数据
   - Hero 轮播（自动/箭头/指示点/触屏滑动）；今日热播；榜单/分类懒加载
   - 继续观看（localStorage）；页脚 N 家资源站；维护弹窗（密码门禁占位）
   - 兜底：Vue CDN 全部失败时 vanilla 渲染，保证不白屏
   ========================================================================== */
(function () {
  'use strict';
  var MT = window.MT;
  if (!MT) { return; }
  var app = document.getElementById('app');
  if (!app) { return; }

  var CATS = ['电影', '电视剧', '综艺', '动漫', '少儿', '纪录片', '短剧'];
  var state = {
    hot: [], hero: [], heroIdx: 0, cw: null, favs: [],
    hotUpdated: '', rankUpdated: '', staleHot: false, rankStale: false,
    rankBlocks: [], rankLoaded: false,
    degraded: false, fromHotJson: false,
    activeCat: '', catTree: null
  };
  var heroTimer = null;

  /* ---------------- /api/hot 返回归一化（数组 / {list} / 三榜对象） ---------------- */
  function normalizeHot(d) {
    if (Array.isArray(d)) { return { list: d, blocks: [], updatedAt: null }; }
    if (!d) { return { list: [], blocks: [], updatedAt: null }; }
    if (Array.isArray(d.list)) { return { list: d.list, blocks: [], updatedAt: d.updated_at || null }; }
    if (Array.isArray(d.hot)) { return { list: d.hot, blocks: [], updatedAt: d.updated_at || null }; }
    var names = { global: '全球热播', douban: '豆瓣口碑', maoyan: '猫眼热映' };
    var blocks = [], ups = [];
    ['global', 'douban', 'maoyan'].forEach(function (k) {
      if (Array.isArray(d[k]) && d[k].length) {
        var u = d[k + '_updated_at'] || d.updated_at;
        blocks.push({ key: k, name: names[k] || k, items: d[k], updatedAt: u });
        if (u) { ups.push(typeof u === 'number' ? u : Date.parse(u)); }
      }
    });
    var updatedAt = ups.length ? Math.max.apply(null, ups) : (d.updated_at || null);
    // 海报 URL 归一化：豆瓣图床走本机 /api/img 代理（防盗链 418）
    function fixPosters(arr) {
      if (!Array.isArray(arr)) { return arr; }
      arr.forEach(function (it) { if (it && it.poster) { it.poster = MT.posterUrl(it.poster); } });
      return arr;
    }
    fixPosters(d.global); fixPosters(d.douban); fixPosters(d.maoyan);
    if (Array.isArray(d.list)) { fixPosters(d.list); }
    if (Array.isArray(d.hot)) { fixPosters(d.hot); }
    // blocks 引用与 d.global/douban/maoyan 相同对象，posterUrl 已幂等，无需重复处理
    return { list: Array.isArray(d.global) ? d.global : [], blocks: blocks, updatedAt: updatedAt, stale: !!d.stale };
  }

  function pickDesc(item) {
    return item.blurb || item.desc || item.intro || item.plot || '';
  }

  /* ---------------- 应用榜单数据到状态/DOM ---------------- */
  function applyHot(n, stale) {
    state.hot = (n.list || []).slice(0, 20);
    state.hero = state.hot.slice(0, 5);
    state.rankBlocks = (n.blocks && n.blocks.length)
      ? n.blocks
      : (state.hot.length ? [{ key: 'hot', name: '今日热播', items: state.hot.slice(0, 12) }] : []);
    var ago = n.updatedAt ? MT.timeAgo(n.updatedAt) : '';
    state.hotUpdated = ago;
    state.rankUpdated = ago;
    state.staleHot = !!stale;
    state.rankStale = !!stale;
    if (stale) {
      MT.degrade.show(state.fromHotJson
        ? '⚠ 后端暂时不可用：展示 /hot.json 快照榜单（每 30s 自动重连）'
        : '⚠ 后端暂时不可用：展示缓存榜单（每 30s 自动重连）');
    } else {
      MT.degrade.hide();
    }
    if (typeof renderVanillaAll === 'function') { renderVanillaAll(); }
  }

  /* ---------------- PWA ServiceWorker 注册（静态壳离线兜底） ---------------- */
  if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js').catch(function () {});
    });
  }

  /* ---------------- 主数据链：/api/hot -> /hot.json -> 旧数据 ---------------- */
  function loadHot() {
    return MT.apiGet('/api/hot', 8000).then(normalizeHot).then(function (n) {
      state.degraded = false; state.fromHotJson = false;
      applyHot(n, n.stale);   // 后端 stale-while-error 标记透传（榜单陈旧提示）
      MT.hotCache.save(n);
      return n;
    }).catch(function () {
      state.fromHotJson = true;
      return fetch('hot.json', { headers: { Accept: 'application/json' }, cache: 'no-cache' })
        .then(function (r) { if (!r.ok) { throw new Error('hot.json ' + r.status); } return r.json(); })
        .then(normalizeHot)
        .then(function (n) { state.degraded = true; applyHot(n, true); return n; })
        .catch(function () {
          var c = MT.hotCache.load();
          if (c) { state.degraded = true; state.fromHotJson = false; applyHot(c, true); return c; }
          state.degraded = true; applyHot({ list: [], blocks: [], updatedAt: null }, true);
          return null;
        });
    });
  }

  /* ---------------- /api/health 30s 轮询：恢复撤横幅 + 刷新 ---------------- */
  function startHealthPoll() {
    MT.pollHealth(function (ok) {
      if (ok && state.degraded) {
        state.degraded = false;
        loadHot();
      }
    }, 30000);
  }

  /* ---------------- Hero 轮播 ---------------- */
  function startHero() {
    clearInterval(heroTimer);
    if (state.hero.length < 2) { return; }
    heroTimer = setInterval(function () {
      state.heroIdx = (state.heroIdx + 1) % state.hero.length;
    }, 5000);
  }
  function bindHeroTouch() {
    var heroEl = document.getElementById('hero');
    if (!heroEl || !('ontouchstart' in window)) { return; }
    var x0 = null;
    heroEl.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; clearInterval(heroTimer); }, { passive: true });
    heroEl.addEventListener('touchend', function (e) {
      if (x0 == null) { return; }
      var dx = e.changedTouches[0].clientX - x0;
      var len = state.hero.length;
      if (Math.abs(dx) > 40) {
        state.heroIdx = dx < 0 ? (state.heroIdx + 1) % len : (state.heroIdx - 1 + len) % len;
      }
      x0 = null; startHero();
    }, { passive: true });
    heroEl.addEventListener('mouseenter', function () { clearInterval(heroTimer); });
    heroEl.addEventListener('mouseleave', startHero);
  }

  /* ---------------- 榜单 / 分类懒加载 ---------------- */
  function setupLazy() {
    MT.lazyLoad(document.getElementById('rankings'), function () {
      if (state.rankLoaded) { return; }
      if (state.rankBlocks.length) { state.rankLoaded = true; return; }
      MT.apiGet('/api/hot', 8000).then(normalizeHot).then(function (n) {
        state.rankBlocks = (n.blocks && n.blocks.length)
          ? n.blocks
          : (n.list && n.list.length ? [{ key: 'hot', name: '今日热播', items: n.list.slice(0, 12) }] : []);
      }).catch(function () {}).finally(function () { state.rankLoaded = true; });
    });
    MT.lazyLoad(document.getElementById('categories'), loadCategories);
  }

  function loadCategories() {
    var slot = document.getElementById('cat-chips');
    if (!slot) { return; }
    MT.apiGet('/api/categories', 5000).then(function (d) {
      var cats = Array.isArray(d) ? d : (d && d.categories);
      var tree = (d && d.tree) || null;
      state.catTree = tree;
      renderCats(cats && cats.length ? cats : CATS);
    }).catch(function () { renderCats(CATS); });
  }
  /* 一级 chips 渲染；默认展开第一个分类的二级子类 */
  function renderCats(cats) {
    var slot = document.getElementById('cat-chips');
    if (!slot) { return; }
    if (!state.activeCat && cats && cats.length) {
      var first = typeof cats[0] === 'string' ? cats[0] : (cats[0].id || cats[0].name);
      state.activeCat = first || '';
    }
    slot.innerHTML = '';
    cats.forEach(function (c) {
      var name = typeof c === 'string' ? c : (c.name || c.title || '');
      var id = typeof c === 'string' ? c : (c.id || name);
      if (!name) { return; }
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'cat-chip' + (id === state.activeCat ? ' active' : '');
      b.setAttribute('data-cat', id);
      b.textContent = name;
      b.setAttribute('aria-pressed', id === state.activeCat ? 'true' : 'false');
      b.addEventListener('click', function () { setActiveCat(id); });
      slot.appendChild(b);
    });
    renderSubCats();
  }
  /* 一级切换：高亮 + 重渲染二级子类行 */
  function setActiveCat(id) {
    state.activeCat = id;
    var chips = document.querySelectorAll('#cat-chips .cat-chip');
    chips.forEach(function (c) {
      var on = c.getAttribute('data-cat') === id;
      c.classList.toggle('active', on);
      c.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    renderSubCats();
  }
  /* 二级子类行：全部入口 + 各子类，跳 search.html?t=&sub= */
  function renderSubCats() {
    var subSlot = document.getElementById('cat-sub-chips');
    if (!subSlot) { return; }
    var cat = state.activeCat || '';
    var tree = state.catTree || MT.categoryTree || {};
    var subs = (tree && tree[cat]) || [];
    subSlot.innerHTML = '';
    if (!cat || !subs || !subs.length) { subSlot.hidden = true; return; }
    subSlot.hidden = false;
    var all = document.createElement('a');
    all.className = 'cat-chip cat-sub-chip cat-chip-all';
    all.href = 'search.html?t=' + encodeURIComponent(cat);
    all.textContent = '全部' + cat;
    subSlot.appendChild(all);
    subs.forEach(function (s) {
      var a = document.createElement('a');
      a.className = 'cat-chip cat-sub-chip';
      a.href = 'search.html?t=' + encodeURIComponent(cat) + '&sub=' + encodeURIComponent(s);
      a.textContent = s;
      subSlot.appendChild(a);
    });
  }

  /* ---------------- 搜索 / 底部导航 ---------------- */
  function initSearch() {
    var form = document.getElementById('search-form');
    var input = document.getElementById('global-search');
    var bnSearch = document.getElementById('bn-search');
    if (form && input) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var wd = input.value.trim();
        window.location.href = 'search.html?wd=' + encodeURIComponent(wd || '');
      });
    }
    if (bnSearch) {
      bnSearch.addEventListener('click', function (e) {
        e.preventDefault();
        if (input) { input.focus(); }
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    }
  }

  /* ---------------- 维护弹窗（密码门禁占位，源池状态展示） ---------------- */
  // 内联 SHA-256（非 HTTPS 下 crypto.subtle 不可用；仅用于门禁密码比对，不落明文）
  function sha256(ascii) {
    function rrot(n, x) { return (x >>> n) | (x << (32 - n)); }
    var mathPow = Math.pow, maxWord = mathPow(2, 32), result = '', words = [], i, j, tmp;
    var asciiBitLength = ascii.length * 8;
    var hash = sha256.h = sha256.h || [];
    var k = sha256.k = sha256.k || [];
    var primeCounter = k.length;
    var isComposite = {};
    for (var candidate = 2; primeCounter < 64; candidate++) {
      if (!isComposite[candidate]) {
        for (i = 0; i < 313; i += candidate) { isComposite[i] = candidate; }
        hash[primeCounter] = (mathPow(candidate, .5) * maxWord) | 0;
        k[primeCounter++] = (mathPow(candidate, 1 / 3) * maxWord) | 0;
      }
    }
    ascii += '\x80';
    while (ascii.length % 64 - 56) { ascii += '\x00'; }
    for (i = 0; i < ascii.length; i++) {
      j = ascii.charCodeAt(i);
      if (j >> 8) { return; }
      words[i >> 2] |= j << ((3 - i) % 4) * 8;
    }
    words[words.length] = ((asciiBitLength / maxWord) | 0);
    words[words.length] = (asciiBitLength);
    for (j = 0; j < words.length;) {
      var w = words.slice(j, j += 16), oldHash = hash.slice(0);
      hash = hash.slice(0, 8);
      for (i = 0; i < 64; i++) {
        var w15 = w[i - 15], w2 = w[i - 2];
        var a = hash[0], e = hash[4];
        var temp1 = hash[7]
          + (rrot(6, e) ^ rrot(11, e) ^ rrot(25, e))
          + ((e & hash[5]) ^ (~e & hash[6]))
          + k[i]
          + (w[i] = (i < 16) ? w[i] : (w[i - 16]
            + (rrot(7, w15) ^ rrot(18, w15) ^ (w15 >>> 3))
            + w[i - 7]
            + (rrot(17, w2) ^ rrot(19, w2) ^ (w2 >>> 10))) | 0);
        var temp2 = (rrot(2, a) ^ rrot(13, a) ^ rrot(22, a))
          + ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));
        hash = [(temp1 + temp2) | 0].concat(hash);
        hash[4] = (hash[4] + temp1) | 0;
      }
      for (i = 0; i < 8; i++) { hash[i] = (hash[i] + oldHash[i]) | 0; }
    }
    for (i = 0; i < 8; i++) {
      for (j = 3; j + 1; j--) {
        var b = (hash[i] >> (j * 8)) & 255;
        result += ((b < 16) ? 0 : '') + b.toString(16);
      }
    }
    return result;
  }
  function initMaintenance() {
    var btn = document.getElementById('maintenance-btn');
    var modal = document.getElementById('maint-modal');
    var body = document.getElementById('maint-body');
    var close = document.getElementById('maint-close');
    if (!btn || !modal) { return; }
    function open() {
      // 密码不落明文：SHA-256 摘要比对（防 F12 直接读源码看到默认密码）
      var pass = window.prompt('请输入维护密码：');
      if (pass === null) { return; }
      var want = '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'; // 123456 的 SHA-256
      if (pass === '' || sha256(pass) !== want) { window.alert('密码错误'); return; }
      modal.hidden = false;
      body.innerHTML = '<p>加载中…</p>';
      MT.apiGet('/api/sources', 6000).then(function (d) {
        var arr = Array.isArray(d) ? d : (d && d.sources) || [];
        var n = arr.length || (d && (d.count != null ? d.count : d.total)) || 0;
        var active = (d && d.active != null) ? d.active
          : arr.filter(function (s) { return s.status !== 'down' && s.healthy !== false; }).length;
        var broken = (d && d.broken != null) ? d.broken
          : arr.filter(function (s) { return s.status === 'down' || s.healthy === false; }).length;
        var fuse = (d && d.fused != null) ? d.fused : 0;
        var html = '<p>资源站总数：<span class="stat">' + n + '</span> 家</p>' +
          '<p>活跃源：<span class="stat">' + active + '</span> 家</p>' +
          '<p>异常/熔断：<span class="stat">' + (broken + fuse) + '</span> 家</p>' +
          '<ul>' + arr.slice(0, 12).map(function (s) {
            var nm = s.name || s.url || '?';
            var st = (s.status === 'down' || s.healthy === false) ? '🔴' : '🟢';
            return '<li>' + st + ' ' + MT.esc(nm) + (s.score != null ? '（评分 ' + s.score + '）' : '') + '</li>';
          }).join('') + '</ul>' +
          '<p style="font-size:13px">自动源管理引擎每 30 分钟更新源池，6 小时探索新源。</p>';
        body.innerHTML = html;
      }).catch(function () {
        body.innerHTML = '<p>后端暂不可用（降级模式），源池状态无法获取。</p>' +
          '<p style="font-size:13px">当前展示 /hot.json 快照或缓存榜单，后端恢复后自动更新。</p>';
      });
    }
    btn.addEventListener('click', open);
    close.addEventListener('click', function () { modal.hidden = true; });
    modal.addEventListener('click', function (e) { if (e.target === modal) { modal.hidden = true; } });
  }

  /* ---------------- Vue 渲染 ---------------- */
  function initVue() {
    state = Vue.reactive(state); // 关键：闭包 state 指向响应式代理，applyHot 的修改才能触发模板更新
    Vue.createApp({
      data: function () { return state; },
      methods: {
        heroPrev: function () {
          var len = this.hero.length;
          this.heroIdx = (this.heroIdx - 1 + len) % len;
        },
        heroNext: function () {
          var len = this.hero.length;
          this.heroIdx = (this.heroIdx + 1) % len;
        },
        clearFavs: function () {
          MT.favorites.save([]);
          this.favs = [];
        }
      },
      mounted: function () {
        startHero();
        bindHeroTouch();
      }
    }).mount('#app');
  }

  /* ---------------- Vanilla 兜底渲染（Vue CDN 全挂时不白屏） ---------------- */
  function renderVanillaAll() {
    if (window.Vue) { return; } // Vue 模式下由模板渲染
    app.removeAttribute('v-cloak');
    /* Hero：仅展示第一张 */
    var heroEl = document.getElementById('hero');
    if (heroEl && state.hero.length) {
      var first = state.hero[0];
      heroEl.innerHTML = '<div class="hero-slide active">' +
        '<div class="hero-bg" style="background-image:url(\'' + MT.esc(first.poster || '') + '\')"></div>' +
        '<div class="hero-mask"></div>' +
        '<div class="hero-content">' +
        '<span class="hero-tag">今日热播</span>' +
        '<h1 class="hero-title">' + MT.esc(first.title || '') + '</h1>' +
        (first.score ? '<p class="hero-meta"><span class="hero-score">★ ' + MT.esc(first.score) + '</span></p>' : '') +
        (pickDesc(first) ? '<p class="hero-desc">' + MT.esc(pickDesc(first)) + '</p>' : '') +
        '<div class="hero-actions">' +
        '<a class="btn-gold" href="detail.html?id=' + encodeURIComponent(first.id) + '">立即播放</a>' +
        '<a class="btn-ghost" href="detail.html?id=' + encodeURIComponent(first.id) + '">查看详情</a>' +
        '</div></div></div>';
    } else if (heroEl) {
      heroEl.innerHTML = '<div class="hero-loading"><div class="skeleton skeleton-hero"></div></div>';
    }
    /* 今日热播行 */
    var row = document.getElementById('hot-row');
    if (row) {
      row.innerHTML = '';
      if (state.hot.length) {
        MT.renderInBatches(state.hot, row, 20, function (item, i) {
          var d = document.createElement('div');
          d.innerHTML = MT.posterCard(item, { showRank: i < 3, priority: i < 6 });
          return d.firstChild;
        });
      } else {
        row.innerHTML = '<p class="empty-note">榜单更新中，请稍后刷新…</p>';
      }
    }
    /* 榜单块 */
    var slot = document.getElementById('rankings-slot');
    if (slot) {
      slot.innerHTML = '';
      state.rankBlocks.forEach(function (bk) {
        var wrap = document.createElement('div');
        wrap.className = 'rank-block';
        wrap.innerHTML = '<h3 class="block-sub">' + MT.esc(bk.name) + '</h3><div class="poster-row"></div>';
        var r = wrap.querySelector('.poster-row');
        MT.renderInBatches(bk.items, r, 20, function (item, i) {
          var d = document.createElement('div');
          d.innerHTML = MT.posterCard(item, { showRank: true });
          return d.firstChild;
        });
        slot.appendChild(wrap);
      });
      if (!state.rankBlocks.length) {
        slot.innerHTML = '<p class="empty-note">榜单更新中，稍后自动重试…</p>';
      }
    }
    /* 继续观看（列表，最多 20 个） */
    var cwSec = document.getElementById('continue-watching');
    if (cwSec && state.cw && state.cw.length) {
      cwSec.style.display = '';
      // vanilla 兜底：至少填第一张
      var first = state.cw[0];
      var imgs = cwSec.querySelectorAll('img');
      if (imgs.length && first) { imgs[0].src = first.poster || ''; }
    }
    /* 分类 */
    if (document.getElementById('cat-chips')) { loadCategories(); }
  }

  /* ---------------- 启动：等 Vue（最多 3s），否则 vanilla ---------------- */
  function afterInit() {
    state.cw = MT.continueWatching.load();
    state.favs = MT.favorites.load();
    loadHot().then(function () {
      setupLazy();
      startHealthPoll();
    }).catch(function () { setupLazy(); startHealthPoll(); });
    MT.fillSourceCount();
    initSearch();
    initMaintenance();
  }
  function boot() {
    var tries = 0;
    (function waitVue() {
      if (window.Vue) { initVue(); afterInit(); }
      else if (++tries < 30) { setTimeout(waitVue, 100); }
      else { renderVanillaAll(); afterInit(); }
    })();
  }
  boot();
})();
