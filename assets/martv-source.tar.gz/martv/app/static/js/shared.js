/* ==========================================================================
   Mars TV 云影院 · 共享前端工具（js/shared.js）
   - fetch 封装：只走相对路径 /api/...，统一解 {code,data,msg} 包装
   - 海报卡片渲染器 / 骨架屏 / 分批渲染(<=20) / IntersectionObserver 懒加载
   - 降级：/api/hot 失败 -> /hot.json 静态快照 -> localStorage 旧数据
   - /api/health 30s 轮询，后端恢复自动撤降级横幅
   - localStorage "继续观看" 记录/读取
   ========================================================================== */
(function (global) {
  'use strict';
  var MT = global.MT || (global.MT = {});
  var CW_KEY = 'martv_continue_watching';
  var HOT_CACHE_KEY = 'martv_hot_cache';
  var FAV_KEY = 'martv_favorites';

  /* ---------------- 追剧收藏（localStorage，轻量版） ---------------- */
  MT.favorites = {
    load: function () {
      try { return JSON.parse(localStorage.getItem(FAV_KEY)) || []; } catch (e) { return []; }
    },
    save: function (list) {
      try { localStorage.setItem(FAV_KEY, JSON.stringify(list.slice(0, 200))); } catch (e) { /* noop */ }
    },
    has: function (id) {
      return this.load().some(function (f) { return f.id === id; });
    },
    toggle: function (item) {
      var list = this.load();
      var i = list.findIndex(function (f) { return f.id === item.id; });
      if (i >= 0) { list.splice(i, 1); this.save(list); return false; }
      list.unshift({ id: item.id, title: item.title, year: item.year || '',
                     poster: item.poster || '', type: item.type || '',
                     ts: Date.now() });
      this.save(list);
      return true;
    }
  };

  /* ---------------- fetch 封装：相对路径 /api/...，解 {code,data,msg} ---------------- */
  function apiGet(path, timeoutMs) {
    timeoutMs = timeoutMs || 10000;
    var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
    var timer = ctrl ? setTimeout(function () { ctrl.abort(); }, timeoutMs) : null;
    return fetch(path, {
      signal: ctrl ? ctrl.signal : undefined,
      headers: { Accept: 'application/json' },
      cache: 'no-cache'
    }).then(function (res) {
      if (!res.ok) { throw new Error('HTTP ' + res.status); }
      return res.json();
    }).then(function (j) {
      // 统一 {code,data,msg}；也兼容裸数组/裸对象
      if (j && typeof j === 'object' && 'code' in j) {
        if (j.code !== 0 && j.code !== 200) { throw new Error((j.msg || 'API code ' + j.code)); }
        return j.data;
      }
      return j;
    }).catch(function (e) {
      if (timer) { clearTimeout(timer); }
      throw e;
    }).finally(function () { if (timer) { clearTimeout(timer); } });
  }
  MT.apiGet = apiGet;

  /* ---------------- 骨架屏 ---------------- */
  function skeletonCard() {
    return '<div class="skeleton skeleton-card" aria-hidden="true"></div>';
  }
  function skeletonChips(n) {
    n = n || 6; var h = '';
    for (var i = 0; i < n; i++) { h += '<div class="skeleton skeleton-chip" style="width:' + (80 + (i * 13) % 60) + 'px" aria-hidden="true"></div>'; }
    return h;
  }
  MT.skeletonCard = skeletonCard;
  MT.skeletonChips = skeletonChips;

  /* ---------------- 海报卡片渲染器 ---------------- */
  /* ---------------- 海报 URL 归一化：豆瓣图床反盗链（无 Referer 418）走本机 /api/img 代理 ---------------- */
  function posterUrl(u) {
    if (!u) { return ''; }
    // 幂等：已是本机代理 URL 不再包
    if (/^\/api\/img\?url=/.test(u)) { return u; }
    // 豆瓣图床 / TMDB 图片域（国内被墙）走本机 /api/img 代理
    if (/doubanio\.com/i.test(u) || /image\.tmdb\.org/i.test(u)) {
      return '/api/img?url=' + encodeURIComponent(u);
    }
    return u;
  }
  MT.posterUrl = posterUrl;

  /* item: {id,title,poster,score,year,source,rank}；返回 HTML 字符串 */
  function posterCard(item, opts) {
    opts = opts || {};
    var id = encodeURIComponent(item.id != null ? item.id : '');
    var title = item.title || '未命名';
    var poster = posterUrl(item.poster || '');
    var score = item.score ? '<span class="poster-score">★' + esc(item.score) + '</span>' : '';
    var rank = (opts.showRank && item.rank != null) ? '<span class="rank-badge">' + esc(item.rank) + '</span>' : '';
    var src = item.source ? '<span class="src-badge">' + esc(String(item.source).slice(0, 8)) + '</span>' : '';
    var href = 'detail.html?id=' + id;
    // 预加载首屏/前几张（fetchpriority=high 仅前 6 张），其余 lazy + decoding=async
    var fp = (opts.priority === true) ? ' fetchpriority="high"' : '';
    // 无海报：渐变占位（片名首字 + 深色渐变），不空白
    if (!poster) {
      var ch = esc((title || '?').slice(0, 1));
      var ph = '<span class="poster-ph">' + ch + '</span>';
      return '<a class="poster-card poster-card-ph" href="' + href + '" data-id="' + id + '" data-title="' + esc(title) + '">' +
        ph + rank + src + '<span class="poster-title">' + esc(title) + '</span>' + score + '</a>';
    }
    return '<a class="poster-card" href="' + href + '" data-id="' + id + '" data-title="' + esc(title) + '">' +
      '<img src="' + esc(poster) + '" alt="' + esc(title) + '" loading="lazy" decoding="async"' + fp +
      ' onerror="this.parentNode.classList.add(\'poster-card-ph\');this.remove()">' +
      rank + src + '<span class="poster-title">' + esc(title) + '</span>' + score + '</a>';
  }
  MT.posterCard = posterCard;

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  MT.esc = esc;

  /* ---------------- 分类体系（与后端 category_engine.py 一致） ----------------
     7 个一级分类 + 二级子类；TYPE_NORM 精确归一化表 + fuzzy 包含匹配兜底。
     normTypeName: "喜剧片"→"喜剧"、"动作片"→"动作"、"港剧"→"港台剧"、"儿童"→"少儿" 等。
  ---------------------------------------------------------------------------- */
  var CATEGORIES = ['电影', '电视剧', '综艺', '动漫', '少儿', '纪录片', '短剧'];
  var CATEGORY_TREE = {
    '电影': ['动作', '喜剧', '爱情', '科幻', '悬疑', '恐怖', '剧情', '战争', '犯罪', '冒险', '奇幻', '动画'],
    '电视剧': ['国产剧', '港台剧', '日韩剧', '欧美剧', '泰剧', '海外剧'],
    '综艺': ['大陆综艺', '港台综艺', '日韩综艺', '欧美综艺'],
    '动漫': ['国产动漫', '日韩动漫', '欧美动漫', '港台动漫'],
    '少儿': ['少儿'],
    '纪录片': ['纪录片'],
    '短剧': ['短剧']
  };
  var TYPE_NORM = {
    // 电影类子类
    '喜剧片': '喜剧', '动作片': '动作', '爱情片': '爱情', '科幻片': '科幻',
    '悬疑片': '悬疑', '恐怖片': '恐怖', '剧情片': '剧情', '战争片': '战争',
    '犯罪片': '犯罪', '冒险片': '冒险', '奇幻片': '奇幻', '动画片': '动画',
    // 电视剧类子类（归入电视剧一级分类）
    '国产剧': '国产剧', '内地剧': '国产剧',
    '港剧': '港台剧', '台剧': '港台剧', '香港剧': '港台剧', '台湾剧': '港台剧',
    '日剧': '日韩剧', '韩剧': '日韩剧', '日本剧': '日韩剧', '韩国剧': '日韩剧',
    '美剧': '欧美剧', '英剧': '欧美剧', '美国剧': '欧美剧', '英国剧': '欧美剧',
    '泰剧': '泰剧', '海外剧': '海外剧',
    // 综艺类子类
    '大陆综艺': '大陆综艺', '内地综艺': '大陆综艺', '港台综艺': '港台综艺',
    '日韩综艺': '日韩综艺', '欧美综艺': '欧美综艺',
    // 动漫类子类
    '国产动漫': '国产动漫', '日韩动漫': '日韩动漫', '欧美动漫': '欧美动漫',
    '港台动漫': '港台动漫',
    // 独立一级分类
    '少儿': '少儿', '儿童': '少儿', '亲子': '少儿',
    '纪录片': '纪录片', '纪实': '纪录片', '纪实片': '纪录片',
    '短剧': '短剧', '微短剧': '短剧'
  };
  /* type_name/vod_class 首段 → 规范子类名；精确命中优先，fuzzy 最长子类名包含兜底 */
  function normTypeName(t) {
    t = String(t == null ? '' : t).trim();
    if (!t) { return ''; }
    if (Object.prototype.hasOwnProperty.call(TYPE_NORM, t)) { return TYPE_NORM[t]; }
    var best = null;
    Object.keys(CATEGORY_TREE).forEach(function (cat) {
      (CATEGORY_TREE[cat] || []).forEach(function (sub) {
        if (sub && t.indexOf(sub) !== -1 && (best === null || sub.length > best.length)) {
          best = sub;
        }
      });
    });
    return best || t;
  }
  MT.categories = CATEGORIES;
  MT.categoryTree = CATEGORY_TREE;
  MT.normTypeName = normTypeName;

  /* ---------------- 分批渲染：每批 <=20，防双核老机卡顿 ---------------- */
  function renderInBatches(items, container, batchSize, renderItem, onDone) {
    if (!container) { return; }
    batchSize = batchSize || 20;
    var i = 0;
    var frag = document.createDocumentFragment();
    (function next() {
      var end = Math.min(i + batchSize, items.length);
      for (; i < end; i++) {
        frag.appendChild(renderItem(items[i]));
      }
      if (i < items.length) {
        container.appendChild(frag);
        frag = document.createDocumentFragment();
        requestAnimationFrame(next);
      } else {
        container.appendChild(frag);
        if (onDone) { onDone(); }
      }
    })();
  }
  MT.renderInBatches = renderInBatches;

  /* ---------------- IntersectionObserver 懒加载：进入视口触发一次 ---------------- */
  function lazyLoad(trigger, loaderFn) {
    if (!trigger || typeof loaderFn !== 'function') { return; }
    if (typeof IntersectionObserver === 'undefined') { loaderFn(); return; }
    var done = false;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting && !done) {
          done = true; io.disconnect();
          loaderFn();
        }
      });
    }, { rootMargin: '200px 0px' });
    io.observe(trigger);
  }
  MT.lazyLoad = lazyLoad;

  /* ---------------- 降级横幅 ---------------- */
  function showBanner(msg) {
    var b = document.getElementById('degrade-banner');
    if (!b) { return; }
    b.textContent = msg || '⚠ 后端暂时不可用，正在展示缓存榜单（每 30s 自动重连）';
    b.hidden = false;
    document.body.classList.add('banner-on');
  }
  function hideBanner() {
    var b = document.getElementById('degrade-banner');
    if (b) { b.hidden = true; }
    document.body.classList.remove('banner-on');
  }
  MT.degrade = { show: showBanner, hide: hideBanner };

  /* ---------------- /api/health 轮询：恢复后回调 ---------------- */
  function pollHealth(cb, intervalMs) {
    intervalMs = intervalMs || 30000;
    return setInterval(function () {
      apiGet('/api/health', 5000).then(function (d) {
        var ok = !!(d && (d.status === 'ok' || d.status === 'up' || d.ok === true || d.code === 0 || d.code === 200));
        if (ok && typeof cb === 'function') { cb(true); }
      }).catch(function () {});
    }, intervalMs);
  }
  MT.pollHealth = pollHealth;

  /* ---------------- localStorage 旧数据缓存（空榜显旧数据 + 更新中） ---------------- */
  function cacheHot(data) {
    try {
      localStorage.setItem(HOT_CACHE_KEY, JSON.stringify({ t: Date.now(), data: data }));
    } catch (e) { /* 隐私模式忽略 */ }
  }
  function loadHotCache() {
    try {
      var j = JSON.parse(localStorage.getItem(HOT_CACHE_KEY) || 'null');
      return j && j.data ? j.data : null;
    } catch (e) { return null; }
  }
  MT.hotCache = { save: cacheHot, load: loadHotCache };

  /* ---------------- localStorage 继续观看 ---------------- */
  var CW_MAX = 20;   // 继续观看最多保留 20 个（用户要求：不被新片顶掉）
  function saveProgress(entry) {
    try {
      entry.updatedAt = Date.now();
      if (entry.total > 0) { entry.pct = Math.min(99, Math.round(entry.progress / entry.total * 100)); }
      else { entry.pct = 0; }
      var list = loadProgress() || [];
      // 同片更新（移到最前），新片插入头部；最多保留 CW_MAX 个
      list = list.filter(function (e) { return e && e.id !== entry.id; });
      list.unshift(entry);
      if (list.length > CW_MAX) { list = list.slice(0, CW_MAX); }
      localStorage.setItem(CW_KEY, JSON.stringify(list));
    } catch (e) { /* 忽略 */ }
  }
  function loadProgress() {
    try {
      var j = JSON.parse(localStorage.getItem(CW_KEY) || 'null');
      if (j == null) { return []; }
      // 兼容旧版单对象数据（2026-08-03 前）：包成数组
      if (!Array.isArray(j)) { j = [j]; }
      j.forEach(function (e) { if (e && e.pct == null && e.total > 0) { e.pct = Math.round(e.progress / e.total * 100); } });
      return j;
    } catch (e) { return []; }
  }
  function clearProgress() {
    try { localStorage.removeItem(CW_KEY); } catch (e) { /* 忽略 */ }
  }
  MT.continueWatching = { save: saveProgress, load: loadProgress, clear: clearProgress };

  /* ---------------- 时间工具：更新于 X 小时前 ---------------- */
  function timeAgo(ts) {
    if (!ts) { return ''; }
    var t = typeof ts === 'number' ? ts : Date.parse(ts);
    if (isNaN(t)) { return ''; }
    var diff = Math.max(0, Date.now() - t) / 1000;
    if (diff < 60) { return '更新于刚刚'; }
    if (diff < 3600) { return '更新于 ' + Math.floor(diff / 60) + ' 分钟前'; }
    if (diff < 86400) { return '更新于 ' + Math.floor(diff / 3600) + ' 小时前'; }
    return '更新于 ' + Math.floor(diff / 86400) + ' 天前';
  }
  MT.timeAgo = timeAgo;

  /* ---------------- 资源计数：/api/sources 填页脚 N ---------------- */
  function fillSourceCount() {
    var el = document.getElementById('src-count');
    if (!el) { return; }
    apiGet('/api/sources', 5000).then(function (d) {
      var n = 0;
      // 优先活跃源数（页脚显示"当前可用"而非接入过的总数，避免 26 vs 2 的落差）
      if (d && (d.active != null)) { n = d.active; }
      else if (Array.isArray(d)) { n = d.length; }
      else if (d && d.sources && d.sources.length) { n = d.sources.length; }
      else if (d && (d.count != null)) { n = d.count; }
      else if (d && (d.total != null)) { n = d.total; }
      if (n > 0) { el.textContent = n; }
    }).catch(function () { /* 后端未起：保留 "N" */ });
  }
  MT.fillSourceCount = fillSourceCount;

  /* ---------------- CDN 兜底加载器（每个 CDN script 后的 fallback 链） ---------------- */
  function loadScript(url) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = url;
      s.async = true;
      s.onload = function () { resolve(url); };
      s.onerror = function () { s.remove(); reject(new Error('load fail: ' + url)); };
      document.head.appendChild(s);
    });
  }
  function loadCss(url) {
    return new Promise(function (resolve, reject) {
      var l = document.createElement('link');
      l.rel = 'stylesheet';
      l.href = url;
      l.onload = function () { resolve(url); };
      l.onerror = function () { l.remove(); reject(new Error('css fail: ' + url)); };
      document.head.appendChild(l);
    });
  }
  /* 按序尝试候选 URL 列表（多个 CDN -> 最后本地 /vendor/ 兜底），全挂不抛错 */
  function loadWithFallback(candidates, done) {
    var i = 0;
    function next() {
      if (i >= candidates.length) { if (done) { done(false); } return; }
      var p = /\.css(\?|$)/.test(candidates[i]) ? loadCss(candidates[i]) : loadScript(candidates[i]);
      p.then(function () { if (done) { done(true); } })
       .catch(function () { i++; next(); });
    }
    next();
  }
  MT.loadWithFallback = loadWithFallback;

  /* v-cloak 由 home.js 统一移除（Vue 挂载时自动移除；vanilla 兜底渲染时手动移除） */
})(window);
