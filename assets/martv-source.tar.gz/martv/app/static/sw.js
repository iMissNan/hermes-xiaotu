/* Mars TV PWA Service Worker：网络优先 + 静态壳缓存（老机器秒开） */
'use strict';
var CACHE = 'martv-v1';

self.addEventListener('install', function (e) {
  e.waitUntil(
    caches.open(CACHE).then(function (c) {
      return c.addAll([
        '/',
        '/index.html',
        '/css/theme.css',
        '/js/shared.js',
        '/js/home.js',
        '/manifest.webmanifest',
        '/icons/icon-192.png',
        '/icons/icon-512.png',
        '/vendor/bootstrap.min.css',
        '/vendor/bootstrap.bundle.min.js',
        '/vendor/vue.global.prod.js'
      ]).catch(function () { /* 单项失败不阻塞安装 */ });
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', function (e) {
  e.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); }));
    }).then(function () { return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function (e) {
  var url = e.request.url;
  // API 与跨域请求永不缓存（保持实时）
  if (url.indexOf('/api/') !== -1 || url.indexOf('http') !== 0 || e.request.method !== 'GET') { return; }
  // 页面导航：网络优先，离线回缓存壳
  if (e.request.mode === 'navigate') {
    e.respondWith(
      fetch(e.request).then(function (r) {
        var copy = r.clone();
        caches.open(CACHE).then(function (c) { c.put('/index.html', copy); });
        return r;
      }).catch(function () { return caches.match('/index.html'); })
    );
    return;
  }
  // 静态资源：缓存优先，回源更新
  e.respondWith(
    caches.match(e.request).then(function (hit) {
      if (hit) {
        fetch(e.request).then(function (r) {
          if (r && r.ok) { caches.open(CACHE).then(function (c) { c.put(e.request, r); }); }
        }).catch(function () {});
        return hit;
      }
      return fetch(e.request).then(function (r) {
        var copy = r.clone();
        caches.open(CACHE).then(function (c) { c.put(e.request, copy); });
        return r;
      });
    })
  );
});
