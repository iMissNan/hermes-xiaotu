"""分类浏览引擎 —— 多源聚合 /api/category（2026-08-02 新增，执行计划落地）。

关键事实（2026-08-02 实测验证）:
- 苹果CMS ac=list 的 t 参数只对"叶子分类"返回数据：暴风 t=21(动作片) 4978 条 /
  t=20(电影片父级) 仅 12 条；无极 t=6(动作片) 5025 条 / t=1(电影) 0 条。
  → 一级分类必须按其子分类 type_id 逐个拉取合并；二级 sub 直达其叶子 type_id。
- 分类树取自 ac=list&pg=1 响应 class 段（type_id/type_pid/type_name），LRU 缓存 6h；
  树缺 type_pid（扁平树，如无极）时以名称 fuzzy 匹配兜底归并子类。
- 类型归一化：fuzzy 包含匹配（"动作片"含"动作"即归入动作；"纪录片"匹配"纪录"）。
- 单源单请求 8s 超时；源内按全局 deadline 提前放弃后续子分类；失败跳过不影响整体；
  分类缺失（树中无该类）不算失败不计数。
- 聚合去重：片名归一化+年份模糊去重，保留评分/海报更优者（与 /api/search 一致）。

约束: 只读依赖 source_engine._cms_get / store 注入实例；不修改 utils/source_engine。
"""

from __future__ import annotations

import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from source_engine import CMS_STD_PATH, SEM, _cms_get  # noqa: E402
from hot_engine import _norm_title  # noqa: E402  片名归一化（与 /api/search 去重共用）
from xiaoya_meta import xiaoya  # noqa: E402  小雅元数据引擎（分类聚合时补 year/poster）
from utils import LRUCache, SEMAPHORE_LIMIT  # noqa: E402

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------
CAT_TIMEOUT = 12.0         # 单请求超时（等价 curl --max-time 12；多页拉取放宽）
CAT_TREE_TTL = 21600       # 分类树缓存 6h（分类结构极少变动）
CAT_PAGE_SIZE = 24         # 聚合后每页卡片数
CAT_MAX_PER_TID = 20       # 每个子分类每页最多取 20 条
CAT_PAGES = 3              # 每个子分类拉取页数（页并发；扩池：单页 20 条撑不起年份筛选/无限滚动）
CAT_MAX_SUBS = 5           # 无 sub 时每源最多拉取子分类数（父分类 + 前 N 个子分类）
# 年份定向拉取：源接口支持 ac=list&year=YYYY（实测暴风 2025 有 15,470 部、
# 豪华 20,318、360 10,563；而分类树只挖到 73 部/年的 0.3%）。
# 一级分类聚合时额外按近 N 年定向拉取，条目 year 由服务器过滤保证，直接强标记。
CAT_YEARS = (2026, 2025, 2024, 2023)   # 定向年份（近 4 年，覆盖"最近火"）
YEAR_PAGES = 30                         # 每年拉取页数（30 页 × 20 条 = 600 条/年/源；
                                        # 实测甜点位：30 页→2025 电影 742 部；50 页不增反降
                                        # （636，源端深分页限流/重复，速播失败），
                                        # 预热一轮 ~124s + 300s < TTL 600s 安全）

# ---------------------------------------------------------------------------
# 分类体系：7 个一级分类 + 二级子类（fuzzy 包含匹配 needles）
# 一级匹配 needles 命中分类树 type_name；二级同理（"动作"→"动作片"）。
# ---------------------------------------------------------------------------
CATEGORY_TREE = {
    "电影": {
        "needles": ("电影",),
        "scope": ("片", "电影"),   # 扁平树子类归属词：动作片/喜剧片等
        "subs": {
            "动作": ("动作",), "喜剧": ("喜剧",), "爱情": ("爱情",),
            "科幻": ("科幻",), "悬疑": ("悬疑",), "恐怖": ("恐怖",),
            "剧情": ("剧情",), "战争": ("战争",), "犯罪": ("犯罪",),
            "冒险": ("冒险",), "奇幻": ("奇幻",), "动画": ("动画",),
        },
    },
    "电视剧": {
        "needles": ("电视剧", "连续剧", "剧集"),
        "scope": ("剧",),        # 国产剧/港剧/日剧 等
        "subs": {
            "国产剧": ("国产", "内地", "大陆"), "港台剧": ("港台", "香港", "台湾"),
            "日韩剧": ("日韩", "日本", "韩国"), "欧美剧": ("欧美",),
            "泰剧": ("泰国",), "海外剧": ("海外",),
        },
    },
    "综艺": {
        "needles": ("综艺",),
        "scope": ("综艺",),
        "subs": {
            "大陆综艺": ("大陆", "内地"), "港台综艺": ("港台", "香港", "台湾"),
            "日韩综艺": ("日韩", "日本", "韩国"), "欧美综艺": ("欧美",),
        },
    },
    "动漫": {
        "needles": ("动漫", "动画"),
        "scope": ("动漫", "动画"),   # 中国动漫/日本动漫 等
        "subs": {
            "国产动漫": ("国产", "中国", "内地", "大陆"),
            "日韩动漫": ("日韩", "日本", "韩国"),
            "欧美动漫": ("欧美",), "港台动漫": ("港台", "香港", "台湾"),
        },
    },
    "少儿": {
        "needles": ("少儿", "儿童", "亲子"),
        "scope": ("少儿", "儿童", "亲子"),
        "subs": {"少儿": ("少儿", "儿童", "亲子")},
    },
    "纪录片": {
        "needles": ("纪录", "纪实"),
        "scope": ("纪录", "纪实"),
        "subs": {"纪录片": ("纪录", "纪实")},
    },
    "短剧": {
        "needles": ("短剧", "微短剧"),
        "scope": ("短剧", "微短剧"),
        "subs": {"短剧": ("短剧", "微短剧")},
    },
}
CATEGORY_NAMES = tuple(CATEGORY_TREE.keys())

# 其它一级分类 needles 并集（用于把"纪录片"从"电影"子类中剔除，避免串类）
_OTHER_NEEDLES = tuple(
    n for k, v in CATEGORY_TREE.items() if k != "__none__"
    for n in v["needles"])


def _other_needles_for(cat: str) -> tuple:
    """除 cat 外所有一级分类 needles 并集（子类归属剔除用）。"""
    out = []
    for k, v in CATEGORY_TREE.items():
        if k != cat:
            out.extend(v["needles"])
    return tuple(out)


# ---------------------------------------------------------------------------
# 分类树：拉取 + LRU 缓存（None 也缓存，6h 后自愈重试）
# ---------------------------------------------------------------------------
_tree_cache = LRUCache(maxsize=64)


def _fetch_tree(api: str) -> Optional[list]:
    """ac=list&pg=1 响应 class 段；失败/无 class 返回 None。"""
    j, _ = _cms_get(api, {"ac": "list", "pg": 1}, timeout=CAT_TIMEOUT)
    if j is None:
        return None
    cls = j.get("class")
    return cls if isinstance(cls, list) else None


def _get_tree(api: str) -> Optional[list]:
    return _tree_cache.get_or_set(("ct", api), lambda: _fetch_tree(api),
                                  ttl=CAT_TREE_TTL)


def _name_match(name: str, needles: tuple) -> bool:
    """fuzzy 包含匹配：name 包含 needles 任一即命中。"""
    return any(n and n in name for n in needles)


# ---------------------------------------------------------------------------
# type_name 归一化映射：源站分类名 → 前端统一展示名（detail 页/卡片 type 字段）
# 匹配规则：精确命中 TYPE_NORM 优先；未命中走 fuzzy 包含匹配（遍历分类树
# 全部子类 needles，最长 needle 优先，避免"动画"误吞"日韩动漫"）；再未命中保留原文。
# 电视剧类归入路径：国产剧→电视剧/国产剧、港剧/台剧→电视剧/港台剧 等。
# ---------------------------------------------------------------------------
TYPE_NORM = {
    # 电影类子类
    "喜剧片": "喜剧", "动作片": "动作", "爱情片": "爱情", "科幻片": "科幻",
    "悬疑片": "悬疑", "恐怖片": "恐怖", "剧情片": "剧情", "战争片": "战争",
    "犯罪片": "犯罪", "冒险片": "冒险", "奇幻片": "奇幻", "动画片": "动画",
    # 电视剧类子类（归入电视剧一级分类）
    "国产剧": "国产剧", "内地剧": "国产剧",
    "港剧": "港台剧", "台剧": "港台剧", "香港剧": "港台剧", "台湾剧": "港台剧",
    "日剧": "日韩剧", "韩剧": "日韩剧", "日本剧": "日韩剧", "韩国剧": "日韩剧",
    "美剧": "欧美剧", "英剧": "欧美剧", "美国剧": "欧美剧", "英国剧": "欧美剧",
    "泰剧": "泰剧", "海外剧": "海外剧",
    # 综艺类子类
    "大陆综艺": "大陆综艺", "内地综艺": "大陆综艺", "港台综艺": "港台综艺",
    "日韩综艺": "日韩综艺", "欧美综艺": "欧美综艺",
    # 动漫类子类
    "国产动漫": "国产动漫", "日韩动漫": "日韩动漫", "欧美动漫": "欧美动漫",
    "港台动漫": "港台动漫",
    # 独立一级分类
    "少儿": "少儿", "儿童": "少儿", "亲子": "少儿",
    "纪录片": "纪录片", "纪实": "纪录片", "纪实片": "纪录片",
    "短剧": "短剧", "微短剧": "短剧",
}


def norm_type_name(t: str) -> str:
    """type_name/vod_class 首段 → 规范子类名；fuzzy 包含匹配兜底。"""
    t = (t or "").strip()
    if not t:
        return ""
    if t in TYPE_NORM:
        return TYPE_NORM[t]
    best = None
    for cfg in CATEGORY_TREE.values():
        for sub, needles in cfg["subs"].items():
            for n in needles:
                if n and n in t and (best is None or len(n) > len(best[0])):
                    best = (n, sub)
    return best[1] if best else t


# ---------------------------------------------------------------------------
# 分类解析：分类树 → (一级父 type_id, 子分类 type_id 列表)
# ---------------------------------------------------------------------------
def _resolve_cat(tree: list, cat: str) -> Optional[tuple]:
    """返回 (父 type_id, 子分类 type_id 列表)；树中无该类返回 None。"""
    cfg = CATEGORY_TREE.get(cat)
    if cfg is None or not tree:
        return None
    needles = cfg["needles"]
    # 名称匹配一级 needles 的分类（父+子都算，如"电影片"+其下子类）
    matched = [(c.get("type_id"), str(c.get("type_name") or ""),
                c.get("type_pid")) for c in tree
               if _name_match(str(c.get("type_name") or ""), needles)]
    if not matched:
        return None
    # 一级父：优先 pid==0/缺失；否则取第一个命中（叶子分类直接可用）
    parent = next((m for m in matched if m[2] in (None, 0)), matched[0])
    ptid = parent[0]
    # 子分类：pid==父 的全部（剔除名称匹配其它一级 needles 的，如"纪录片"）
    other = _other_needles_for(cat)
    subs = [tid for tid, name, pid in matched
            if pid == ptid and tid != ptid
            and not _name_match(name, other)]
    # 扁平树兜底（无 pid 关联，如无极/红牛）：子类必须命中二级 needles
    # 且命中本类 scope 归属词，并排除其它一级类 needles（防跨类误配：
    # 红牛"国产剧"命中"国产"但 scope"动漫/动画"不命中 → 排除；
    # "中国动漫"命中 scope 且（扩展 needles 含"中国"）→ 收录）
    if not subs:
        scope = cfg.get("scope") or needles
        sub_needles = tuple(n for sns in cfg["subs"].values() for n in sns)
        for c in tree:
            tid = c.get("type_id")
            name = str(c.get("type_name") or "")
            pid = c.get("type_pid")
            if tid is None or tid == ptid:
                continue
            if pid == ptid or pid in (None, 0):
                if _name_match(name, sub_needles) \
                        and _name_match(name, scope) \
                        and not _name_match(name, other):
                    subs.append(tid)
    # 去重保序
    seen, out = set(), []
    for t in subs:
        if t not in seen:
            seen.add(t)
            out.append(t)
    return ptid, out


def _resolve_sub_tids(tree: list, ptid, cat: str, sub: str) -> list:
    """二级子类 → 叶子 type_id 列表（如 港台剧=香港剧+台湾剧）。"""
    sns = CATEGORY_TREE[cat]["subs"].get(sub)
    if not sns or not tree:
        return []
    scope = CATEGORY_TREE[cat].get("scope") or CATEGORY_TREE[cat]["needles"]
    other = _other_needles_for(cat)
    by_pid, others = [], []
    for c in tree:
        name = str(c.get("type_name") or "")
        tid = c.get("type_id")
        pid = c.get("type_pid")
        if tid is None:
            continue
        # 同时命中二级 needles 与 scope 归属词，且非其它一级类
        # （防跨类误配：动漫/国产 不能匹配"国产剧"——scope 动漫/动画不命中；
        #  电影/动作 能匹配"动作片"——scope 片/电影命中）
        if not _name_match(name, sns) or not _name_match(name, scope):
            continue
        if _name_match(name, other):
            continue
        (by_pid if pid == ptid else others).append(tid)
    out = by_pid + [t for t in others if t not in by_pid]
    return out


# ---------------------------------------------------------------------------
# 条目归一化（字段与 main._cms_item 对齐；type 回退 type_name，兼容精简源）
# ---------------------------------------------------------------------------
def _norm_year(v) -> Optional[int]:
    if v is None:
        return None
    m = re.search(r"(\d{4})", str(v))
    return int(m.group(1)) if m else None


def _to_score(v) -> Optional[float]:
    try:
        return round(float(v), 1) if v not in (None, "") else None
    except (TypeError, ValueError):
        return None


def _cms_list_of(j) -> list:
    """CMS list 响应 → list 段（兼容 list/data 键与裸对象）。"""
    lst = (j.get("list") if isinstance(j, dict) else None) or \
          (j.get("data") if isinstance(j, dict) else None)
    if isinstance(lst, dict):
        return [lst]
    if isinstance(lst, list):
        return [x for x in lst if isinstance(x, dict)]
    return []


def _cat_item(src_name: str, e) -> Optional[dict]:
    """CMS list 条目 → 前端统一字段（id = 来源:vod_id 主键，详情可直接查）。"""
    if not isinstance(e, dict):
        return None
    vid = e.get("vod_id")
    if vid is None:
        return None
    cls = str(e.get("vod_class") or "").strip()
    tname = str(e.get("type_name") or "").strip()
    t = norm_type_name(cls.split(",")[0].strip() if cls else tname)
    # 年份：vod_year 优先，缺失时从标题提取（"阿龙2025"/"流浪地球 (2019)" 等形态）
    year = _norm_year(e.get("vod_year"))
    if year is None:
        m = re.search(r"(19|20)\d{2}", str(e.get("vod_name") or ""))
        if m:
            year = int(m.group(0))
    return {
        "id": "%s:%s" % (src_name, vid),
        "title": str(e.get("vod_name") or "").strip(),
        "poster": str(e.get("vod_pic") or ""),
        "score": _to_score(e.get("vod_score")),
        "year": year,
        "type": t,
        "area": str(e.get("vod_area") or ""),
        "remarks": str(e.get("vod_remarks") or ""),
        "source": src_name,
        "vod_id": str(vid),
    }


def _belongs_to_cat(cat: str, tname: str) -> bool:
    """年份定向条目的归属判断：规范子类名属于 cat 才算（防串类）。

    年份定向不带 t（源不支持 t+year 组合、父分类 t 无效），返回全类型混合
    （实测含 剧情片/大陆综艺/国产剧/日韩动漫…），必须按归属过滤后收入。
    """
    if not tname:
        return False
    cfg = CATEGORY_TREE.get(cat)
    if not cfg:
        return False
    return tname in cfg["subs"] or _name_match(tname, cfg["needles"])


# 源是否支持 year 过滤参数（探测结果缓存 6h；无极等源忽略 year 返回全量）
_year_ok_cache = LRUCache(maxsize=32)


def _source_supports_year(api: str) -> bool:
    """探测：year=2025 与 year=2024 的 total 不同 → year 过滤生效。

    无极 total 三个年份恒等（117262），若强标记会把全量内容标成同一年。
    **偶发请求失败（j 为 None）不缓存、按不支持处理**——下轮聚合会重试，
    避免源站限流/抖动导致数据最丰富的源（如暴风 2025=15470）被长期跳过。
    """
    v = _year_ok_cache.get(("yr", api))
    if v is not None:
        return v
    try:
        j1, _ = _cms_get(api, {"ac": "list", "pg": 1, "year": 2025},
                         timeout=CAT_TIMEOUT)
        j2, _ = _cms_get(api, {"ac": "list", "pg": 1, "year": 2024},
                         timeout=CAT_TIMEOUT)
        if j1 is None or j2 is None:
            return False  # 请求失败：本次跳过年份定向，不缓存
        ok = j1.get("total") != j2.get("total")
        _year_ok_cache.set(("yr", api), ok, ttl=CAT_TREE_TTL)
        return ok
    except Exception:
        return False  # 异常同样不缓存，下轮重试
# ---------------------------------------------------------------------------
# 单源拉取：树解析 → 子分类 type_id 列表 → 逐个 ac=list&t=<id>&pg=1
# ---------------------------------------------------------------------------
def _cat_fetch_source(api: str, src_name: str, cat: str, sub: str,
                      deadline: float):
    """返回 (items, status)：status ∈ ok / failed / nosuch。

    nosuch=该源分类树中无此类（跳过，不算失败）；failed=请求失败（计失败）。
    源内按 deadline 提前放弃后续子分类，保证单源最坏 ~CAT_TIMEOUT+ε。
    """
    tree = _get_tree(api)
    if tree is None:
        return [], "failed"
    resolved = _resolve_cat(tree, cat)
    if resolved is None:
        return [], "nosuch"
    ptid, subs = resolved
    if sub:
        tids = _resolve_sub_tids(tree, ptid, cat, sub)
        if not tids:
            return [], "nosuch"
    else:
        tids = [ptid] + subs[:CAT_MAX_SUBS]
    items, ok = [], 0
    # 所有 (tid, pg) 一次性提交（_cms_get 内部全局信号量限流，请求尽快入队；
    # 慢 tid 不再串行阻塞同源其他 tid——冷聚合从 16.5s 降到 ~5s）
    jobs = [(tid, p, None) for tid in tids for p in range(1, CAT_PAGES + 1)]
    # 年份定向拉取（一级分类页，2026-08-03 扩资源）：源接口支持 ac=list&year=YYYY
    # （实测暴风 2025=15470/豪华 20318/360 10563，而分类树只能挖到几十部/年）。
    # 不带 t 返回全类型混合 → 条目按 _belongs_to_cat 归属过滤 + year 强标记
    # （服务器已按年份过滤，vod_year 字段却为空，强标记才能进年份筛选）。
    if not sub and CAT_YEARS and _source_supports_year(api):
        for yr in CAT_YEARS:
            for p in range(1, YEAR_PAGES + 1):
                jobs.append((None, p, yr))
    pex = ThreadPoolExecutor(max_workers=min(SEMAPHORE_LIMIT * 2, len(jobs)))
    try:
        futs = {}
        for tid, p, yr in jobs:
            params = {"ac": "list", "pg": p}
            if tid is not None:
                params["t"] = tid
            if yr is not None:
                params["year"] = yr
            futs[pex.submit(_cms_get, api, params, CAT_TIMEOUT)] = (tid, p, yr)
        for fut in as_completed(futs):
            if time.monotonic() > deadline:
                break
            tid, p, yr = futs[fut]
            try:
                j, _ = fut.result()
            except Exception:
                j = None
            if j is None:
                continue
            ok += 1
            for e in _cms_list_of(j)[:CAT_MAX_PER_TID]:
                it = _cat_item(src_name, e)
                if it is None or not it["title"]:
                    continue
                if yr is not None:
                    # 年份定向条目：归属过滤防串类 + year 强标记
                    if not _belongs_to_cat(cat, it.get("type")):
                        continue
                    it["year"] = yr
                items.append(it)
    finally:
        pex.shutdown(wait=False, cancel_futures=True)  # 超时后不等待慢请求
    if not ok:
        return [], "failed"
    return items, "ok"


# ---------------------------------------------------------------------------
# 多源并发聚合（线程池；失败跳过；去重；score 降序）
# ---------------------------------------------------------------------------
def category_loader(store, cat: str, sub: str) -> dict:
    """全量聚合（不分页）：items 已按 score/year 降序；路由侧按 pg 切片。"""
    t0 = time.monotonic()
    srcs = [s for s in store.list_sources("active")
            if not store.is_circuit_open(s["name"])]
    srcs.sort(key=lambda s: s.get("score") or 0.0, reverse=True)
    if not srcs:
        return {"items": [], "total": 0, "sources_used": 0,
                "sources_failed": [], "elapsed": 0.0}

    def work(s):
        api = s.get("api_hint") or (s.get("base_url") or "") + CMS_STD_PATH
        # 每源独立 deadline：常规子分类 (1+5)×3 页 + 年份定向 4年×3 页 ≈ 30 请求，
        # 10 并发信号量下 ~0.3-1s/请求，放宽到 2×CAT_TIMEOUT 保证年份定向拉完
        dl = time.monotonic() + CAT_TIMEOUT * 2
        return _cat_fetch_source(api, s["name"], cat, sub, dl)

    results, used, failed = [], 0, []
    with ThreadPoolExecutor(max_workers=min(SEMAPHORE_LIMIT, len(srcs))) as ex:
        futs = {ex.submit(work, s): s["name"] for s in srcs}
        try:
            # 总预算：单源超时 + 排队余量（最多 7 源 / 6 并发 → 多等 1 轮）
            total_budget = CAT_TIMEOUT * 2 + 8 + (len(srcs) // max(SEMAPHORE_LIMIT, 1)) * CAT_TIMEOUT
            for fut in as_completed(futs, timeout=total_budget):
                name = futs[fut]
                try:
                    items, status = fut.result()
                except Exception:
                    items, status = [], "failed"
                if status == "ok":
                    used += 1
                    store.record_success(name)
                    results.extend(items)
                elif status == "failed":
                    failed.append(name)
                    store.record_failure(name)
                # nosuch：分类缺失，跳过不计数
        except TimeoutError:
            # 注意：futs 的 key 是 Future 对象，必须取 .values() 才是源名！
            # 若遍历 key 会把 Future 当源名传给 store.record_failure → _require 补位
            # {"name": Future} → 下次 save() json.dump 崩 → 详情接口 500
            for name in set(futs.values()):
                if name not in results and name not in failed:
                    failed.append(name)
                    store.record_failure(name)

    # 去重：片名（剥离尾部年份）为主键——同名不同年也合并（源库同片不同源常见；
    # 年份筛选靠保留的强标记 year）。保留优先级：有 year > 有 poster > 评分高。
    # 剥离尾部年份：源标题形态不一（"宗师叶问2026" vs "宗师叶问" 是同一部片）；
    # 防 "1921" 这类纯年份片名被剥空（保留长度 >= 2）
    def _dedup_key(it):
        t = _norm_title(it["title"])
        m = re.search(r"(19|20)\d{2}$", t)
        if m and len(t) - 4 >= 2:
            t = t[:m.start()]
        return t

    def _better(a, b):
        """a 是否优于 b：有 year > 有 poster > 评分高（年份定向强标记优先保留）。"""
        for k in ("year", "poster"):
            va, vb = bool(a.get(k)), bool(b.get(k))
            if va != vb:
                return va
        return (a.get("score") or 0) > (b.get("score") or 0)

    best = {}
    for it in results:
        key = _dedup_key(it)
        old = best.get(key)
        if old is None or _better(it, old):
            best[key] = it
    # 排序：评分降序为主，但同分时按源轮转打散（避免高分源霸占整页，
    # 参考腾讯/爱奇艺分类页的多源混合观感）
    scored = sorted(best.values(),
                    key=lambda x: ((x.get("score") or 0.0), x.get("year") or 0),
                    reverse=True)
    items = _interleave_by_source(scored)
    # 小雅补数据（聚合时补，结果随 10min 聚合缓存生效；用户请求 0 开销）：
    # 源分类接口 vod_year/vod_pic 普遍为空（实测 0/20），标题带年份的才有 year。
    # 补 year 供年份筛选/year_facets，补 poster 供当前页展示。
    # 性能：lookup 命中 O(1)；miss 有 5min 防抖 + 8000 容量（原 200 会被每轮
    # 2344 次查询挤爆 → 索引构建完成后全表扫描 13k×2344 ≈ 11s/请求，2026-08-03 实锤）
    try:
        for it in items:
            if not it.get("year") or not it.get("poster"):
                m = xiaoya.lookup(it.get("title"), it.get("year"))
                if m is None:
                    m = xiaoya.lookup(it.get("title"), None)  # 年份查不到再去年份放宽
                if m is not None:
                    if not it.get("year") and m.get("year"):
                        it["year"] = m["year"]
                    if not it.get("poster"):
                        it["poster"] = m["poster"]
    except Exception:
        pass  # 兜底失败不影响主流程
    return {"items": items, "total": len(items), "sources_used": used,
            "sources_failed": failed, "elapsed": round(time.monotonic() - t0, 2)}


def _interleave_by_source(items: list, max_burst: int = 4) -> list:
    """按源轮转打散：同源连续最多 max_burst 条，保证每页多源混合。"""
    buckets = {}
    for it in items:
        buckets.setdefault(it.get("source", "?"), []).append(it)
    names = list(buckets.keys())
    out, idx, guard = [], {n: 0 for n in names}, 0
    while guard < len(items) * 2:
        guard += 1
        moved = False
        for n in names:
            if idx[n] >= len(buckets[n]):
                continue
            burst = 0
            while idx[n] < len(buckets[n]) and burst < max_burst:
                out.append(buckets[n][idx[n]])
                idx[n] += 1
                burst += 1
                moved = True
        if not moved:
            break
    return out
