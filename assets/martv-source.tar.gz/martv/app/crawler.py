#!/usr/bin/env python3
"""Mars TV 本地影视数据库爬虫（2026-08-03 扩资源核心）。

架构：源站全量爬进 SQLite（vods 表），前端查询全部走本地库（秒出、无深度限制），
播放时 detail 回源站实时取播放地址（地址有时效性，不落库）。

- 全量爬：遍历活跃源 × 叶子分类（全部，不限 5 个），逐页翻到 total，边爬边写库
- 断点续传：crawl_state 记录 (src, tid) 已爬到哪一页，中断/重启后继续
- 增量：CMS 按更新时间倒序，增量模式只拉每分类前 N 页 upsert，新片自动入库
- 限速：全局信号量并发 + 每请求超时，避免锁死源站
"""
import json
import os
import sqlite3
import sys
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from source_engine import _cms_get, CMS_STD_PATH
from category_engine import _get_tree, _resolve_cat, _resolve_sub_tids, \
    _cat_item, _belongs_to_cat, CATEGORY_TREE, CATEGORY_NAMES, CAT_TIMEOUT

DB_PATH = "/opt/martv/data/vods.db"
SOURCES_PATH = "/opt/martv/data/sources.json"
MAX_WORKERS = 6          # 全局并发（源站友好）
PAGE_SIZE = 20
INCREMENT_PAGES = 3      # 增量模式每分类拉前 3 页（最新更新）

SCHEMA = """
CREATE TABLE IF NOT EXISTS vods (
    id TEXT PRIMARY KEY,          -- source:vod_id
    title TEXT NOT NULL,
    cat TEXT,                     -- 一级分类（电影/电视剧/动漫/综艺/纪录片/短剧/少儿）
    type TEXT,                    -- 规范子类名（剧情/动作/国产剧...）
    year INTEGER,
    area TEXT,
    score REAL,
    poster TEXT,
    remarks TEXT,
    source TEXT,
    vod_id TEXT,
    updated_at REAL DEFAULT 0,    -- 源站 vod_time 时间戳（增量判断）
    crawled_at REAL DEFAULT 0,
    health REAL DEFAULT 1.0,      -- 播放健康分 0-1（巡检器回写；分类排序降权用）
    health_at REAL DEFAULT 0,     -- 最近健康巡检时间
    pinyin TEXT DEFAULT ''        -- 拼音检索：全拼小写|首字母（如 zhangshanshousuo|zsss）
);
CREATE INDEX IF NOT EXISTS idx_vods_cat_year ON vods(cat, year);
CREATE INDEX IF NOT EXISTS idx_vods_title ON vods(title);
CREATE INDEX IF NOT EXISTS idx_vods_cat_score ON vods(cat, score);

CREATE TABLE IF NOT EXISTS crawl_state (
    src TEXT, tid TEXT, next_pg INTEGER, total_pages INTEGER,
    updated_at REAL,
    last_vod_time TEXT DEFAULT '',   -- 增量检测：上次该分类最大 vod_time（YYYY-MM-DD HH:MM:SS 字符串比较）
    PRIMARY KEY(src, tid)
);

-- FTS5 全文索引（搜索毫秒级；49 万条 LIKE 全表扫 ~600ms → FTS 毫秒）
CREATE VIRTUAL TABLE IF NOT EXISTS vods_fts USING fts5(
    title, content='vods', content_rowid='rowid', tokenize='unicode61'
);
CREATE TRIGGER IF NOT EXISTS vods_ai AFTER INSERT ON vods BEGIN
    INSERT INTO vods_fts(rowid, title) VALUES (new.rowid, new.title);
END;
CREATE TRIGGER IF NOT EXISTS vods_ad AFTER DELETE ON vods BEGIN
    INSERT INTO vods_fts(vods_fts, rowid, title) VALUES ('delete', old.rowid, old.title);
END;
CREATE TRIGGER IF NOT EXISTS vods_au AFTER UPDATE ON vods BEGIN
    INSERT INTO vods_fts(vods_fts, rowid, title) VALUES ('delete', old.rowid, old.title);
    INSERT INTO vods_fts(rowid, title) VALUES (new.rowid, new.title);
END;
"""


def connect():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


def init_db():
    conn = connect()
    conn.executescript(SCHEMA)
    # 旧库补列（幂等）
    for col in ("crawl_state.last_vod_time TEXT DEFAULT ''",
                "vods.pinyin TEXT DEFAULT ''"):
        tbl, rest = col.split(".", 1)
        try:
            conn.execute("ALTER TABLE %s ADD COLUMN %s" % (tbl, rest))
            conn.commit()
        except Exception:
            pass
    conn.close()


def cat_of(cat_name: str, tname: str) -> str:
    """规范子类名 → 一级分类（归属判断，防串类）。"""
    if _belongs_to_cat(cat_name, tname):
        return cat_name
    return ""


def _pinyin(title: str) -> str:
    """标题转拼音索引：'全拼小写|首字母'（如 '爱情公寓' → 'aiqinggongyu|aqgy'）。
    非汉字保留原字符（数字/字母/空格），标点剔除。"""
    if not title:
        return ""
    try:
        from pypinyin import lazy_pinyin  # 局部导入（采集路径才需要）
        segs = lazy_pinyin(title)
        full = "".join(segs).lower()
        init = "".join((s[0] if s and s[0].isalpha() else "") for s in segs if s).lower()
        return "%s|%s" % (full, init)
    except Exception:
        return ""


def upsert_batch(conn, rows):
    """批量 upsert（INSERT OR REPLACE 按 source:vod_id 主键）。"""
    p_rows = []
    for r in rows:
        py = _pinyin(r[1])  # r[1] = title
        p_rows.append(tuple(r) + (py,))
    conn.executemany(
        """INSERT OR REPLACE INTO vods
           (id, title, cat, type, year, area, score, poster, remarks,
            source, vod_id, updated_at, crawled_at, pinyin)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        p_rows)
    conn.commit()


def crawl_source_category(api: str, src_name: str, cat: str, tid: str,
                          start_pg: int, max_pages: int, mode: str) -> dict:
    """单源单分类爬取：start_pg 起翻页，逐页 upsert。返回统计。"""
    conn = connect()
    got, total = 0, 0
    now = time.time()
    next_pg = start_pg
    fail_streak = 0
    max_vt = ""   # 本分类本次拉到的最大 vod_time（增量检测用）
    try:
        # 增量变化检测：先拉 pg=1 取最大 vod_time，与上次相同 → 源站无更新，跳过
        if mode == "incremental":
            j0, _ = _cms_get(api, {"ac": "list", "t": tid, "pg": 1},
                             timeout=CAT_TIMEOUT)
            if j0 is not None:
                vts0 = [str(e.get("vod_time") or "").strip()
                        for e in j0.get("list", []) if e.get("vod_time")]
                vts0 = [v for v in vts0 if v]
                if vts0:
                    max_vt = max(vts0)
                    row = conn.execute(
                        "SELECT last_vod_time FROM crawl_state WHERE src=? AND tid=?",
                        (src_name, tid)).fetchone()
                    last = (row[0] if row else "") or ""
                    if max_vt == last:
                        return {"source": src_name, "cat": cat, "tid": tid,
                                "got": 0, "skipped": True, "total_pages": 0}
        pg = start_pg
        while pg <= max_pages:
            j, _ = _cms_get(api, {"ac": "list", "t": tid, "pg": pg},
                            timeout=CAT_TIMEOUT)
            if j is None:
                fail_streak += 1
                if fail_streak >= 3:
                    break  # 连续 3 次失败：本轮放弃，下次从断点续
                time.sleep(1.0 * fail_streak)  # 递增退避 1s/2s，防源站限流
                continue  # 单次失败重试同页（不丢页）
            fail_streak = 0
            if not total:
                total = j.get("total") or 0
                max_pages = min(max_pages, (total + PAGE_SIZE - 1) // PAGE_SIZE)
                if max_pages < 1:
                    break
            items = []
            for e in j.get("list", [])[:PAGE_SIZE]:
                it = _cat_item(src_name, e)
                if it is None or not it["title"]:
                    continue
                vt = str(e.get("vod_time") or "").strip()
                if vt and vt > max_vt:
                    max_vt = vt
                tname = it.get("type") or ""
                c = cat_of(cat, tname)
                if not c:
                    # 该分类拉到的条目理论上应归属本类，防串类用强归属
                    c = cat
                items.append((
                    it["id"], it["title"], c, tname, it.get("year"),
                    it.get("area"), it.get("score"), it.get("poster"),
                    it.get("remarks"), src_name, it["vod_id"],
                    e.get("vod_time") or 0, now,
                ))
            if items:
                upsert_batch(conn, items)
                got += len(items)
            next_pg = pg + 1
            # 翻到底或最后一页
            if len(j.get("list", [])) < PAGE_SIZE or pg >= max_pages:
                break
            pg += 1
            if mode == "full":
                time.sleep(0.05)  # 全量限速，防锁死
        conn.execute(
            "INSERT OR REPLACE INTO crawl_state "
            "(src, tid, next_pg, total_pages, updated_at, last_vod_time)"
            " VALUES (?,?,?,?,?,?)",
            (src_name, tid, next_pg, max_pages, now, max_vt))
        conn.commit()
    finally:
        conn.close()
    return {"source": src_name, "cat": cat, "tid": tid, "got": got,
            "total_pages": max_pages}


def crawl_all(mode: str = "full"):
    """全量/增量爬所有活跃源的所有分类。"""
    init_db()
    srcs = json.load(open(SOURCES_PATH))["sources"]
    active = [s for s in srcs if s.get("active") or s.get("status") == "active"]
    jobs = []
    for s in active:
        api = s.get("api_hint") or (s.get("base_url") or "") + CMS_STD_PATH
        tree = _get_tree(api)
        if tree is None:
            continue
        for cat in CATEGORY_NAMES:
            resolved = _resolve_cat(tree, cat)
            if resolved is None:
                continue
            ptid, subs = resolved
            tids = [ptid] + list(subs)  # 全部叶子分类，不限量
            for tid in tids:
                jobs.append((api, s["name"], cat, str(tid)))
    total_jobs = len(jobs)
    done = 0
    t0 = time.monotonic()
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        futs = {}
        for api, name, cat, tid in jobs:
            # 断点续传：查 state
            conn = connect()
            row = conn.execute(
                "SELECT next_pg, total_pages FROM crawl_state WHERE src=? AND tid=?",
                (name, tid)).fetchone()
            conn.close()
            start_pg = row[0] if row else 1
            max_pages = row[1] if row else 999999
            # 越界修正：历史记录 next_pg > total_pages（翻页过界残留），
            # total 可能已变化 → 重置从第 1 页重爬（增量模式不受影响）
            if start_pg > max_pages and max_pages < 999999:
                start_pg = 1
            if mode == "incremental":
                start_pg, max_pages = 1, INCREMENT_PAGES
            futs[ex.submit(crawl_source_category, api, name, cat, tid,
                           start_pg, max_pages, mode)] = (name, cat, tid)
        for fut in as_completed(futs):
            name, cat, tid = futs[fut]
            done += 1
            try:
                r = fut.result()
                print(f"[{done}/{total_jobs}] {r['source']} {cat}/{tid}: "
                      f"+{r['got']} 条 (共 {r['total_pages']} 页)", flush=True)
            except Exception as e:
                print(f"[{done}/{total_jobs}] {name} {cat}/{tid}: ERR {e}", flush=True)
    conn = connect()
    n = conn.execute("SELECT COUNT(*) FROM vods").fetchone()[0]
    conn.close()
    print(f"\n完成 {mode} 爬取: 库内共 {n} 条, 用时 {time.monotonic()-t0:.0f}s", flush=True)


def crawl_years(mode: str = "full"):
    """年份补爬：源站 list 接口 vod_year 字段全空（实测 95%+ 缺失），
    但支持 year 过滤的源可用 ac=list&year=YYYY 定向拉取，条目 year 由
    服务器过滤保证，直接强标记入库。覆盖近 4 年热片（用户年份筛选核心）。
    """
    init_db()
    srcs = json.load(open(SOURCES_PATH))["sources"]
    active = [s for s in srcs if s.get("active") or s.get("status") == "active"]
    years = (2026, 2025, 2024, 2023)
    pages = 50
    conn = connect()
    try:
        now = time.time()
        for s in active:
            api = s.get("api_hint") or (s.get("base_url") or "") + CMS_STD_PATH
            # 源是否支持 year 过滤（探测缓存）
            from category_engine import _source_supports_year
            if not _source_supports_year(api):
                print(f"{s['name']}: 不支持 year 过滤，跳过", flush=True)
                continue
            for yr in years:
                got = 0
                for pg in range(1, pages + 1):
                    j, _ = _cms_get(api, {"ac": "list", "pg": pg, "year": yr},
                                    timeout=CAT_TIMEOUT)
                    if j is None:
                        time.sleep(1.0)
                        continue
                    rows = []
                    for e in j.get("list", [])[:PAGE_SIZE]:
                        it = _cat_item(s["name"], e)
                        if it is None or not it["title"]:
                            continue
                        tname = it.get("type") or ""
                        # 归属判断：全类型混合，归属到对应一级分类
                        c = ""
                        for cat in CATEGORY_NAMES:
                            if _belongs_to_cat(cat, tname):
                                c = cat
                                break
                        if not c:
                            continue
                        rows.append((
                            it["id"], it["title"], c, tname, yr,
                            it.get("area"), it.get("score"), it.get("poster"),
                            it.get("remarks"), s["name"], it["vod_id"],
                            e.get("vod_time") or 0, now,
                        ))
                    if rows:
                        upsert_batch(conn, rows)
                        got += len(rows)
                    if len(j.get("list", [])) < PAGE_SIZE:
                        break
                    time.sleep(0.03)
                print(f"{s['name']} {yr}: +{got} 条", flush=True)
    finally:
        conn.close()
    conn = connect()
    n = conn.execute("SELECT COUNT(*) FROM vods").fetchone()[0]
    conn.close()
    print(f"\n年份补爬完成: 库内共 {n} 条", flush=True)


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "full"
    if mode == "years":
        crawl_years()
    else:
        crawl_all(mode)
