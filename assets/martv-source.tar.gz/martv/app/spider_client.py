"""spider 协议源聚合（调本地 node 引擎网关 127.0.0.1:8095）。

设计：
- 源清单来自 /opt/martv/spider/data/spider_sources.json（阶段2 探活产物）
- 搜索：并发 top-N 源（引擎内串行，HTTP 层并发），去重合并
- 详情：spider 源线路并入现有多源聚合
- 超时/降级：单源失败不影响整体
"""
import json
import os
import time
import urllib.request
import urllib.error
from concurrent.futures import ThreadPoolExecutor, as_completed

SPIDER_DIR = "/opt/martv/spider"
SOURCES_FILE = os.path.join(SPIDER_DIR, "data", "spider_sources.json")
ENGINE = "http://127.0.0.1:8095"
SPIDER_SEARCH_BUDGET = 6.0        # spider 搜索总预算（秒）
SPIDER_MAX_SOURCES = 8            # 参与搜索的 spider 源上限
SPIDER_TIMEOUT = 12.0             # 单源请求超时
SPIDER_SEARCH_MAX = 10            # 每源最多取条数

_log = None


def _setup_logger(logger):
    global _log
    _log = logger


def _engine_post(path: str, payload: dict, timeout: float = SPIDER_TIMEOUT):
    """调引擎网关；失败返回 None。"""
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(ENGINE + path, data=body,
                                 headers={"Content-Type": "application/json"})
    t0 = time.monotonic()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read())
    except Exception:
        return None
    finally:
        pass


def load_spider_sources() -> list:
    """读 spider_sources.json，返回 active 源列表。"""
    try:
        with open(SOURCES_FILE, encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        return []
    return [s for s in d.get("sources", []) if s.get("status") == "active"]


def spider_search(word: str, limit: int = 20):
    """并发搜 spider 源，返回 [{title, year, poster, type, source, vod_id, ...}]。"""
    srcs = load_spider_sources()
    if not srcs:
        return []
    srcs = srcs[:SPIDER_MAX_SOURCES]
    t0 = time.monotonic()
    deadline = t0 + SPIDER_SEARCH_BUDGET
    results = []

    def work(s):
        r = _engine_post("/search", {"source": s["script"], "keyword": word})
        if not r or not r.get("ok"):
            return None
        lst = r.get("list") or []
        out = []
        for e in lst[:SPIDER_SEARCH_MAX]:
            title = (e.get("vod_name") or "").strip()
            if not title:
                continue
            out.append({
                "id": "spider:%s:%s" % (s["script"], e.get("vod_id", "")),
                "title": title,
                "year": (e.get("vod_year") or "").strip(),
                "type": (e.get("type_name") or "").strip(),
                "area": (e.get("vod_area") or "").strip(),
                "score": "",
                "poster": (e.get("vod_pic") or "").strip(),
                "remarks": (e.get("vod_remarks") or "").strip(),
                "source": s.get("display") or s["script"],
                "vod_id": str(e.get("vod_id", "")),
                "spider": True,
            })
        return out

    with ThreadPoolExecutor(max_workers=min(SPIDER_MAX_SOURCES, len(srcs))) as ex:
        futs = {}
        for s in srcs:
            if time.monotonic() + 0.5 > deadline:
                break
            futs[ex.submit(work, s)] = s
        try:
            for fut in as_completed(futs, timeout=max(0.2, deadline - time.monotonic())):
                items = fut.result()
                if items:
                    results.extend(items)
        except TimeoutError:
            pass

    # 去重：片名
    seen = {}
    for it in results:
        k = it["title"]
        old = seen.get(k)
        if old is None or (it.get("poster") and not old.get("poster")):
            seen[k] = it
    items = list(seen.values())
    if _log:
        _log.info("spider 搜索「%s」%d 源返回 %d 条，耗时 %.1fs",
                  word, len(futs), len(items), time.monotonic() - t0)
    return items


def spider_detail(script: str, vod_id: str):
    """取 spider 源详情（含播放线路）。"""
    r = _engine_post("/detail", {"source": script, "ids": vod_id})
    if not r or not r.get("ok"):
        return None
    det = r.get("detail") or {}
    lst = det.get("list") or []
    if not lst:
        return None
    return lst[0]
