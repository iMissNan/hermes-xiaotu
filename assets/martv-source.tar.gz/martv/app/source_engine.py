"""自动源管理引擎 —— 仓库更新 / 候选探索入池 / 榜单可搜巡检。

设计依据: docs/superpowers/specs/2026-08-02-martv-design-v3.md 第四章。
依赖核心库: utils.py（fetch/黑名单/常量）+ store.py（sources.json 原子读写/熔断器）。

CLI: python source_engine.py {update|explore|patrol}
- update  (每 30 分钟): 拉取已知仓库 index.json → 新增站点进候选 / 已删站点移出活跃池
                        / 活跃源重测健康度；单仓库失败重试 3 次，连 3 天失败标"仓库死亡"
- explore (每 6 小时):  解析仓库 spider 规则（base64 解码提真实域名，仅取域名）
                        → 候选源全量可靠性测试 → 评分入池/待观察/剔除
- patrol  (每日):       巡检 TopN 榜单片可搜性并回写评分

全部操作记 logs/source_audit.csv；脚本内置 flock 防同命令重叠（重叠时静默退出）。
评分公式（第四章原文）: 总分 = 必过项 × [0.4×速度归一 + 0.3×库量 log 归一 + 0.3×线路存活率]
"""

from __future__ import annotations

import base64
import csv
import fcntl
import json
import math
import os
import re
import sys
import threading
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from typing import Optional
from urllib.parse import urlencode, urlparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from store import SourceStore  # noqa: E402
from utils import (BASE_DIR, DATA_DIR, LOGS_DIR, SEMAPHORE_LIMIT, SOURCE_TIMEOUT,  # noqa: E402
                   fetch, get_logger, is_blacklisted)

# ---------------------------------------------------------------------------
# 常量（第四章）
# ---------------------------------------------------------------------------
REPOS = [
    {"name": "道长(dzhipy)", "url": "https://gitlab.com/duomv/dzhipy/-/raw/main/index.json"},
    {"name": "王二小(wex)", "url": "https://9280.kstore.space/wex.json"},
]
REPO_RETRIES = 3                 # 单仓库失败重试次数（1 + 3 次重试）
REPO_DEAD_DAYS = 3               # 连 N 天失败标"仓库死亡"
REPO_FETCH_TIMEOUT = 25.0        # 仓库 index.json 拉取 read 超时（秒）

HOT_WORDS = ("热辣滚烫", "流浪地球", "庆余年")   # 3 个固定热词，逐词搜索必须有结果
ADMIT_SCORE = 80.0               # ≥80 入池
WATCH_SCORE = 60.0               # 60-79 待观察
LOW_KICK_TIMES = 3               # 连 3 次 <60 剔除
SAMPLE_ENTRIES = 3               # 抽样 3 条播放地址验证视频流
LIB_LOG_BASE = 10000             # 库量 log 归一基准：1 万部 → 1.0

VIDEO_TAIL = (".m3u8", ".mp4", ".flv", ".ts", ".mkv", ".rmvb", ".avi",
              ".mov", ".webm", ".wmv", ".mpg", ".mpeg", ".m4v")

CMS_STD_PATH = "/api.php/provide/vod/"    # 苹果CMS 标准 API 路径（域名兜底探测）

PATROL_TITLES = 10               # 巡检取榜单 TopN
PATROL_SAMPLE = 3                # 每源抽样搜索片数（控预算）
EXPLORE_BUDGET = 2400            # explore 总时长预算（秒），超时未测候选留待下轮

# R3: 评分放宽 —— 热词/抽样 ≥2/3 即过（原 3/3 全中）；total=0 时库量保底
HOT_MIN_HITS = 2                 # 热词命中 ≥2/3（3 词中 2 词）
SAMPLE_MIN_OK = 2                # 抽样视频流 ≥2/3（3 条中 2 条有效）
LIB_FLOOR = 1000                 # lib_total=0 时按 1000 部保底计库量，杜绝评分天花板锁死
# R4: 瞬时失败容错 —— 连续 N 次 <60 才开始累计 low_score；候选为 0 提前重测
LOW_STREAK_REQUIRE = 3           # 连续 N 次 <60 才累计 1 次 low_score（瞬时抖动不累计）
LOW_RETEST_EARLY = 2             # 候选为 0 时提前重测 low_score<2 的 watch 源（跳过冷却）
# R5: 删除校验 —— 仓库源需连续 N 轮未收录才移出活跃池
REPO_MISS_KICK_ROUNDS = 3        # 连续 N 轮未出现在仓库列表才删除（manual 永不删）

AUDIT_PATH = os.path.join(LOGS_DIR, "source_audit.csv")
AUDIT_HEADER = ["timestamp", "source_name", "action", "score", "reason"]

# 全局并发闸（第四章 Semaphore(6)，与 api.py 共用同一上限）
SEM = threading.Semaphore(SEMAPHORE_LIMIT)

_audit_lock = threading.Lock()
_lock_fds = []
_log = get_logger("engine")

URL_RE = re.compile(r"https?://[^\s\"'\\]+", re.I)
_HOST_RE = re.compile(
    r"^(?=.{1,253}\.?$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+"
    r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$", re.I)


def _cut_sep(url: str) -> str:
    """截断 TVBox/hipy 配置残留分隔符（$ 链路标记、;md5 校验串）。"""
    return re.split(r"\$|;md5", url, maxsplit=1)[0]


def _valid_host(host: str) -> bool:
    """域名或 IPv4/IPv6 字面量才视为真实主机（spider 类名/残留串一律拒绝）。"""
    if _HOST_RE.match(host):
        return True
    try:
        import ipaddress
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


# R2: 非 CMS 站点类型关键词 —— 网盘/磁力/搜索聚合站协议非苹果CMS，不入 CMS 池
NON_CMS_KEYWORDS = (
    "网盘", "云盘", "夸克", "阿里盘", "百度盘", "迅雷盘", "天翼盘",
    "蓝奏", "uc盘", "115盘", "pan.baidu", "quark", "aliyunpan",
    "磁力", "种子", "torrent", "magnet:", "bt:",
    "搜索", "聚合",
)


def classify_site_type(name: str, api: str = "", ext: str = "") -> str:
    """站点类型标签: cms / netdisk / magnet / search。

    按 站点名+api/ext 文本关键词判定。网盘、磁力、搜索聚合类站点进不了
    CMS 池 —— 其协议不是苹果CMS，探测必白费（现状 sources.json 中 17 个
    网盘/磁力 watch 源即此类，每轮 explore 白白消耗探测预算）。
    """
    text = " ".join(str(x) for x in (name, api, ext) if x).lower()
    for kw in NON_CMS_KEYWORDS:
        if kw in text:
            if kw in ("磁力", "种子", "torrent", "magnet:", "bt:"):
                return "magnet"
            if kw in ("搜索", "聚合"):
                return "search"
            return "netdisk"
    return "cms"


def _is_cms_source(s: dict) -> bool:
    """候选源是否 CMS 类型：显式 type 标签优先；存量源无标签时按名称/域名关键词回退。"""
    t = s.get("type")
    if t:
        return t == "cms"
    return classify_site_type(s.get("name") or "",
                              s.get("base_url") or "") == "cms"


# ---------------------------------------------------------------------------
# 审计 CSV（全部操作留痕）
# ---------------------------------------------------------------------------
def audit(source_name: str, action: str, score="", reason="") -> None:
    """追加一行到 source_audit.csv；文件不存在时先写表头。线程安全。"""
    os.makedirs(LOGS_DIR, exist_ok=True)
    with _audit_lock:
        fresh = (not os.path.exists(AUDIT_PATH)
                 or os.path.getsize(AUDIT_PATH) == 0)
        with open(AUDIT_PATH, "a+", encoding="utf-8", newline="") as f:
            if not fresh:
                # 既有文件若末行无换行先补一个，避免表头与首行粘连
                f.seek(0, os.SEEK_END)
                if f.tell() > 0:
                    f.seek(f.tell() - 1)
                    if f.read(1) != "\n":
                        f.write("\n")
            w = csv.writer(f)
            if fresh:
                w.writerow(AUDIT_HEADER)
            w.writerow([time.strftime("%Y-%m-%d %H:%M:%S"),
                        source_name, action, score, reason])


# ---------------------------------------------------------------------------
# flock 防重叠（同命令互斥；被占用时静默退出，由 cron 错峰）
# ---------------------------------------------------------------------------
def _flock(cmd: str) -> int:
    os.makedirs(LOGS_DIR, exist_ok=True)
    lock_path = os.path.join(LOGS_DIR, "source_engine.%s.lock" % cmd)
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o644)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        print("[%s] flock 被占用：另一 %s 实例运行中，本次跳过" % (cmd, cmd))
        os.close(fd)
        sys.exit(0)
    _lock_fds.append(fd)  # 持有引用防 GC 提前关闭
    return fd


# ---------------------------------------------------------------------------
# 域名归一化（去重主键：scheme://host，仅取域名）
# ---------------------------------------------------------------------------
def normalize_domain(url: str) -> Optional[str]:
    """URL → scheme://host（小写、剥默认端口、剥路径/查询）。非法返回 None。"""
    if not url:
        return None
    if "://" not in url:
        url = "http://" + url
    url = _cut_sep(url)                     # 防御：残留分隔符截断
    try:
        p = urlparse(url)
    except ValueError:
        return None
    host = (p.hostname or "").lower().strip(".")
    if not host or not _valid_host(host):
        return None
    scheme = (p.scheme or "http").lower()
    try:
        port = p.port
    except ValueError:
        return "%s://%s" % (scheme, host)
    if port in (80, 443, None):
        return "%s://%s" % (scheme, host)
    return "%s://%s:%d" % (scheme, host, port)


def _host_of(domain: str) -> str:
    try:
        return urlparse(domain).hostname or domain
    except ValueError:
        return domain


# ---------------------------------------------------------------------------
# 仓库解析：提取 spider 规则中的真实域名（base64 解码兜底，仅取域名）
# ---------------------------------------------------------------------------
def _first_abs_url(*fields) -> Optional[str]:
    for f in fields:
        if isinstance(f, str):
            m = URL_RE.search(f)
            if m:
                u = _cut_sep(m.group(0))
                return u.rstrip(".,;)]}'\"")
    return None


def _clean_url(u: str) -> str:
    """剥离 TVBox/hipy 残留分隔符与尾随标点。"""
    return _cut_sep(u).rstrip(".,;)]}'\" ")


def _decode_base64_field(field: str) -> Optional[str]:
    """base64 解码（自动补 padding）；非法字符/解码失败返回 None。"""
    try:
        return base64.b64decode(field + "=" * (-len(field) % 4)
                                ).decode("utf-8", "ignore")
    except Exception:
        return None


def _api_str_of(api) -> str:
    """api 字段归一为字符串：str 直取；dict 取 url/api/spider 键。"""
    if isinstance(api, str):
        return api
    if isinstance(api, dict):
        for k in ("url", "api", "spider"):
            v = api.get(k)
            if isinstance(v, str):
                return v
    return ""


def _extract_api_from_text(text: str) -> Optional[str]:
    """从 base64 解码文本提取 CMS api 地址。

    R1: 先按 JSON 结构解析，取对象里的 api 键（TVBox spider 规则标准形态
    {"key":..,"api":"https://..."}）；结构不匹配时回退正则扫首个绝对 URL。
    原实现把解码文本整体当字符串只查 "http" 子串，api 键的结构信息全丢。
    """
    if not text:
        return None
    try:
        obj = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        obj = None
    if isinstance(obj, dict):
        for key in ("api", "url", "spider_url"):
            v = obj.get(key)
            if isinstance(v, str) and v.startswith("http"):
                return _clean_url(v)
    return _first_abs_url(text)


def _fetch_ext_payload(url: str):
    """拉取 ext=http 指向的资源 → (text, content_type, ok)。8s 读超时。"""
    r = fetch(url, timeout=8.0)
    if r is None:
        return None, "", False
    try:
        ctype = (r.headers.get("Content-Type") or "").lower()
        return r.text, ctype, r.status_code == 200
    finally:
        r.close()


def _resolve_site_hint(api: str, ext: str):
    """api/ext → (hint, discard_reason)。URL 直取；base64 按 JSON 结构取 api 键。"""
    for f in (api, ext):
        if f.startswith("http"):
            return _clean_url(f), None
        if f:
            dec = _decode_base64_field(f)
            if dec:
                hint = _extract_api_from_text(dec)
                if hint:
                    return hint, None
    return None, "api/ext 无有效 CMS 地址"


def parse_repo_index(payload: str) -> list:
    """index.json → [{name, domain, api_hint, type}]。

    规则提取（R1）：
      1. api 字段为绝对 URL → 直接取；
      2. ext 字段为绝对 URL → 先拉取判 Content-Type 分流：JS 托管
         (text/javascript) 跳过并审计；JSON → 按结构取 api 键作为候选；
      3. ext 字段为 base64 编码 JSON（TVBox spider 规则）→ 解码后按 JSON
         结构取 api 键。
    无法提取/非法域名的站点 audit 留痕（站点名+原因），不再静默丢弃。
    身份主键 = normalize_domain(URL)（仅 scheme://host）；api_hint 保留全路径供探测。
    type 标签（R2）供入池过滤：网盘/磁力/搜索站不进 CMS 池。
    """
    try:
        data = json.loads(payload)
    except (json.JSONDecodeError, TypeError):
        return []
    sites = data.get("sites") if isinstance(data, dict) else data
    if not isinstance(sites, list):
        return []
    items = []          # (name, api, ext_or_hint, type)
    ext_pending = {}    # ext_url → (name, api, type)
    for s in sites:
        if not isinstance(s, dict):
            continue
        name = str(s.get("name") or s.get("key") or "").strip()
        api = _api_str_of(s.get("api"))
        ext = s.get("ext")
        rtype = classify_site_type(name, api,
                                   ext if isinstance(ext, str) else "")
        if api.startswith("http"):
            items.append((name, api, "", rtype))
        elif isinstance(ext, str) and ext.startswith("http"):
            ext_pending.setdefault(ext, (name, api, rtype))
        else:
            items.append((name, api, ext if isinstance(ext, str) else "", rtype))

    # R1: ext=http 并发拉取判 Content-Type 分流（JS 托管跳过 / JSON 取 api 键）
    if ext_pending:
        def _load(url: str):
            return url, _fetch_ext_payload(url)
        with ThreadPoolExecutor(max_workers=8) as pool:
            fetched = dict(pool.map(_load, ext_pending))
        for url, (name, api, rtype) in ext_pending.items():
            text, ctype, ok = fetched.get(url, (None, "", False))
            if not ok or not text:
                audit(name or "(未命名)", "discard", "",
                      "ext 拉取失败(超时/非200): %s" % url)
                continue
            if "javascript" in ctype or "ecmascript" in ctype:
                audit(name or "(未命名)", "discard", "",
                      "ext 为 JS 托管(%s)，非 CMS 接口" % ctype)
                continue
            hint = _extract_api_from_text(text)
            if hint:
                items.append((name, api, hint, rtype))
            else:
                audit(name or "(未命名)", "discard", "",
                      "ext 内容非 JSON 结构且无 api 键: %s" % url)

    out, seen = [], set()
    for name, api, ext, rtype in items:
        hint, reason = _resolve_site_hint(api, ext)
        if reason:
            audit(name or "(未命名)", "discard", "", reason)
            continue
        domain = normalize_domain(hint)
        if not domain:
            audit(name or "(未命名)", "discard", "",
                  "URL 无法归一化: %s" % hint)
            continue
        key = (domain, name)
        if key in seen:
            continue
        seen.add(key)
        out.append({"name": name or domain, "domain": domain,
                    "api_hint": hint, "type": rtype})
    return out


# ---------------------------------------------------------------------------
# 苹果CMS 探测（Semaphore(6) 内短 GET；必过项判定在此完成）
# ---------------------------------------------------------------------------
def _cms_get(api_url: str, params: dict, timeout: float = SOURCE_TIMEOUT):
    """GET api_url?params → (json|None, elapsed)。200 且 <timeout 且可解析才返回 json。"""
    sep = "&" if "?" in api_url else "?"
    full = api_url + sep + urlencode(params)
    t0 = time.monotonic()
    with SEM:
        r = fetch(full, timeout=timeout)
    elapsed = time.monotonic() - t0
    if r is None:
        return None, elapsed
    try:
        if r.status_code != 200 or elapsed >= timeout:
            return None, elapsed
        j = r.json()
    except Exception:
        return None, elapsed
    finally:
        r.close()
    return (j if isinstance(j, dict) else None), elapsed


_CMS_KEYS = ("code", "list")   # R3: 标准苹果CMS 必有 code+list；page/total/class 部分实现缺失不作必过键


def _cms_list(api_url: str):
    """列表探测：返回 (可用 api_url, elapsed, json) 或 (None, ...)。
    依次尝试 api_hint → 域名+/api.php/provide/vod/，首个协议键齐全者胜出。"""
    for u in api_url:
        j, elapsed = _cms_get(u, {"ac": "list", "pg": 1})
        if j is not None and all(k in j for k in _CMS_KEYS):
            return u, elapsed, j
    return None, 0.0, None


def _cms_search(api_url: str, word: str):
    j, _ = _cms_get(api_url, {"ac": "detail", "wd": word})
    return j


def is_video_url(u: str) -> bool:
    """播放地址为视频流格式（m3u8/mp4/flv/ts/mkv...，剥查询/锚点后看后缀）。"""
    if not u:
        return False
    uu = u.split("?")[0].split("#")[0].lower().rstrip("/")
    return uu.endswith(VIDEO_TAIL)


def probe_candidate(cand: dict) -> dict:
    """候选源全量可靠性测试（必过项 + 评分输入采集）。"""
    hint = cand.get("api_hint") or ""
    std = (cand.get("domain") or "") + CMS_STD_PATH
    urls = []
    for u in (hint, std):
        if u and u not in urls:
            urls.append(u)
    api_used, elapsed, j = _cms_list(urls)
    if api_used is None:
        return {"ok": False, "reason": "CMS 列表不可用(非200/超时/协议键缺失)",
                "blacklisted": is_blacklisted(cand.get("name"))}
    # 热词搜索
    hits = 0
    for w in HOT_WORDS:
        jj = _cms_search(api_used, w)
        if jj is not None and jj.get("list"):
            hits += 1
    # 抽样 3 条播放地址（vod_play_url：线路$$$分隔 / 集#分隔 / 名称$地址）
    entries = (j.get("list") or [])[:SAMPLE_ENTRIES]
    total_lines = valid_lines = valid_entries = 0
    blacklisted = is_blacklisted(cand.get("name")) or is_blacklisted(api_used)

    def _count_play(play: str) -> bool:
        """统计 play 串中的视频流地址；条目含至少 1 条有效地址返回 True。"""
        nonlocal total_lines, valid_lines, valid_entries
        ent_ok = False
        for ln in play.split("$$$"):
            for ep in ln.split("#"):
                url = ep.split("$")[-1].strip() if "$" in ep else ep.strip()
                if not url:
                    continue
                total_lines += 1
                if is_video_url(url):
                    valid_lines += 1
                    ent_ok = True
        if ent_ok:
            valid_entries += 1
        return ent_ok

    for e in entries:
        play = str(e.get("vod_play_url") or "")
        if is_blacklisted(str(e.get("vod_name") or "")) or is_blacklisted(play):
            blacklisted = True
        if _count_play(play):
            continue  # list 条目已含可播地址，无需回退
        # 回退：部分 CMS 为省流量 ac=list 不带 vod_play_url → ac=detail&ids= 取播放地址再抽样
        vid = e.get("vod_id")
        if not vid:
            continue
        dj, _ = _cms_get(api_used, {"ac": "detail", "ids": vid})
        if dj is not None and dj.get("list"):
            dplay = str(dj["list"][0].get("vod_play_url") or "")
            if is_blacklisted(dplay):
                blacklisted = True
            _count_play(dplay)
    return {
        "ok": True, "elapsed": elapsed, "keys_ok": True,
        "hot_hits": hits, "entries": len(entries),
        "valid_entries": valid_entries, "valid_lines": valid_lines,
        "total_lines": total_lines, "lib_total": int(j.get("total") or 0),
        "blacklisted": blacklisted, "api_used": api_used,
    }


# ---------------------------------------------------------------------------
# 评分（第四章公式，纯函数可测）
# ---------------------------------------------------------------------------
def score_candidate(p: dict):
    """总分 = 必过项 × [0.4×速度归一 + 0.3×库量 log 归一 + 0.3×线路存活率]。

    必过项: HTTP 200 且 <5s(ok)、协议键齐全(keys_ok)、热词 ≥2/3(hot_hits>=2)、
            抽样 ≥3 条且 ≥2/3 为视频流(valid_entries>=2)、黑名单未命中。
    返回 (score, must_pass, fail_reason)。
    """
    must = bool(p.get("ok") and p.get("keys_ok")
                and p.get("hot_hits", 0) >= HOT_MIN_HITS
                and p.get("entries", 0) >= SAMPLE_ENTRIES
                and p.get("valid_entries", 0) >= SAMPLE_MIN_OK
                and not p.get("blacklisted"))
    if not must:
        if p.get("blacklisted"):
            reason = "黑名单一票否决"
        elif not p.get("ok"):
            reason = p.get("reason") or "必过项失败"
        elif p.get("hot_hits", 0) < HOT_MIN_HITS:
            reason = "热词搜索不全(%d/%d，需≥%d)" % (p.get("hot_hits", 0),
                                                 len(HOT_WORDS), HOT_MIN_HITS)
        elif p.get("entries", 0) < SAMPLE_ENTRIES:
            reason = "抽样不足(%d条<3)" % p.get("entries", 0)
        elif p.get("valid_entries", 0) < SAMPLE_MIN_OK:
            reason = "播放地址非视频流(%d/%d，需≥%d)" % (p.get("valid_entries", 0),
                                                   p.get("entries", 0), SAMPLE_MIN_OK)
        else:
            reason = "必过项失败"
        return 0.0, False, reason
    speed = max(0.0, min(1.0, (SOURCE_TIMEOUT - p["elapsed"])
                         / (SOURCE_TIMEOUT - 0.5)))            # 0.5s→1.0，5s→0
    lib = min(1.0, math.log10(max(p.get("lib_total", 0), LIB_FLOOR) + 1)
              / math.log10(LIB_LOG_BASE))        # R3: total=0 时按 1000 部保底，杜绝评分天花板锁死
    surv = (p.get("valid_lines") or 0) / max(p.get("total_lines") or 1, 1)
    score = 100.0 * (0.4 * speed + 0.3 * lib + 0.3 * surv)
    return round(score, 1), True, ""


def classify(score: float, must: bool, blacklisted: bool) -> str:
    """阈值判定: reject(黑名单) / active(≥80) / watch(60-79) / low(<60 或必过失败)。"""
    if blacklisted:
        return "reject"
    if not must or score < WATCH_SCORE:
        return "low"
    if score >= ADMIT_SCORE:
        return "active"
    return "watch"


# ---------------------------------------------------------------------------
# update —— 每 30 分钟
# ---------------------------------------------------------------------------
def _find_repo(store, url: str):
    for r in store.list_repos():
        if r.get("url") == url:
            return r
    return None


def _pull_repo(url: str) -> Optional[str]:
    """拉取 index.json：200 返回文本；失败/超时返回 None。"""
    r = fetch(url, timeout=REPO_FETCH_TIMEOUT)
    if r is None:
        return None
    try:
        if r.status_code != 200:
            return None
        return r.text
    finally:
        r.close()


def _mark_repo_ok(store, url: str, now: float) -> None:
    store.upsert_repo(url, last_ok=now)
    r = _find_repo(store, url)
    if r is not None:
        r["dead_since"] = None
        r["fail_days"] = 0
        r["fail_date"] = None
        store.save()


def _bump_repo_fail(store, url: str) -> int:
    """连败按『天』计数：同一天多次失败只计 1。返回累计失败天数。"""
    r = _find_repo(store, url)
    if r is None:
        store.upsert_repo(url)
        r = _find_repo(store, url)
    today = time.strftime("%Y-%m-%d")
    if r is not None and r.get("fail_date") != today:
        r["fail_days"] = r.get("fail_days", 0) + 1
        r["fail_date"] = today
        store.save()
    return r["fail_days"] if r is not None else 0


def _set_repo_dead(store, url: str, now: float) -> None:
    r = _find_repo(store, url)
    if r is not None:
        r["dead_since"] = now
        store.save()


def run_update() -> dict:
    """30 分钟更新：拉仓库 → 新增候选 / 移出已删 / 活跃源重测健康度。"""
    store = SourceStore()
    now = time.time()
    repo_domains: dict = {}      # repo_name -> {domain, ...}（仅成功拉取的仓库）
    repo_ok_names = set()        # 本轮成功的仓库名
    new_candidates = []
    repo_results = {}

    for repo in REPOS:
        payload, attempts = None, 0
        for attempt in range(REPO_RETRIES + 1):        # 1 次 + 3 次重试
            attempts = attempt + 1
            payload = _pull_repo(repo["url"])
            if payload is not None:
                break
            if attempt < REPO_RETRIES:
                time.sleep(attempt + 1)                # 1s/2s/3s 退避
        if payload is not None:
            sites = parse_repo_index(payload)
            _mark_repo_ok(store, repo["url"], now)
            audit(repo["name"], "repo_ok", "", "%d 站" % len(sites))
            repo_results[repo["name"]] = {"ok": True, "sites": len(sites)}
            repo_ok_names.add(repo["name"])
            doms = repo_domains.setdefault(repo["name"], set())
            for s in sites:
                doms.add(s["domain"])
                if not any(normalize_domain(x.get("base_url") or "") == s["domain"]
                           for x in store.all_sources()):
                    if s.get("type") != "cms":
                        # R2: 网盘/磁力/搜索站协议非苹果CMS，不入 CMS 池
                        audit(s["name"], "skip_non_cms", "",
                              "站点类型 %s，不入 CMS 池" % s.get("type"))
                        continue
                    name = s["name"]
                    ex = store.get_source(name)
                    if ex is not None and normalize_domain(ex.get("base_url") or "") != s["domain"]:
                        name = "%s@%s" % (name, _host_of(s["domain"]))
                    rec = {"name": name, "base_url": s["domain"], "score": 0.0,
                           "status": "watch", "tested": False, "low_score": 0,
                           "api_hint": s.get("api_hint") or "", "last_seen": now,
                           "repo": repo["name"]}
                    store.upsert_source(rec)
                    new_candidates.append(name)
                    audit(name, "candidate_added", "", "仓库新增")
        else:
            fail_days = _bump_repo_fail(store, repo["url"])
            audit(repo["name"], "repo_fail", "", "重试%d次仍失败，连败%d天" % (REPO_RETRIES, fail_days))
            repo_results[repo["name"]] = {"ok": False, "fail_days": fail_days}
            if fail_days >= REPO_DEAD_DAYS:
                r = _find_repo(store, repo["url"])
                if r is None or not r.get("dead_since"):
                    _set_repo_dead(store, repo["url"], now)
                    audit(repo["name"], "repo_dead", "", "连%d天失败，标记仓库死亡" % fail_days)
                    repo_results[repo["name"]]["dead"] = True

    # 已删站点移出活跃池（R5: 仅仓库来源 origin=repo，且需连续 N 轮未收录；
    # manual 源永不自动删；**仓库失败不连坐**：只有"源所属仓库本轮成功拉取
    # 但该源不在其列表"才累计 miss（历史教训 2026-08-04：道长仓库拉取失败
    # 3 轮 → 暴风资源被误判 removed_repo_deleted，实际源站 200 正常 97 分））
    changed = False
    for s in store.list_sources("active"):
        if s.get("origin") != "repo":
            continue
        rname = s.get("repo") or ""
        # 源有仓库归属且该仓库本轮成功 → 按收录情况判定
        if rname in repo_ok_names:
            dom = normalize_domain(s.get("base_url") or "")
            if dom and dom in repo_domains.get(rname, set()):
                if s.get("repo_miss"):
                    s["repo_miss"] = 0
                    changed = True
            else:
                s["repo_miss"] = s.get("repo_miss", 0) + 1
                changed = True
                if s["repo_miss"] >= REPO_MISS_KICK_ROUNDS:
                    store.set_status(s["name"], "removed")
                    audit(s["name"], "removed_repo_deleted", "",
                          "仓库连续%d轮未收录该站" % s["repo_miss"])
                else:
                    audit(s["name"], "repo_missing", "",
                          "仓库本轮未收录(第%d/%d轮)" % (s["repo_miss"],
                                                    REPO_MISS_KICK_ROUNDS))
        else:
            # 无归属或所属仓库本轮失败：不计 miss（防仓库宕机连坐误删）；
            # 但清掉历史 miss，源恢复收录后从 0 起算
            if s.get("repo_miss"):
                s["repo_miss"] = 0
                changed = True
    if changed:
        store.save()

    # 活跃源重测健康度（轻量：列表可达性；熔断中的源跳过）
    for s in store.list_sources("active"):
        if store.is_circuit_open(s["name"]):
            continue
        api = s.get("api_hint") or (s.get("base_url") or "") + CMS_STD_PATH
        j, _ = _cms_get(api, {"ac": "list", "pg": 1})
        if j is not None:
            prev_bad = (s.get("circuit") or {}).get("fail_count", 0) > 0
            store.record_success(s["name"])
            if prev_bad:                                # 仅状态翻转时留痕，避免刷屏
                audit(s["name"], "health_ok", "", "重测恢复")
        else:
            store.record_failure(s["name"])
            audit(s["name"], "health_fail", "", "重测失败(非200/超时)")

    alert, msg = store.pool_alert()
    if alert:
        audit("__pool__", "pool_alert", "", msg)

    st = store.stats()
    for name, res in repo_results.items():
        if res.get("ok"):
            print("[update] 仓库 %s = OK（%d 站）" % (name, res["sites"]))
        else:
            print("[update] 仓库 %s = FAIL（连败 %d 天%s）"
                  % (name, res.get("fail_days", 0),
                     "，已标记死亡" if res.get("dead") else ""))
    print("[update] 新增候选 %d 个；池内 total=%d active=%d watch=%d removed=%d 熔断=%d"
          % (len(new_candidates), st["total"], st["active"], st["watch"],
             st["removed"], st["circuit_open"]))
    _log.info("update 完成: %s", json.dumps({"repos": repo_results, "pool": st},
                                            ensure_ascii=False))
    return {"repos": repo_results, "pool": st, "new_candidates": new_candidates}


# ---------------------------------------------------------------------------
# explore —— 每 6 小时
# ---------------------------------------------------------------------------
def run_explore() -> dict:
    """候选源全量可靠性测试 → 评分入池/待观察/剔除；域名归一化去重只留最高分。"""
    store = SourceStore()
    now = time.time()
    active_domains = {normalize_domain(s.get("base_url") or "")
                      for s in store.all_sources()
                      if s.get("status") == "active"}

    # 候选集合：未测过 或 watch 且冷却到期；黑名单/已剔除/域名已有活跃源 跳过
    candidates = []
    for s in store.all_sources():
        if s.get("status") == "removed" or s.get("blacklisted"):
            continue
        if not _is_cms_source(s):
            continue                    # R2: 网盘/磁力/搜索站不入 CMS 池
        dom = normalize_domain(s.get("base_url") or "")
        if dom in active_domains:
            if s.get("status") != "active":
                store.set_status(s["name"], "removed")
                audit(s["name"], "dedup_removed", "", "域名重复，已有活跃源")
            continue
        if s.get("status") == "active":
            continue
        if s.get("tested") and not store.should_retest(s["name"]):
            continue
        candidates.append(s)

    # R4: 候选为 0 时提前重测 low_score<2 的 watch 源（跳过冷却），避免 explore 空转
    if not candidates:
        for s in store.all_sources():
            if s.get("status") != "watch" or s.get("blacklisted"):
                continue
            if not _is_cms_source(s):
                continue
            if s.get("low_score", 0) >= LOW_RETEST_EARLY:
                continue
            dom = normalize_domain(s.get("base_url") or "")
            if dom in active_domains:
                continue
            if store.is_circuit_open(s["name"]):
                continue
            candidates.append(s)
        if candidates:
            audit("__explore__", "retest_early", "",
                  "候选为0，提前重测 low_score<%d 的 watch 源 %d 个"
                  % (LOW_RETEST_EARLY, len(candidates)))

    deadline = time.monotonic() + EXPLORE_BUDGET
    results = []  # (record, score, must, reason)

    def _work(s):
        if time.monotonic() > deadline:
            return None
        probe = probe_candidate(s)
        score, must, reason = score_candidate(probe)
        return (s, score, must, reason, probe)

    with ThreadPoolExecutor(max_workers=SEMAPHORE_LIMIT) as pool:
        for r in pool.map(_work, candidates):
            if r is not None:
                results.append(r)

    n_admit = n_watch = n_low = n_reject = 0
    for s, score, must, reason, probe in results:
        s["tested"] = True
        s["last_seen"] = time.time()
        s["last_score"] = score
        if probe.get("api_used"):
            s["api_hint"] = probe["api_used"]           # 记住可用线路，供后续 update/patrol
        cls = classify(score, must, probe.get("blacklisted"))
        if cls == "reject":
            s["status"] = "removed"
            s["blacklisted"] = True
            n_reject += 1
            audit(s["name"], "reject", score, "黑名单一票否决")
        elif cls == "active":
            s["status"] = "active"
            s["score"] = score
            s["low_score"] = 0
            s["consec_fail"] = 0
            s["origin"] = "repo"        # R5: 探索入池标记仓库来源，删除校验仅对 repo 源生效
            n_admit += 1
            audit(s["name"], "admit", score, "评分≥80 入池")
        elif cls == "watch":
            s["status"] = "watch"
            s["score"] = score
            s["low_score"] = 0
            s["consec_fail"] = 0
            n_watch += 1
            audit(s["name"], "watch", score, "60-79 待观察")
        else:
            s["score"] = score
            # R4: 连续 N 次 <60 才开始累计 low_score，此后每次连续失败累计 1；
            # 中途出现一次 ≥60 即清零连败计数（瞬时抖动不累计、不剔除）
            s["consec_fail"] = s.get("consec_fail", 0) + 1
            streak = s["consec_fail"]
            if streak >= LOW_STREAK_REQUIRE:
                s["low_score"] = s.get("low_score", 0) + 1
            if s["low_score"] >= LOW_KICK_TIMES:
                s["status"] = "removed"
                audit(s["name"], "remove", score,
                      "连续%d次<60剔除(%s)" % (LOW_KICK_TIMES, reason))
            else:
                s["status"] = "watch"
                audit(s["name"], "low_score", score,
                      "连续%d次<60，累计%d/%d(%s)"
                      % (streak, s["low_score"], LOW_KICK_TIMES, reason))
            n_low += 1

    # 域名归一化去重：同域名只留评分最高者（活跃/待观察全量复查）
    groups = defaultdict(list)
    for s in store.all_sources():
        dom = normalize_domain(s.get("base_url") or "")
        if dom and s.get("status") in ("active", "watch") and not s.get("blacklisted"):
            groups[dom].append(s)
    for dom, items in groups.items():
        if len(items) < 2:
            continue
        items.sort(key=lambda x: x.get("last_score", x.get("score", 0.0)),
                   reverse=True)
        for loser in items[1:]:
            sc = loser.get("last_score", loser.get("score", 0.0))
            if loser["status"] == "active":
                loser["status"] = "watch"
                loser["score"] = sc
                audit(loser["name"], "demoted", sc, "域名重复降级")
            else:
                loser["status"] = "removed"
                audit(loser["name"], "dedup_removed", sc, "域名重复，保留评分最高者")

    store.save()
    st = store.stats()
    print("[explore] 候选 %d：入池 %d / 待观察 %d / 低分 %d / 黑名单拒 %d；池内 active=%d watch=%d"
          % (len(candidates), n_admit, n_watch, n_low, n_reject,
             st["active"], st["watch"]))
    _log.info("explore 完成: %s", json.dumps(
        {"tested": len(results), "admit": n_admit, "watch": n_watch,
         "low": n_low, "reject": n_reject, "pool": st}, ensure_ascii=False))
    return {"tested": len(results), "admit": n_admit, "watch": n_watch,
            "low": n_low, "reject": n_reject, "pool": st}


# ---------------------------------------------------------------------------
# patrol —— 每日
# ---------------------------------------------------------------------------
def run_patrol() -> dict:
    """巡检 TopN 榜单片可搜性并回写评分（0.9×旧分 + 0.1×可搜率）。"""
    store = SourceStore()
    hot_path = os.path.join(DATA_DIR, "hot.json")   # 修复：热榜在 data/ 而非 static/（曾致每日空转跳过）
    if not os.path.exists(hot_path):
        audit("__hot__", "patrol_skip", "", "hot.json 不存在（热榜引擎未启动）")
        print("[patrol] hot.json 不存在，跳过")
        return {"skipped": True}
    try:
        with open(hot_path, encoding="utf-8") as f:
            hot = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        audit("__hot__", "patrol_skip", "", "hot.json 解析失败: %s" % e)
        print("[patrol] hot.json 解析失败，跳过")
        return {"skipped": True}
    titles = []
    # hot.json 结构：{updated_at, sections:{global|douban|maoyan:{items:[{title,...}]}}, id_map}
    secs = hot.get("sections") if isinstance(hot.get("sections"), dict) else {}
    for sec in secs.values():
        for it in (sec.get("items") or []):
            if isinstance(it, dict) and it.get("title"):
                titles.append(it["title"])
            if len(titles) >= PATROL_TITLES:
                break
        if len(titles) >= PATROL_TITLES:
            break
    if not titles:
        audit("__hot__", "patrol_skip", "", "hot.json 无榜单标题")
        return {"skipped": True}
    sampled = titles[:PATROL_SAMPLE]

    actives = [s for s in store.list_sources("active")
               if not store.is_circuit_open(s["name"])]
    for s in actives:
        api = s.get("api_hint") or (s.get("base_url") or "") + CMS_STD_PATH
        hits = 0
        for t in sampled:
            j = _cms_search(api, t)
            if j is not None and j.get("list"):
                hits += 1
        ratio = hits / len(sampled)
        patrol_score = round(ratio * 100.0, 1)
        s["score"] = round(0.9 * (s.get("score") or 0.0) + 0.1 * patrol_score, 1)
        s["last_patrol"] = time.time()
        audit(s["name"], "patrol", patrol_score, "%d/%d 榜单片可搜" % (hits, len(sampled)))
        if hits == 0:
            store.record_failure(s["name"])
        else:
            store.record_success(s["name"])
    store.save()
    print("[patrol] 巡检 %d 个活跃源，每源抽样 %d 片" % (len(actives), len(sampled)))
    _log.info("patrol 完成: %d 源，样本 %d 片", len(actives), len(sampled))
    return {"checked": len(actives), "sampled": len(sampled)}


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main() -> None:
    cmd = sys.argv[1] if len(sys.argv) > 1 else "update"
    if cmd not in ("update", "explore", "patrol"):
        print("用法: python source_engine.py {update|explore|patrol}")
        sys.exit(2)
    _flock(cmd)
    try:
        if cmd == "update":
            run_update()
        elif cmd == "explore":
            run_explore()
        else:
            run_patrol()
    except KeyboardInterrupt:
        sys.exit(130)


if __name__ == "__main__":
    main()
