"""Mars TV 后端核心库 —— 共享常量 / fetch 助手 / 原子写 / 日志轮转 / LRU 单飞缓存。

设计依据: docs/superpowers/specs/2026-08-02-martv-design-v3.md 第二、四章。
供 source_engine / hot_engine / api 三模块共用，接口保持稳定，禁止破坏性变更。
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from collections import OrderedDict
from logging.handlers import RotatingFileHandler
from typing import Any, Callable, Optional, Tuple

import requests

# --------------------------------------------------------------------------
# 路径与端口
# --------------------------------------------------------------------------
BASE_DIR = "/opt/martv"
APP_DIR = os.path.join(BASE_DIR, "app")
DATA_DIR = os.path.join(BASE_DIR, "data")
LOGS_DIR = os.path.join(BASE_DIR, "logs")
SCRIPTS_DIR = os.path.join(BASE_DIR, "scripts")

WEB_PORT = 8082   # nginx 静态前端端口
API_PORT = 8090   # FastAPI 后端端口

# --------------------------------------------------------------------------
# 超时 / 并发预算（第二章运行约束）
# --------------------------------------------------------------------------
CONNECT_TIMEOUT = 2.0                # connect 超时（秒）
SOURCE_TIMEOUT = 5.0                 # 单源搜索 read 超时（秒）
CHECK_TIMEOUT = 3.0                  # 线路预检单线超时（秒）
SEARCH_TOTAL_BUDGET = 8.0            # 搜索聚合总兜底（秒）
SEMAPHORE_LIMIT = 10                 # 全局并发闸 Semaphore(10)（原 6：分类多页拉取后 6 并发冷聚合 16s+）
CHECK_CONCURRENCY = 4                # 线路预检并发上限

# --------------------------------------------------------------------------
# 熔断参数（第四章）
# --------------------------------------------------------------------------
CIRCUIT_FAIL_THRESHOLD = 3           # 单源连败 N 次触发熔断
CIRCUIT_OPEN_SECONDS = 600           # 熔断时长（10 分钟）
DEMOTE_AFTER_OPEN = 5                # 累计熔断 N 次 → 自动移出活跃池（降级 watch）
SOURCE_COOLDOWN_SECONDS = 86400      # 降级源冷却 24h 后再测
ACTIVE_POOL_ALERT_THRESHOLD = 3      # 活跃池 <3 告警

# --------------------------------------------------------------------------
# 内容黑名单（一票否决）
# --------------------------------------------------------------------------
BLACKLIST_WORDS = ("丝袜", "无码", "制服", "淫乱")

# --------------------------------------------------------------------------
# 缓存 / 日志预算
# --------------------------------------------------------------------------
LRU_MAXSIZE = 200                    # 缓存 LRU 容量上限（条）
LOG_MAX_BYTES = 5 * 1024 * 1024      # 单日志文件上限 5MB
LOG_BACKUP_COUNT = 7                 # 日志滚动备份份数

# --------------------------------------------------------------------------
# 派生路径常量
# --------------------------------------------------------------------------
SOURCES_PATH = os.path.join(DATA_DIR, "sources.json")
BACKEND_LOG_PATH = os.path.join(LOGS_DIR, "backend.log")

CHROME_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)


def is_blacklisted(text: Optional[str]) -> bool:
    """黑名单词一票否决（命中任一即 True，供源评分/入库前过滤）。"""
    if not text:
        return False
    return any(w in text for w in BLACKLIST_WORDS)


# --------------------------------------------------------------------------
# fetch 助手
# --------------------------------------------------------------------------
_session = requests.Session()
_session.headers.update({"User-Agent": CHROME_UA})
_session.trust_env = False  # 不读系统代理环境变量，避免误走代理


def fetch(url: str, method: str = "GET", timeout: Optional[float] = None,
          referer: Optional[str] = None, range_bytes: Optional[Tuple[int, int]] = None,
          headers: Optional[dict] = None, allow_redirects: bool = True):
    """requests 封装：真实 Chrome UA + 可选 Referer/Range + connect/read 双超时。

    - timeout 缺省按用途取 SOURCE_TIMEOUT；内部拆成 (connect, read) 双超时。
    - method="HEAD" 被服务器拒绝（403/405/501 或请求异常）时自动 GET 兜底。
    - 成功返回 requests.Response（调用方负责 .close() 或随用随弃）；
      失败/异常返回 None，由调用方降级处理。
    """
    to = timeout if timeout is not None else SOURCE_TIMEOUT
    hdrs = {"User-Agent": CHROME_UA}
    if referer:
        hdrs["Referer"] = referer
    if range_bytes:
        hdrs["Range"] = "bytes=%d-%d" % range_bytes
    if headers:
        hdrs.update(headers)

    def _do(m):
        try:
            return m(url, headers=hdrs, timeout=(CONNECT_TIMEOUT, to),
                     allow_redirects=allow_redirects)
        except requests.RequestException:
            return None

    if method.upper() == "HEAD":
        r = _do(_session.head)
        if r is None or r.status_code in (403, 405, 501):
            if r is not None:
                r.close()
            return _do(_session.get)  # HEAD 被拒 → GET 兜底
        return r
    return _do(_session.get)


# --------------------------------------------------------------------------
# 原子写
# --------------------------------------------------------------------------
def write_json_atomic(path: str, data: Any) -> None:
    """tmp 文件 + fsync + os.replace 原子替换；目录项一并 fsync 防断电丢条目。"""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = "%s.tmp.%d.%d" % (path, os.getpid(), threading.get_ident())
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    try:
        dfd = os.open(os.path.dirname(path) or ".", os.O_RDONLY)
        try:
            os.fsync(dfd)
        finally:
            os.close(dfd)
    except OSError:
        pass  # 个别文件系统不支持目录 fsync，忽略


# --------------------------------------------------------------------------
# 日志：RotatingFileHandler → backend.log，5MB × 7 份备份
# --------------------------------------------------------------------------
_logger_registry: dict = {}


def get_logger(name: str = "backend") -> logging.Logger:
    """按名取 logger（同名复用，防止重复 handler）；写 /opt/martv/logs/backend.log。"""
    if name in _logger_registry:
        return _logger_registry[name]
    logger = logging.getLogger("martv." + name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    if not logger.handlers:
        fh = RotatingFileHandler(BACKEND_LOG_PATH, maxBytes=LOG_MAX_BYTES,
                                 backupCount=LOG_BACKUP_COUNT, encoding="utf-8")
        fh.setFormatter(logging.Formatter(
            "%(asctime)s %(levelname)s [%(name)s] %(message)s"))
        logger.addHandler(fh)
    _logger_registry[name] = logger
    return logger


# --------------------------------------------------------------------------
# LRU 缓存：容量 ≤200 + TTL 过期 + 同键单飞
# --------------------------------------------------------------------------
_MISS = object()


class LRUCache:
    """线程安全 LRU + TTL + 同键单飞（single-flight）。

    - 容量上限 maxsize（默认 200），OrderedDict 插入/命中移尾，超限淘汰最旧。
    - TTL 惰性过期：过期键视为 miss，下次访问时重新加载刷新。
    - 单飞：同 key 并发 get_or_set 时仅一个线程执行 loader，
      其余线程等待同一结果（异常同样共享），避免打爆上游源站。
    """

    def __init__(self, maxsize: int = LRU_MAXSIZE, default_ttl: Optional[float] = None):
        self._maxsize = maxsize
        self._default_ttl = default_ttl
        self._data: "OrderedDict[Any, tuple]" = OrderedDict()  # key -> (expires_at, value)
        self._inflight: dict = {}                              # key -> (Event, container)
        self._lock = threading.Lock()
        self.hits = 0
        self.misses = 0

    @staticmethod
    def _now() -> float:
        return time.monotonic()

    def _resolve_ttl(self, ttl: Optional[float]) -> Optional[float]:
        return ttl if ttl is not None else self._default_ttl

    def _evict_locked(self) -> None:
        while len(self._data) > self._maxsize:
            self._data.popitem(last=False)

    def size(self) -> int:
        with self._lock:
            return len(self._data)

    def stats(self) -> dict:
        with self._lock:
            return {"size": len(self._data), "maxsize": self._maxsize,
                    "hits": self.hits, "misses": self.misses}

    def get(self, key: Any, default: Any = None) -> Any:
        """取缓存；未命中/过期返回 default（并计 miss）。"""
        with self._lock:
            item = self._data.get(key)
            if item is None:
                self.misses += 1
                return default
            expires_at, value = item
            if expires_at is not None and self._now() >= expires_at:
                del self._data[key]
                self.misses += 1
                return default
            self._data.move_to_end(key)
            self.hits += 1
            return value

    def set(self, key: Any, value: Any, ttl: Optional[float] = None) -> None:
        """写入缓存（覆盖旧值并刷新 TTL）。"""
        ttl = self._resolve_ttl(ttl)
        expires_at = self._now() + ttl if ttl is not None else None
        with self._lock:
            self._data[key] = (expires_at, value)
            self._data.move_to_end(key)
            self._evict_locked()

    def clear(self) -> None:
        with self._lock:
            self._data.clear()
            self._inflight.clear()

    def get_or_set(self, key: Any, loader: Callable[[], Any],
                   ttl: Optional[float] = None, force: bool = False) -> Any:
        """取缓存；未命中/过期则执行 loader 并缓存。同 key 并发仅一次 loader。

        force=True：跳过命中检查直接进入单飞 loader（预热线程用——主动刷新，
        但若用户请求正 inflight 则共享其结果，避免并发双重聚合）。
        """
        if not force:
            val = self.get(key, _MISS)
            if val is not _MISS:
                return val
        with self._lock:
            if not force:
                item = self._data.get(key)  # double-check：等待期间可能已被填充
                if item is not None:
                    expires_at, value = item
                    if expires_at is None or self._now() < expires_at:
                        self._data.move_to_end(key)
                        self.hits += 1
                        return value
                    del self._data[key]
            inflight = self._inflight.get(key)
            if inflight is not None:
                event, container = inflight
                wait = True
            else:
                event = threading.Event()
                container = {}
                self._inflight[key] = (event, container)
                wait = False
        if wait:
            event.wait()  # 等第一个线程完成，共享同一结果（含异常）
            if "error" in container:
                raise container["error"]
            return container["value"]
        # 我是第一个：执行 loader
        try:
            value = loader()
        except Exception as e:  # 失败也广播给等待者，避免各自重试打爆上游
            with self._lock:
                self._inflight.pop(key, None)
            container["error"] = e
            event.set()
            raise
        ttl = self._resolve_ttl(ttl)
        expires_at = self._now() + ttl if ttl is not None else None
        with self._lock:
            self._inflight.pop(key, None)
            self._data[key] = (expires_at, value)
            self._data.move_to_end(key)
            self._evict_locked()
        container["value"] = value
        event.set()
        return value



