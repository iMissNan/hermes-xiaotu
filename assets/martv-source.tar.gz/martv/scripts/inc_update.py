#!/usr/bin/env python3
"""增量更新（cron 每 30 分钟）：CMS 按更新时间倒序，拉各分类前几页 + 近 4 年最新页。
只更新新片/更新过的片（INSERT OR REPLACE 幂等），几分钟内完成。

有效增量：每分类先拉 pg=1 对比 max(vod_time)，源站无更新则跳过（省 2/3 请求，
避免源站限流）；有更新才拉前 3 页。vod_time 为 YYYY-MM-DD HH:MM:SS 字符串，
字典序即时间序，直接字符串比较。

附带：海报磁盘缓存清理（每日最多一次：删 30 天未访问 + 总量超 500MB 删最旧）。
"""
import sys, time, glob, os
sys.path.insert(0, "/opt/martv/app")
from crawler import crawl_all, crawl_years, init_db

POSTER_DIR = "/opt/martv/data/posters"
POSTER_MAX_TOTAL = 500 * 1024 * 1024   # 500MB 上限
POSTER_MAX_AGE = 30 * 86400            # 30 天未访问即删
CLEAN_TS = "/tmp/martv-poster-clean.ts"


def clean_posters():
    """海报磁盘缓存清理（每日一次）：
    1) 删除 mtime 超 30 天未访问的缓存（源站/图床变化后旧图无价值）
    2) 总量超 500MB 时按最旧优先删，降到 400MB 以下
    """
    try:
        last = float(open(CLEAN_TS).read().strip() or 0)
        if time.time() - last < 86400:
            return  # 每日最多执行一次
    except Exception:
        pass
    if not os.path.isdir(POSTER_DIR):
        return
    files = []
    for p in glob.glob(os.path.join(POSTER_DIR, "*.img")):
        try:
            files.append((os.path.getmtime(p), p, os.path.getsize(p)))
        except OSError:
            pass
    now = time.time()
    removed = 0
    # 1) 过期清理
    for mt, p, _ in files:
        if now - mt > POSTER_MAX_AGE:
            try:
                os.remove(p)
                removed += 1
            except OSError:
                pass
    # 2) 总量上限（最旧优先删到 400MB）
    files = [(m, p, s) for m, p, s in files if os.path.exists(p)]
    total = sum(s for _, _, s in files)
    if total > POSTER_MAX_TOTAL:
        for mt, p, s in sorted(files, key=lambda x: x[0]):
            if total <= POSTER_MAX_TOTAL * 4 // 5:
                break
            try:
                os.remove(p)
                total -= s
                removed += 1
            except OSError:
                pass
    try:
        open(CLEAN_TS, "w").write(str(time.time()))
    except OSError:
        pass
    if removed:
        print(f"海报缓存清理: 删除 {removed} 个过期文件, 当前 {total // 1024 // 1024}MB")


if __name__ == "__main__":
    t0 = time.monotonic()
    init_db()                    # 幂等建表/补列
    crawl_all("incremental")     # 各分类前 3 页（最新更新；无更新分类自动跳过）
    clean_posters()
    print(f"增量更新完成，用时 {time.monotonic()-t0:.0f}s")
