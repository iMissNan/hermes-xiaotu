#!/usr/bin/env python3
"""回填 vods.pinyin 拼音索引（一次性后台任务，可断点续跑）。

用法: /opt/martv/venv/bin/python scripts/backfill_pinyin.py [batch]
批处理 2000 条/批，异常中断后重跑自动续（只处理 pinyin='' 的行）。
"""
import os
import sys
import time

sys.path.insert(0, "/opt/martv/app")
from crawler import connect, _pinyin  # noqa: E402

BATCH = int(sys.argv[1]) if len(sys.argv) > 1 else 2000


def main():
    conn = connect()
    t0 = time.time()
    done = 0
    while True:
        rows = conn.execute(
            "SELECT id, title FROM vods WHERE pinyin = '' LIMIT ?",
            (BATCH,)).fetchall()
        if not rows:
            break
        conn.executemany("UPDATE vods SET pinyin = ? WHERE id = ?",
                         [(_pinyin(t), i) for i, t in rows])
        conn.commit()
        done += len(rows)
        print("[backfill] %d 条 (%.1fs)" % (done, time.time() - t0), flush=True)
    conn.close()
    print("[backfill] 完成，共 %d 条，耗时 %.1fs" % (done, time.time() - t0))


if __name__ == "__main__":
    main()
