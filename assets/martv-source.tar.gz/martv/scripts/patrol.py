#!/usr/bin/env python3
"""Mars TV 健康巡检器（2026-08-03）：有效性检测 + 流畅性预测。

对库内影片抽样探测播放地址：
- 有效性：HEAD/GET 播放地址 HTTP 状态（404/403/超时 = 无效，health 归零沉底）
- 流畅性：首包响应时间/源站测速 → 源级速度分（快源优先展示）

策略（G3220 老机器 + 源站友好）：
- 每天巡检一轮：全库 49 万条太多，按 (源, 分类) 分层抽样——
  近 4 年热片优先（用户最常看），旧片低频抽检
- 探测用 detail 接口拿真实播放地址（vod_play_url 有时效，取第一条线路）
- 结果写回 vods.health / vods.health_at；源级速度分写 sources.json
"""
import json
import os
import sqlite3
import sys
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "/opt/martv/app")

from source_engine import _cms_get, CMS_STD_PATH, SOURCE_TIMEOUT
from utils import fetch
from crawler import connect, DB_PATH

# 近 4 年优先（用户年份筛选核心区）
PRIORITY_YEARS = (2026, 2025, 2024, 2023)
PER_SOURCE_CAT = 30       # 每源每分类抽检条数
SAMPLE_OLD = 10           # 旧片（2010 前）每分类抽检条数
MAX_WORKERS = 4           # 探测并发（源站友好，同 CHECK_CONCURRENCY）
LINE_TIMEOUT = 5.0        # 单线探测超时


def _sample_rows(conn, limit: int) -> list:
    """抽样：近 4 年优先 + 未巡检过的优先 + 老片少量。"""
    rows = conn.execute(
        "SELECT id, title, source, vod_id FROM vods "
        "WHERE year IN (2026,2025,2024,2023) AND health_at < ? "
        "ORDER BY RANDOM() LIMIT ?",
        (time.time() - 86400, limit)).fetchall()
    if len(rows) < limit:
        rows += conn.execute(
            "SELECT id, title, source, vod_id FROM vods "
            "WHERE (year IS NULL OR year < 2023) AND health_at < ? "
            "ORDER BY RANDOM() LIMIT ?",
            (time.time() - 86400, limit - len(rows))).fetchall()
    return rows


def _probe_line(api: str, vod_id: str) -> dict:
    """detail 接口拿播放地址 → 探测有效性 + 测速。返回 {ok, speed_ms, err}。"""
    j, _ = _cms_get(api, {"ac": "detail", "ids": vod_id}, timeout=LINE_TIMEOUT)
    if j is None:
        return {"ok": False, "err": "detail fail"}
    lst = j.get("list") or []
    if not lst:
        return {"ok": False, "err": "no detail"}
    play = str(lst[0].get("vod_play_url") or "")
    if not play:
        return {"ok": False, "err": "no play_url"}
    # 取第一条线路的第一个地址（格式：名称$地址$$$名称$地址）
    url = ""
    for line in play.split("$$$"):
        line = line.strip()
        if "$" in line:
            candidate = line.split("$", 1)[1].strip()
        else:
            candidate = line
        if candidate.startswith(("http://", "https://")):
            url = candidate
            break
    if not url:
        return {"ok": False, "err": "no valid url"}
    t0 = time.monotonic()
    try:
        r = fetch(url, method="HEAD", timeout=LINE_TIMEOUT)
        if r is None:
            r = fetch(url, method="GET", timeout=LINE_TIMEOUT,
                      headers={"Range": "bytes=0-1024"})
        if r is None:
            return {"ok": False, "err": "conn fail"}
        speed = round((time.monotonic() - t0) * 1000)
        if r.status_code in (200, 206, 301, 302):
            return {"ok": True, "speed_ms": speed}
        return {"ok": False, "err": "HTTP %s" % r.status_code}
    except Exception as e:
        return {"ok": False, "err": str(e)[:60]}


def run_patrol(limit: int = 5000):
    """一轮巡检：抽样探测 → 回写 health + 源级速度分。"""
    srcs = json.load(open("/opt/martv/data/sources.json"))["sources"]
    api_of = {s["name"]: (s.get("api_hint") or (s.get("base_url") or "") + CMS_STD_PATH)
              for s in srcs if s.get("active") or s.get("status") == "active"}
    conn = connect()
    try:
        rows = _sample_rows(conn, limit)
    finally:
        conn.close()
    if not rows:
        print("无可巡检条目（全部新鲜）")
        return
    print(f"巡检 {len(rows)} 条 ...", flush=True)
    src_speed = {}   # 源 -> [速度 ms]
    src_ok = {}      # 源 -> 有效数
    src_cnt = {}     # 源 -> 总数

    def work(row):
        vid, title, source, vod_id = row
        api = api_of.get(source)
        if not api:
            return row, {"ok": False, "err": "source inactive"}
        return row, _probe_line(api, vod_id)

    results = []
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        futs = [ex.submit(work, r) for r in rows]
        for fut in as_completed(futs):
            row, res = fut.result()
            results.append((row, res))
            s = row[2]
            src_cnt[s] = src_cnt.get(s, 0) + 1
            if res["ok"]:
                src_ok[s] = src_ok.get(s, 0) + 1
                src_speed.setdefault(s, []).append(res["speed_ms"])
    # 回写
    conn = connect()
    try:
        now = time.time()
        for row, res in results:
            h = 1.0 if res["ok"] else 0.0
            conn.execute("UPDATE vods SET health=?, health_at=? WHERE id=?",
                         (h, now, row[0]))
        conn.commit()
        # 源级速度分：avg speed → 0.5~1.0（快源高分），写 sources.json
        sp = json.load(open("/opt/martv/data/sources.json"))
        for s in sp["sources"]:
            name = s["name"]
            if name not in src_cnt:
                continue
            okr = src_ok.get(name, 0) / src_cnt[name]
            avg = sum(src_speed.get(name, [1000])) / max(len(src_speed.get(name, [1])), 1)
            speed_score = max(0.5, min(1.0, 1.0 - (avg - 200) / 3000))
            s["health"] = {"ok_rate": round(okr, 2), "avg_speed_ms": round(avg),
                           "speed_score": round(speed_score, 2),
                           "checked_at": now}
        with open("/opt/martv/data/sources.json", "w") as f:
            json.dump(sp, f, ensure_ascii=False, indent=1)
    finally:
        conn.close()
    bad = sum(1 for _, r in results if not r["ok"])
    print(f"巡检完成: {len(results)} 条, 无效 {bad} 条, "
          f"源健康: { {k: '%d/%d' % (src_ok.get(k, 0), v) for k, v in src_cnt.items()} }", flush=True)


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 5000
    run_patrol(n)
