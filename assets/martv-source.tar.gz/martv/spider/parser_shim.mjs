// pdfh/pdfa/pd 宿主实现 —— 基于 npm 标准 cheerio（TVBox/FongMi 语义）
// pdfh(html, "sel&&attr1&&Text")    单字段：选择器 + && 属性/子选择器链，取第一条
// pdfa(html, "sel;f1;f2;...")       多字段：选择器匹配多个元素，每元素逐字段 pdfh，~ 拼接
// pd(html, "sel&&href", base)       URL 字段 + 相对地址拼接
export async function installParser() {
  const { load } = await import('cheerio');
  const DOM_CHECK_ATTR = /(url|src|href|-original|-src|-play|-url|style)$/;
  const SPECIAL_URL = /^(ftp|magnet|thunder|ws):/;

  // 单字段解析：sel&&链
  function pdfhOne(html, parse) {
    if (!parse || !parse.trim()) return '';
    const parts = String(parse).split('&&');
    const p0 = parts[0].trim();
    if (!p0) return '';
    try {
      const $ = load(html);
      let cur = $(p0).first();
      if (cur.length === 0) return '';
      for (let i = 1; i < parts.length; i++) {
        const p = parts[i].trim();
        if (!p) continue;
        const lp = p.toLowerCase();
        if (lp === 'text' || lp === 'text()') {
          cur = cur.text().trim();
        } else if (lp === 'html') {
          cur = cur.html() || '';
        } else if (lp === 'alltext') {
          cur = cur.text().replace(/\s+/g, ' ').trim();
        } else {
          // TVBox：先当属性取，失败/为空则当子选择器 find
          const v = cur.attr(p);
          if (v !== undefined && v !== '') {
            cur = String(v).trim();
          } else {
            cur = cur.find(p).first();
          }
        }
      }
      return typeof cur === 'string' ? cur : '';
    } catch (e) {
      return '';
    }
  }

  globalThis.pdfh = pdfhOne;

  // 多字段列表解析
  globalThis.pdfa = (html, parse) => {
    if (!parse || !parse.trim()) return [];
    const parts = String(parse).split(';').map((s) => s.trim()).filter(Boolean);
    if (!parts.length) return [];
    try {
      const $ = load(html);
      const out = [];
      $(parts[0]).each((i, el) => {
        const itemHtml = $(el).html() || '';
        const fields = [];
        for (let j = 1; j < parts.length; j++) {
          fields.push(pdfhOne(itemHtml, parts[j]));
        }
        out.push(fields.join('~'));
      });
      return out;
    } catch (e) {
      return [];
    }
  };

  globalThis.pd = (html, parse, uri) => {
    let ret = pdfhOne(html, parse);
    if (!ret) return '';
    if (DOM_CHECK_ATTR.test(parse) && !SPECIAL_URL.test(ret)) {
      if (/http/.test(ret)) {
        ret = ret.slice(ret.indexOf('http'));
      } else {
        const base = uri || globalThis.MY_URL || '';
        ret = globalThis.joinUrl(base, ret);
      }
    }
    return ret;
  };

  globalThis.pdfh2 = pdfhOne;
  globalThis.pdfa2 = globalThis.pdfa;
  globalThis.pd2 = globalThis.pd;
}
