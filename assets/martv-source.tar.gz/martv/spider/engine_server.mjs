// Mars TV Spider 引擎网关 —— worker 线程池版
// 监听 127.0.0.1:8095，FastAPI 通过 HTTP 调用
// 架构：主进程只做 HTTP + 任务分发；3 个 worker 各自独立 drpy2 实例
//       （drpy2 的 req 是同步 curl，会阻塞事件循环——worker 隔离后互不影响）
// 端点: /health /sources /probe /search /detail /home /play
import http from 'http';
import fs from 'fs';
import path from 'path';
import { Worker } from 'worker_threads';

const SPIDER_DIR = '/opt/martv/spider';
const LIBS_DIR = path.join(SPIDER_DIR, 'libs');
const SCRIPTS_DIR = path.join(SPIDER_DIR, 'scripts');
const PORT = 8095;
const SRC_TIMEOUT = 30000;         // 单源操作超时（HTTP 层）
const WORKER_COUNT = 3;            // worker 池大小
const OP_QUEUE_MAX = 24;           // 主进程待分发队列上限（防堆积）

// ---------------- worker 池 ----------------
let workerSeq = 0;
const workers = [];
const pending = new Map();         // id → {resolve, timer}
const ready = new Set();

function pickWorker() {
  // 选 pending 任务最少的 worker
  let best = workers[0];
  let bestLoad = Infinity;
  for (const w of workers) {
    const load = w.busy || 0;
    if (load < bestLoad) { bestLoad = load; best = w; }
  }
  return best;
}

function dispatch(worker, payload) {
  return new Promise((resolve) => {
    const id = 't' + (++workerSeq);
    const timer = setTimeout(() => {
      pending.delete(id);
      worker.busy = (worker.busy || 0) - 1;
      resolve({ ok: false, error: 'engine_timeout' });
    }, SRC_TIMEOUT);
    pending.set(id, { resolve, timer });
    worker.busy = (worker.busy || 0) + 1;
    worker.postMessage({ id, ...payload });
  });
}

function createWorker() {
  const w = new Worker(path.join(SPIDER_DIR, 'engine_worker.mjs'), {
    workerData: { LIBS_DIR, SCRIPTS_DIR, REQ_TIMEOUT: 10 },
  });
  w.busy = 0;
  w.on('message', (msg) => {
    if (msg.id === '__ready__') {
      ready.add(w);
      return;
    }
    const p = pending.get(msg.id);
    if (p) {
      clearTimeout(p.timer);
      pending.delete(msg.id);
      w.busy = Math.max(0, (w.busy || 0) - 1);
      p.resolve(msg.result || { ok: false, error: 'no_result' });
    }
  });
  w.on('error', (e) => console.log('worker error:', String(e.message || e).slice(0, 120)));
  w.on('exit', (code) => {
    ready.delete(w);
    // 重建（幂等：5s 后重启一个）
    setTimeout(() => {
      if (!workers.includes(w)) return;
      const idx = workers.indexOf(w);
      workers[idx] = createWorker();
      console.log('worker 重建，池大小', workers.length);
    }, 5000);
  });
  workers.push(w);
  return w;
}

// 初始化 worker 池
for (let i = 0; i < WORKER_COUNT; i++) createWorker();

// 任务分发（带队列上限）
let dispatchQueue = Promise.resolve();
let dispatchDepth = 0;
function submit(payload) {
  if (dispatchDepth >= OP_QUEUE_MAX) {
    return Promise.resolve({ ok: false, error: 'queue_full', queued: dispatchDepth });
  }
  dispatchDepth++;
  const run = dispatchQueue.then(async () => {
    const w = pickWorker();
    return dispatch(w, payload);
  });
  dispatchQueue = run.catch(() => {});
  return run.finally(() => { dispatchDepth--; });
}

// ---------------- HTTP 服务 ----------------
const server = http.createServer(async (req, res) => {
  const respond = (code, obj) => {
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify(obj));
  };
  try {
    const u = new URL(req.url, 'http://127.0.0.1');
    const p = u.pathname;

    if (p === '/health') {
      return respond(200, {
        ok: true, ts: Date.now(),
        workers: workers.filter((w) => ready.has(w)).length,
        pending: pending.size,
        queued: dispatchDepth,
      });
    }
    if (p === '/sources') {
      const names = fs.readdirSync(SCRIPTS_DIR).filter((f) => f.endsWith('.js'));
      return respond(200, { ok: true, total: names.length });
    }

    let body = '';
    for await (const chunk of req) {
      body += chunk;
      if (body.length > 1024 * 1024) return respond(413, { ok: false, error: 'too_large' });
    }
    const q = JSON.parse(body || '{}');
    const name = q.source;
    if (!name) return respond(400, { ok: false, error: 'no_source' });

    let payload = null;
    if (p === '/search') {
      if (!q.keyword) return respond(400, { ok: false, error: 'no_keyword' });
      payload = { op: 'search', source: name, keyword: q.keyword };
    } else if (p === '/detail') {
      if (!q.ids) return respond(400, { ok: false, error: 'no_ids' });
      payload = { op: 'detail', source: name, ids: q.ids };
    } else if (p === '/home') {
      payload = { op: 'home', source: name };
    } else if (p === '/play') {
      if (!q.flag || !q.id) return respond(400, { ok: false, error: 'no_flag_id' });
      payload = { op: 'play', source: name, flag: q.flag, vid: q.id };
    } else if (p === '/probe') {
      payload = { op: 'probe', source: name, smoke: !!q.smoke };
    } else {
      return respond(404, { ok: false, error: 'not_found' });
    }

    const r = await submit(payload);
    return respond(r && r.ok !== false ? 200 : (r && r.error === 'queue_full' ? 503 : 502), r);
  } catch (e) {
    return respond(500, { ok: false, error: String(e.message || e).slice(0, 200) });
  }
});

// 启动
server.listen(PORT, '127.0.0.1', () => {
  console.log(`spider 引擎网关（worker×${WORKER_COUNT}）监听 http://127.0.0.1:${PORT}`);
});
