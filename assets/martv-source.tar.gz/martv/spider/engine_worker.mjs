// Spider 引擎 Worker —— 每个 worker 独立 drpy2 实例（隔离同步阻塞）
// 主进程通过 postMessage 分发任务，worker 串行执行
import { parentPort, workerData } from 'worker_threads';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { createRequire } from 'module';
import https from 'https';
import http from 'http';

const require = createRequire(import.meta.url);
const LIBS_DIR = workerData.LIBS_DIR;
const SCRIPTS_DIR = workerData.SCRIPTS_DIR;
const REQ_TIMEOUT = workerData.REQ_TIMEOUT || 10;   // 单次 curl 超时（缩短，防长卡）
const MAX_BUF = 30 * 1024 * 1024;

// ---------------- TVBox 宿主全局（必须在 import drpy2 前） ----------------
const _store = {};
globalThis.env = { MY_URL: '', ROUTE_PATH: '' };
globalThis.local = {
  get: (k) => (_store[k] !== undefined ? _store[k] : null),
  set: (k, v) => { _store[k] = String(v); },
  delete: (k) => { delete _store[k]; },
  clear: () => { for (const k in _store) delete _store[k]; },
  size: () => Object.keys(_store).length,
};
globalThis.pdfh = () => '';
globalThis.pdfa = () => '';
globalThis.pd = () => '';
globalThis.pdfl = () => '';
globalThis.pdfh2 = () => '';
globalThis.pdfa2 = () => '';
globalThis.pd2 = () => '';
globalThis.joinUrl = (a, b) => (b && b.startsWith('http') ? b : (a || '') + (b || ''));
globalThis.urljoin = (a, b) => globalThis.joinUrl(a, b);
globalThis.print = () => {};
globalThis.log = () => {};
globalThis.dealJson = (s) => { try { return JSON.parse(s); } catch (e) { return {}; } };
globalThis.getProxyUrl = () => 'http://127.0.0.1:9978/proxy?do=js';
globalThis.getCrypto = () => ({ MD5: (s) => s });
globalThis.MY_URL = '';
globalThis.MY_CATE = '';
globalThis.MY_PAGE = '1';
globalThis.VODS = [];
globalThis.VOD = {};
globalThis.HOST = '';
globalThis.getxx = [];

// UMD 库显式加载
let CryptoJS = null, pako = null;
try { CryptoJS = require(path.join(LIBS_DIR, 'crypto-js.js')); globalThis.CryptoJS = CryptoJS; } catch (e) {}
try {
  pako = require(path.join(LIBS_DIR, 'pako.min.js'));
  globalThis.pako = pako;
  globalThis.ungzip = (s) => {
    const bin = pako.ungzip(Uint8Array.from(atob(s), (c) => c.charCodeAt(0)));
    return new TextDecoder().decode(bin);
  };
} catch (e) {}
try { globalThis.NODERSA = require(path.join(LIBS_DIR, 'node-rsa.js')); } catch (e) {}
try { globalThis.JSEncrypt = require(path.join(LIBS_DIR, 'jsencrypt.js')); } catch (e) {}

// req：TVBox 同步请求（worker 内阻塞无碍——不影响主进程事件循环）
globalThis.req = (url, obj = {}) => {
  const u = String(url || '');
  if (!/^https?:\/\//i.test(u)) return { content: '', headers: {}, status: 0 };
  const method = (obj.method || 'GET').toUpperCase();
  const headers = obj.headers || {};
  let cmd = `curl -s -m ${REQ_TIMEOUT} -i -X ${method}`;
  for (const [k, v] of Object.entries(headers)) {
    if (['cookie', 'user-agent', 'referer', 'content-type', 'accept', 'x-requested-with'].includes(k.toLowerCase())) {
      cmd += ` -H '${k}: ${String(v).replace(/'/g, '')}'`;
    }
  }
  if (obj.body) {
    const b = typeof obj.body === 'string' ? obj.body : JSON.stringify(obj.body);
    cmd += ` -d '${b.replace(/'/g, '')}'`;
  }
  cmd += ` '${u.replace(/'/g, '')}'`;
  try {
    const raw = execSync(cmd, { encoding: 'utf8', maxBuffer: MAX_BUF, timeout: REQ_TIMEOUT * 1000 });
    const sep = raw.indexOf('\r\n\r\n');
    const headPart = sep >= 0 ? raw.slice(0, sep) : '';
    const content = sep >= 0 ? raw.slice(sep + 4) : raw;
    const headersOut = {};
    for (const line of headPart.split('\r\n').slice(1)) {
      const i = line.indexOf(':');
      if (i > 0) headersOut[line.slice(0, i).trim().toLowerCase()] = line.slice(i + 1).trim();
    }
    return { content, headers: headersOut, status: parseInt(headPart.split(' ')[1] || '0', 10) };
  } catch (e) {
    return { content: '', headers: {}, status: 0 };
  }
};
globalThis.request = (url, options = {}) => globalThis.req(url, options).content;

// fetch：异步（部分 spider 用）
globalThis.fetch = (url, options = {}) => {
  return new Promise((resolve, reject) => {
    const u = String(url || '');
    if (!/^https?:\/\//i.test(u)) return reject(new Error('bad url'));
    const isHttps = u.startsWith('https');
    const h = isHttps ? https : http;
    const pu = new URL(u);
    const headers = { 'User-Agent': 'Mozilla/5.0 (Linux; Android 11) TVBox', ...(options.headers || {}) };
    const req = h.request({
      hostname: pu.hostname, port: pu.port || (isHttps ? 443 : 80),
      path: pu.pathname + pu.search, method: (options.method || 'GET').toUpperCase(),
      headers,
    }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        const buf = Buffer.concat(chunks);
        resolve({
          ok: res.statusCode >= 200 && res.statusCode < 300,
          status: res.statusCode,
          headers: { get: (k) => res.headers[k.toLowerCase()] || null },
          json: () => JSON.parse(buf.toString('utf8')),
          text: () => buf.toString('utf8'),
          arrayBuffer: () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength),
        });
      });
    });
    req.setTimeout((options.timeout || 15000), () => req.destroy(new Error('timeout')));
    req.on('error', reject);
    if (options.body) req.write(typeof options.body === 'string' ? options.body : JSON.stringify(options.body));
    req.end();
  });
};

// ---------------- 引擎 ----------------
// 关键顺序：drpy2 的 defaultParser={pdfh,pdfa,pd} 在模块加载时捕获全局引用，
// 必须先安装 cheerio 解析器，再 import drpy2（否则 defaultParser 永远指向空函数）。
const { installParser } = await import('./parser_shim.mjs');
await installParser();
console.log('pdfh/pdfa/pd 解析器已安装 (npm cheerio)');

const drpyMod = await import(path.join(LIBS_DIR, 'drpy2.min.mjs'));
const drpy = drpyMod.default;

function loadScript(name) {
  const safe = path.basename(String(name));
  const fp = path.join(SCRIPTS_DIR, safe);
  if (!fs.existsSync(fp)) return null;
  return fs.readFileSync(fp, 'utf8');
}

function preDecode(code) {
  if (!code) return code;
  if (/var rule|function|[\u4e00-\u9fa5]/.test(code)) return code;
  try {
    const dec = Buffer.from(code.replace(/\s+/g, ''), 'base64').toString('utf8');
    if (dec && /var rule/.test(dec)) return dec;
  } catch (e) { /* ignore */ }
  return code;
}

function parseResult(r) {
  if (typeof r === 'string') {
    try { return JSON.parse(r); } catch (e) { return {}; }
  }
  return r || {};
}

// 每次操作前重新 init（drpy2 单例 rule）
async function withSource(name, fn) {
  const code = loadScript(name);
  if (!code) return { ok: false, error: 'no_script' };
  try {
    await drpy.init(preDecode(code));
  } catch (e) {
    return { ok: false, error: 'init_fail' };
  }
  const rule = drpy.getRule();
  if (!rule || !(rule.title || rule.host || rule.url)) {
    return { ok: false, error: 'init_fail' };
  }
  return fn(rule);
}

// 串行队列（worker 内单例 rule 保护）
let opQueue = Promise.resolve();
function enqueue(fn) {
  const run = opQueue.then(fn, fn);
  opQueue = run.catch(() => {});
  return run;
}

// ---------------- 消息处理 ----------------
parentPort.on('message', async (msg) => {
  const { id, op, source, keyword, ids, flag, vid, smoke } = msg;
  try {
    const result = await enqueue(() => withSource(source, async (rule) => {
      const o = { ok: true, title: rule.title || '', host: rule.host || '' };
      if (op === 'search') {
        const r = await drpy.search(keyword);
        o.list = parseResult(r).list || [];
      } else if (op === 'detail') {
        o.detail = parseResult(await drpy.detail(ids));
      } else if (op === 'home') {
        o.home = parseResult(await drpy.home());
      } else if (op === 'play') {
        o.play = parseResult(await drpy.play(flag, vid));
      } else if (op === 'probe') {
        o.searchable = rule.searchable ?? '';
        o.searchUrl = rule.searchUrl ? 'yes' : '';
        o.detailUrl = rule.detailUrl ? 'yes' : '';
        if (smoke && (rule.searchable === 2 || rule.searchable === '2' || (rule.搜索 && rule.搜索 !== '*') || rule.searchUrl)) {
          try {
            o.smoke = (parseResult(await drpy.search('爱情公寓')).list || []).length;
          } catch (e) {
            o.smoke = -1;
          }
        }
      }
      return o;
    }));
    parentPort.postMessage({ id, result });
  } catch (e) {
    parentPort.postMessage({ id, result: { ok: false, error: String(e.message || e).slice(0, 150) } });
  }
});

parentPort.postMessage({ id: '__ready__' });
